<?php

namespace App\Controllers\Api\Approvals;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Attendance extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside attendance/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

	public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->attendance->select('COUNT(attendanceId) as total')->where('status', 'PENDING')->where('nextApprover', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->attendance->where('nextApprover', $userId)->where('status', 'PENDING')->orderBy('attendanceId', 'DESC')->limit($limit, $offset)->find();

                    foreach($data as $attendance)
                    {
                        if($attendance->picture)
                        {
                            $attendance->picture = site_url($attendance->picture);
                        }
                        
                        $nextApproverName = $this->users->findById($attendance->nextApprover) ? $this->users->findById($attendance->nextApprover)->employeeName: "-";
                        $attendance->nextApproverName = $nextApproverName;
                    }

                    if($data)
                    {
                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");

                    if(!$startDate || !$endDate)
                    {
                        $response = [
                            "status" => 500,
                            "message" => "Please provide Start Date & End Date",
                            "error" => true,
                            "data" => []
                        ];
                    }
                    else
                    {
                        //Content Goes Here
                        $data = $this->attendance->where('nextApprover', $userId)->where("date BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE)->where('status', 'PENDING')->findAll();

                        if($data)
                        {
                            foreach($data as $attendance)
                            {
                                if($attendance->picture)
                                {
                                    $attendance->picture = site_url($attendance->picture);
                                }
                                
                                $nextApproverName = $this->users->findById($attendance->nextApprover) ? $this->users->findById($attendance->nextApprover)->employeeName: "-";
                                $attendance->nextApproverName = $nextApproverName;
                            }

                            $response = [
                                "status" => 200,
                                "message" => "Data Fetched successfully",
                                "error" => false,
                                "data" => $data
                            ];
                        }
                        else
                        {
                            $response = [
                                "status" => 500,
                                "message" => "Sorry, no records found for the specified dates.",
                                "error" => true,
                                "data" => []
                            ];
                        }
                        //Content Goes Here
                    }
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function view($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$attendanceId = $this->request->getVar("attendanceId");

                    //Content Goes Here
                    $total = $this->attendance->select('COUNT(attendanceId) as total')->where('attendanceId', $attendanceId)->first()->total;

                    $data = $this->attendance->where('attendanceId', $attendanceId)->first();

                    if($data)
                    {

						if($data->picture)
                        {
                            $data->picture = site_url($data->picture);
                        }
                        
                        $nextApproverName = $this->users->findById($data->nextApprover) ? $this->users->findById($data->nextApprover)->employeeName: "-";
                        $data->nextApproverName = $nextApproverName;

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function approve($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					if($this->request->getVar("attendanceId") && $this->request->getVar("attendanceId") >= 1)
					{
						$attendanceId = $this->request->getVar("attendanceId");
						$currentApprover = $userId;
						$profile = $this->profile->where('userId', $userId)->first();
						$nextApprover = ($profile->reportTo && $profile->reportTo >= 1) ? $profile->reportTo : null;

						//Content Goes Here
						if($nextApprover)
						{
							$updateArray = array(
								'nextApprover' => $nextApprover,
								'status' => 'APPROVED'
							);

							if($this->attendance->set($updateArray)->where('attendanceId', $attendanceId)->update())
							{
								$log = array(
									'userId' => $userId,
									'attendanceId' => $attendanceId,
									'log' => "Attendance approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Attendance approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->attendance->errors()
								];
							}
						}
						else
						{
							$updateArray = array(
								'nextApprover' => null,
								'status' => 'APPROVED',
								'approvedBy' => $userId
							);

							if($this->attendance->set($updateArray)->where('attendanceId', $attendanceId)->update())
							{
								$log = array(
									'userId' => $userId,
									'attendanceId' => $attendanceId,
									'log' => "Attendance approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Attendance approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->attendance->errors()
								];
							}
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Attencde ID is required",
							"error" => true,
							"data" => ""
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function reject($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					//Content Goes Here
					$attendanceId = $this->request->getVar("attendanceId");
					$approverRemarks = $this->request->getVar("approverRemarks");

					if($this->request->getVar("attendanceId") && $this->request->getVar("attendanceId") >= 1)
					{
						if(!$approverRemarks)
						{
							$response = [
								"status" => 500,
								"message" => "Please provide your remarks",
								"error" => true,
								"data" => ""
							];
						}
						else
						{
							$updateArray = array(
								'status' => 'REJECTED',
								'approverRemarks' => $approverRemarks
							);

							if($this->attendance->set($updateArray)->where('attendanceId', $attendanceId)->update())
							{
								$log = array(
									'userId' => $userId,
									'attendanceId' => $attendanceId,
									'log' => $approverRemarks
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Attendance rejected successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->attendance->errors()
								];
							}
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Attendance ID is required",
							"error" => true,
							"data" => []
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }
}