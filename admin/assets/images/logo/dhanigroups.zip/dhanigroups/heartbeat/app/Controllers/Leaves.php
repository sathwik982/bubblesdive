<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Leaves extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Leaves();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Leaves/');
        define('ITEM','Leave');
        define('ITEMS','Leaves');
        define('DBTABLE','leaves');
        define('VARIABLE','data');
        define('ROUTE','leaves');

        session()->set('activate', "leaves");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );
        $leaveCategories = $this->leaveCategories->findAll();
        return view(VIEWFOLDER.'index', ['const' => $const, 'leaveCategories' => $leaveCategories]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('leaveId, userId, leaveCategoryId, createdDate, total, status, nextApprover, approvedBy');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->leaveId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a href="'.site_url(ROUTE."/view/".$row->leaveId).'" class="text-primary"><i class="bx bx-show-alt" style="font-size:20px;"></i></a>
                    ';
        })
        ->edit('userId', function($row)
        {
            $employeeName = $this->users->findById($row->userId) ? $this->users->findById($row->userId)->employeeName: "-";
            return $employeeName;
        })
    
        ->edit('leaveCategoryId', function($row)
        {
            $leaveCategory = $this->leaveCategories->findById($row->leaveCategoryId) ? $this->leaveCategories->findById($row->leaveCategoryId)->leaveCategory: "-";
            return $leaveCategory;
        })

        ->edit('createdDate', function($row)
        {
            $timestamp = strtotime($row->createdDate);
            $date = date('Y-m-d', $timestamp);
            return $date;
        })
        ->edit('nextApprover', function($row)
        {
            $nextApprover = $this->users->findById($row->nextApprover) ? $this->users->findById($row->nextApprover)->employeeName: "-";
            return $nextApprover;
        })
        ->edit('approvedBy', function($row)
        {
            $approvedBy = $this->users->findById($row->approvedBy) ? $this->users->findById($row->approvedBy)->employeeName: "-";
            return $approvedBy;
        })
        ->edit('status', function($row)
        {
            if($row->status == "APPROVED")
            {
                return "<span class='badge badge-soft-success font-size-12'>" .$row->status. "</span>";                   
            }
            else
            {
                return "<span class='badge badge-soft-danger font-size-12'>" .$row->status. "</span>";   
            }
        })
        ->edit('total', function($row) 
        {
            if ($row->total != "") 
            {
               return $row->total . " days";
            } 
        })
        ->filter(function ($builder, $request)
        {
            if ($this->request->getGet("status"))
            $builder->where("status", $this->request->getGet("status"));
            if ($this->request->getGet("leaveCategoryId"))
            $builder->where("leaveCategoryId", $this->request->getGet("leaveCategoryId"));
            if ($this->request->getGet("fromDate") && $this->request->getGet("toDate"))
            {
                $from = date("Y-m-d", strtotime($this->request->getGet("fromDate")));
                $to = date("Y-m-d", strtotime($this->request->getGet("toDate")));

                $builder->where("DATE(createdDate) BETWEEN '" . $from . "' AND '" . $to . "'", NULL, FALSE);
            }
        })
        
        
        //->hide('leaveId')
        ->toJson(); 
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        $users = $this->users->findAll();
        $leaveCategories = $this->leaveCategories->findAll();
        
        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'leaveCategories' => $leaveCategories]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');
    
        $fromDate = strtotime($data->fromDate);
        $toDate = strtotime($data->toDate);
      
        $secondsDiff = $toDate - $fromDate;
        $daysDiff = floor($secondsDiff / (60 * 60 * 24));
    
        if($this->model->insert($data))
        {
           $leaveId = $this->model->insertID;
           $this->leaves->set('total', $daysDiff)->where('leaveId', $leaveId)->update();
           $leaveId = $this->model->getInsertID();

        if($this->request->getFileMultiple('document'))
        {
            $leave_documents = $this->request->getFileMultiple('document');
                foreach($leave_documents as $document)
                {
                    $file = $document;
                    $uploadedFile = $file->getName();
                    $originalName = $file->getName();
                    if($document && $uploadedFile != "")
                    {
                        $uploadedFile = $file->getName();
                        if($uploadedFile != "")
                        {
                            if ($file->isValid() && !$file->hasMoved())
                            {
                                $extension = $file->getClientExtension();
                                $newName = $leaveId . "_closure_".rand().".".$extension;
                                $file->move('uploads/', $newName);
                                $uploadedFile = "uploads/".$newName;
                            }

                            //Save to Database
                            $insertArray = array(
                                'leaveId' => $leaveId,
                                'documents' => $uploadedFile,
                                'createdDate' => date("Y-m-d H:i:s"),
                                'lastModifiedDate' => date("Y-m-d H:i:s")
                            );

                            $this->leave_documents->insert($insertArray);

                        //Save to Database
                    }
                }
            }
        } 
           return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }
        
    }

    public function edit($leaveId)
    {
        $data = $this->check($leaveId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->leaveId,
            'id'=> $data->leaveId
        );

        $users = $this->users->findAll();
        $leaveCategories = $this->leaveCategories->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'leaveCategories' => $leaveCategories]);
    }

    public function update($leaveId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($leaveId);
        if($this->request->getFileMultiple('document'))
        {
            $leave_documents  = $this->request->getFileMultiple('document');
            foreach($leave_documents  as $document)
            {
                $file = $document;
                $uploadedFile = $file->getName();
                if($document && $uploadedFile != "")
                {
                    $uploadedFile = $file->getName();
                    if($uploadedFile != "")
                    {
                        if ($file->isValid() && !$file->hasMoved())
                        {
                            $extension = $file->getClientExtension();
                            $newName = $leaveId . "_closure_".rand().".".$extension;
                            $file->move('uploads/', $newName);
                            $uploadedFile = "uploads/".$newName;
                        }

                        //Save to Database
                        $insertArray = array(
                            'leaveId' => $leaveId,
                            'documents' => $uploadedFile,
                            'createdDate' => date("Y-m-d H:i:s"),
                            'lastModifiedDate' => date("Y-m-d H:i:s")
                        );

                        $this->leave_documents->insert($insertArray);
                        //Save to Database
                    }
                }
            }
        }
		$data->fill($post);
        
        if(!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function view($leaveId)
    {
        $data = $this->check($leaveId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->leaveId,
            'id'=> $data->leaveId
        );
         
        $users = $this->users->findAll();
        $leaveCategories = $this->leaveCategories->findAll();
        $leave_documents = $this->leave_documents->where('leaveId', $leaveId)->findAll();
        
        foreach($leave_documents as $leave_document)
        {
            if($leave_document->documents)
            {
                $leave_document->documents = site_url($leave_document->documents);
            }
        }
       
        return view(VIEWFOLDER."view", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'leaveCategories' => $leaveCategories, 'leave_documents' => $leave_documents]);
    }

    public function check($leaveId)
	{
		$data = $this->model->findById($leaveId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $leaveId not found");
		}
		return $data;
	}

}



