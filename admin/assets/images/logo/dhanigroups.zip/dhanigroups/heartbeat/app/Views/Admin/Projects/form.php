<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="projectName">Project Name <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="projectName" name="projectName" placeholder="Project Name" required value="<?= old('projectName', $data->projectName); ?>">
        <div class="invalid-feedback">Please enter the Project Name</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="projectLocation">Project Location <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="projectLocation" name="projectLocation" placeholder="Project Location" required value="<?= old('projectLocation', $data->projectLocation); ?>">
        <div class="invalid-feedback">Please enter the Project Location</div>
    </div>
    <div class="col-md-3" id="headQuarterId">
        <div class="mb-3">
            <label for="headQuarterId">Headquarter <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="headQuarterId" name="headQuarterId">
                <option value="">Please Select</option>
                <?php
                    foreach($headquarters as $headquarter)
                    {
                        $selected = null;
    
                        (old('headQuarterId', $data->headQuarterId) == $headquarter->headQuarterId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$headquarter->headQuarterId.'" '.$selected.'>'.$headquarter->headQuarterName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Headquarter</div>
        </div>
    </div>
</div>