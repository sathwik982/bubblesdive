<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Login extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

	// POST
	public function index()
	{
		$rules = [
			"mobileNumber" => "required",
			"userPassword" => "required|min_length[6]"
		];

		if (!$this->validate($rules))
		{
			$response = [
				"status" => 500,
				"message" => $this->validator->getErrors(),
				"error" => true,
				"data" => []
			];
		} 
		else
		{

			$mobileNumber = $this->request->getVar("mobileNumber");
			$userPassword = $this->request->getVar("userPassword");
			$user = new Users();
			$user = $user->where("mobileNumber", $mobileNumber)->where("userStatus", 'ACTIVE')->first();

			if (!empty($user))
			{
				if (MD5($userPassword) == $user->userPassword)
				{
					$iat = time();
					$nbf = $iat - 10000;
					$exp = $iat + 3600;
					unset($user->password);

					$payload = [
						"iat" => $iat,
						"nbf" => $nbf,
						"userinfo" => $user
					];

					$token = JWT::encode($payload, $this->getKey());

					$response = [
						"status" => 200,
						"message" => 'Login Successful',
						"error" => false,
						"data" => [
							"token" => $token
						]
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => 'Invalid Credentials',
						"error" => true,
						"data" => []
					];
				}
			}
			else
			{
				$response = [
					"status" => 500,
					"message" => 'User does not exist or is not activated',
					"error" => true,
					"data" => []
				];
			}
		}

		return $this->respondCreated($response);
	}

	// GET
	public function profile()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					unset($user->userPassword);
					unset($user->otp);
					$profile = $this->profile->where('userId', $user->userId)->first();

					unset($profile->profileId);
					unset($profile->userId);

					//Modify Data
					$profile->designation = $this->designations->findById($profile->designationId) ? $this->designations->findById($profile->designationId)->designation: "-";

					$profile->highestQualificationName = $this->qualifications->findById($profile->highestQualification) ? $this->qualifications->findById($profile->highestQualification)->qualificationName: "-";

					$profile->projectName = $this->projects->findById($profile->projectId) ? $this->projects->findById($profile->projectId)->projectName: "-";

					$profile->headQuarterName = $this->headquarters->findById($profile->headquarterId) ? $this->headquarters->findById($profile->headquarterId)->headQuarterName: "-";

					$profile->reportToName = $this->users->findById($profile->reportTo) ? $this->users->findById($profile->reportTo)->employeeName: "-";

					$profile->profilePicture = ($profile->profilePicture) ? site_url($profile->profilePicture) : $profile->profilePicture;
					//Modify Data

					$response = [
						"status" => 200,
						"message" => "User Details",
						"error" => false,
						"data" => [
							"user" => $user,
							"profile" => $profile
						]
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Session Expired. Please login & try again.",
						"error" => true,
						"data" => []
					];
				}

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function forgot()
	{
		$mobileNumber = $this->request->getVar("mobileNumber");
		$user = new Users();
		$user = $user->where("mobileNumber", $mobileNumber)->first();
		
		if (!empty($user))
		{
			$sendArray = array('userId' => $user->userId);
			$otp = random_int(100000, 999999);
			$this->users->set('otp', $otp)->where("mobileNumber", $mobileNumber)->update();

			//Send SMS
			$data = [
			'From'=>'CRISNT', 
			'To'=> $mobileNumber,
			'TemplateName'=> ' OTP_TO_CUSTOMER',
			'VAR1'=> 'DHANI GROUPS',
			'VAR2'=> $otp,
			'VAR3'=> 'DHANI'
			];
		
			$url = 'http://2factor.in/API/V1/'.$_ENV['SMS_API_KEY'].'/ADDON_SERVICES/SEND/TSMS';
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			$result = curl_exec($curl);
			curl_close($curl);
		
			$response = [
				"status" => 200,
				"message" => 'OTP sent successfully',
				"error" => false,
				"data" => $sendArray
			];
		}
		else
		{
			$response = [
				"status" => 500,
				"message" => 'User with this Mobile Number doesa not exist',
				"error" => true,
				"data" => []
			];
		}

		return $this->respondCreated($response);
	}

	public function verify()
	{
		$userId = $this->request->getVar("userId");
		$otp = $this->request->getVar("otp");
		$user = new Users();
		$user = $this->users->where("userId", $userId)->where("otp", $otp)->first();

		if (!empty($user))
		{
			$this->users->set('otp', null)->where("userId", $userId)->update();

			$response = [
				"status" => 200,
				"message" => 'OTP Verified successully',
				"error" => false,
				"data" => "VALID"
			];
		}
		else
		{
			$response = [
				"status" => 500,
				"message" => 'Invalid OTP',
				"error" => true,
				"data" => "INVALID"
			];
		}

		return $this->respondCreated($response);
	}

	public function resend()
	{
		$userId = $this->request->getVar("userId");
		$user = $this->users->findById($userId);

		if($user)
		{
			$otp = random_int(100000, 999999);
			//Send SMS
			$data = [
			'From'=>'CRISNT', 
			'To'=> $user->mobileNumber,
			'TemplateName'=> ' OTP_TO_CUSTOMER',
			'VAR1'=> 'DHANI GROUPS',
			'VAR2'=> $otp,
			'VAR3'=> 'DHANI'
			];
		
			$url = 'http://2factor.in/API/V1/'.$_ENV['SMS_API_KEY'].'/ADDON_SERVICES/SEND/TSMS';
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			$result = curl_exec($curl);
			curl_close($curl);

			if($this->users->set('otp', $otp)->where('userId', $userId)->update())
			{
				$response = [
					"status" => 200,
					"message" => 'OTP sent successfully',
					"error" => false,
					"data" => []
				];
			}
			else
			{
				$response = [
					"status" => 500,
					"message" => 'Error updating user OTP',
					"error" => true,
					"data" => []
				];
			}
		}
		else
		{
			$response = [
				"status" => 500,
				"message" => 'User does not exist',
				"error" => true,
				"data" => []
			];
		}

		return $this->respondCreated($response);
	}

	public function newpassword()
	{
		$userId = $this->request->getVar("userId");
		$userPassword = $this->request->getVar("userPassword");
		$password_confirmation = $this->request->getVar("password_confirmation");

		$rules = [
			"userPassword" => "required|min_length[6]",
			"password_confirmation" => "required|min_length[6]|matches[userPassword]"
		];

		if (!$this->validate($rules))
		{
			$response = [
				"status" => 500,
				"message" => $this->validator->getErrors(),
				"error" => true,
				"data" => []
			];
		} 
		else
		{

			$user = new Users();
			$user = $user->where("userId", $userId)->first();

			if (!empty($user))
			{
				if ($this->users->set('userPassword', $userPassword)->where("userId", $userId)->update())
				{
					//Reset OTP to null
					$this->users->set('otp', null)->where("userId", $userId)->update();

					$response = [
						"status" => 200,
						"message" => 'Password Reset Successful',
						"error" => false,
						"data" => "Success"
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => 'Error updating password',
						"error" => true,
						"data" => "Failed"
					];
				}
			}
			else
			{
				$response = [
					"status" => 500,
					"message" => 'User does not exist',
					"error" => true,
					"data" => []
				];
			}
		}

		return $this->respondCreated($response);
	}

	/*

	public function approveAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$attendanceId = $this->request->getVar("attendanceId");
				
				$log = array('attendanceId' => $attendanceId, 'log' => "Attendance was approved by $userName on $now", 'createdDate' => $now);

				if($nextApprover && $nextApprover >= 1)
				{
					$this->attendance->set('nextApprover', $nextApprover)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();

					$this->logs->insert($log);
				}
				else
				{
					$setData = array(
						'approvedBy' => $userId,
						'nextApprover' => null,
						'status' => 'APPROVED'
					);

					$this->attendance->set($setData)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();

					$this->logs->insert($log);
				}
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Attendance updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function rejectAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$attendanceId = $this->request->getVar("attendanceId");
				$remarks = $this->request->getVar("remarks");

				$log = array('attendanceId' => $attendanceId, 'log' => "Attendance was rejected by $userName on $now with the remarks :: $remarks", 'createdDate' => $now);

				$setData = array(
					'approvedBy' => $userId,
					'nextApprover' => null,
					'status' => 'REJECTED',
					'remarks' => $remarks
				);

				$this->attendance->set($setData)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();
				$this->logs->insert($log);
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Attendance updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approveLaborAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$attendanceId = $this->request->getVar("attendanceId");
				$log = array('laborAttendanceId' => $attendanceId, 'log' => "Attendance was approved by $userName on $now", 'createdDate' => $now);

				if($nextApprover && $nextApprover >= 1)
				{
					$this->loborAttendance->set('nextApprover', $nextApprover)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();
					$this->logs->insert($log);
				}
				else
				{
					$setData = array(
						'approvedBy' => $userId,
						'nextApprover' => null,
						'status' => 'APPROVED'
					);

					$this->loborAttendance->set($setData)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();

					$this->logs->insert($log);
				}
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Labor Attendance updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function rejectLaborAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$attendanceId = $this->request->getVar("attendanceId");
				$remarks = $this->request->getVar("remarks");

				$log = array('laborAttendanceId' => $attendanceId, 'log' => "Attendance was rejected by $userName on $now with the remarks :: $remarks", 'createdDate' => $now);

				$setData = array(
					'approvedBy' => $userId,
					'nextApprover' => null,
					'status' => 'REJECTED',
					'remarks' => $remarks
				);

				$this->loborAttendance->set($setData)->where('attendanceId', $attendanceId)->where('nextApprover', $userId)->update();
				$this->logs->insert($log);
				//Data Here		
				
				$response = [
					"status" => 200,
					"message" => "Labor Attendance updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approveLeaves()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$leaveId = $this->request->getVar("leaveId");
				$log = array('leaveId' => $leaveId, 'log' => "Leave was approved by $userName on $now", 'createdDate' => $now);

				if($nextApprover && $nextApprover >= 1)
				{
					$this->leaves->set('nextApprover', $nextApprover)->where('leaveId', $leaveId)->where('nextApprover', $userId)->update();

					$this->logs->insert($log);
				}
				else
				{
					$setData = array(
						'approvedBy' => $userId,
						'nextApprover' => null,
						'status' => 'APPROVED'
					);

					$this->leaves->set($setData)->where('leaveId', $leaveId)->where('nextApprover', $userId)->update();
					$this->logs->insert($log);
				}
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Leaves updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function rejectLeaves()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$leaveId = $this->request->getVar("leaveId");
				$remarks = $this->request->getVar("remarks");

				$log = array('leaveId' => $leaveId, 'log' => "Leave was rejected by $userName on $now with the remarks :: $remarks", 'createdDate' => $now);

				$setData = array(
					'approvedBy' => $userId,
					'nextApprover' => null,
					'status' => 'REJECTED',
					'remarks' => $remarks
				);

				$this->leaves->set($setData)->where('leaveId', $leaveId)->where('nextApprover', $userId)->update();
				$this->logs->insert($log);
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Leaves updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approveExpenses()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$expenseId = $this->request->getVar("expenseId");
				$log = array('expenseId' => $expenseId, 'log' => "Expense was approved by $userName on $now", 'createdDate' => $now);

				if($nextApprover && $nextApprover >= 1)
				{
					$this->expense->set('nextApprover', $nextApprover)->where('expenseId', $expenseId)->where('nextApprover', $userId)->update();

					$this->logs->insert($log);
				}
				else
				{
					$setData = array(
						'approvedBy' => $userId,
						'nextApprover' => null,
						'status' => 'APPROVED'
					);

					$this->expense->set($setData)->where('expenseId', $expenseId)->where('nextApprover', $userId)->update();
					$this->logs->insert($log);
				}
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Expense updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function rejectExpenses()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$userName = $decoded_data->userinfo->empName;
				$nextApprover = $this->users->findById($userId)->reportTo;
				$now = date("Y-m-d H:i:s");

				//Data Here
				$expenseId = $this->request->getVar("expenseId");
				$remarks = $this->request->getVar("remarks");

				$log = array('expenseId' => $expenseId, 'log' => "Expense was rejected by $userName on $now with the remarks :: $remarks", 'createdDate' => $now);

				$setData = array(
					'approvedBy' => $userId,
					'nextApprover' => null,
					'status' => 'REJECTED',
					'remarks' => $remarks
				);

				$this->expense->set($setData)->where('expenseId', $expenseId)->where('nextApprover', $userId)->update();
				$this->logs->insert($log);
				//Data Here	
				
				$response = [
					"status" => 200,
					"message" => "Expense updated successfully",
					"error" => false,
					"data" => []
				];

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	

	public function listAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$limit = $offset = 0;

				if ($this->request->getVar("limit"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}

				if ($limit <= 0) {
					$limit = 10000;
				}

				if ($offset <= 0) {
					$offset = 0;
				}

				//Content Goes Here

				if ($limit >= 1 && !$offset)
				{
					$attendance = $this->attendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->limit($limit)->find();
				}
				else if($limit >= 1 && $offset >= 1)
				{
					$attendance = $this->attendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->limit($offset, $limit)->find();
				}
				else
				{
					$attendance = $this->attendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->findAll();
				}
				
				if($attendance)
				{
					
					$response = [
						"status" => 200,
						"message" => "Attendance Fetched successfully",
						"error" => false,
						"data" => $attendance
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No records found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listLaborAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$limit = $offset = 0;

				if ($this->request->getVar("limit"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}

				if ($limit <= 0) {
					$limit = 10000;
				}

				if ($offset <= 0) {
					$offset = 0;
				}

				//Content Goes Here

				if ($limit >= 1 && !$offset)
				{
					$attendance = $this->loborAttendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->limit($limit)->find();
				}
				else if($limit >= 1 && $offset >= 1)
				{
					$attendance = $this->loborAttendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->limit($offset, $limit)->find();
				}
				else
				{
					$attendance = $this->loborAttendance->orderBy('attendanceId', 'DESC')->where('userId', $userId)->findAll();
				}
				
				if($attendance)
				{
					
					$response = [
						"status" => 200,
						"message" => "Labor Attendance Fetched successfully",
						"error" => false,
						"data" => $attendance
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No records found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listExpenseCategories()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$categories = $this->expenseCategories->where('display !=', 'WEB')->findAll();
				
				if($categories)
				{
					$response = [
						"status" => 200,
						"message" => "Categories Fetched successfully",
						"error" => false,
						"data" => $categories
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No Categories found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listLeaveCategories()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$categories = $this->leaveCategories->findAll();
				
				if($categories)
				{
					$response = [
						"status" => 200,
						"message" => "Categories Fetched successfully",
						"error" => false,
						"data" => $categories
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No Categories found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listVehicles()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$vehicles = $this->vehicles->where('ownership', $userId)->findAll();
				
				if($vehicles)
				{
					$response = [
						"status" => 200,
						"message" => "Vehicles Fetched successfully",
						"error" => false,
						"data" => $vehicles
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No Vehicles found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function newAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$nextApprover = $decoded_data->userinfo->reportTo;
				//Content Goes Here

				$date = date("Y-m-d");
				$attendanceType = $this->request->getVar("attendanceType");
				$attendance = $this->request->getVar("attendance");
				$attendanceLatt = $this->request->getVar("attendanceLatt");
				$attendanceLong = $this->request->getVar("attendanceLong");
				$picture = $this->request->getVar("picture");
				$notes = $this->request->getVar("notes");
				$distanceFromHQ = 0;
				$status = "PENDING";
				$uploadFolder = "uploads/";

				$now = date("Y-m-d H:i:s");
				$settings = $this->settings->findById(1);
				$morningStart = $settings->morningAttendanceStart;
				$morningStart = date("Y-m-d ").$morningStart.":00";
				$morningEnd = $settings->morningAttendanceEnd;
				$morningEnd = date("Y-m-d ").$morningEnd.":00";

				$eveningStart = $settings->eveningAttendanceStart;
				$eveningStart = date("Y-m-d ").$eveningStart.":00";
				$eveningEnd = $settings->eveningAttendanceEnd;
				$eveningEnd = date("Y-m-d ").$eveningEnd.":00";

				if($now >= $morningStart && $now <= $morningEnd)
				{
					$attendanceType = "MORNING";
				}
				else if($now >= $eveningStart && $now <= $eveningEnd)
				{
					$attendanceType = "EVENING";
				}

				if($this->request->getVar("picture"))
				{
					$imageName = "attendance_".$userId."_".rand(1,1000).".jpg";
					if(file_exists($uploadFolder.$imageName))
					{
						$imageName = rand(1,1000)."_".$imageName;
					}

					file_put_contents($uploadFolder.$imageName, base64_decode($picture));
				}

				$attendanceData = array(
					'userId' => $userId,
					'date' => $date,
					'attendanceType' => $attendanceType,
					'attendance' => $attendance,
					'attendanceLatt' => $attendanceLatt,
					'attendanceLong' => $attendanceLong,
					'distanceFromHQ' => $distanceFromHQ,
					'picture' => $uploadFolder.$imageName,
					'notes' => $notes,
					'nextApprover' => $nextApprover
				);

				if($this->attendance->insert($attendanceData))
				{
					
					$response = [
						"status" => 200,
						"message" => "Attendance recorded successfully",
						"error" => false,
						"data" => []
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Error recording attendance",
						"error" => true,
						"data" => $this->attendance->errors()
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function newLaborAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$nextApprover = $decoded_data->userinfo->reportTo;

				//Content Goes Here

				$date = date("Y-m-d");
				$laborName = $this->request->getVar("laborName");
				$laborMobile = $this->request->getVar("laborMobile");
				$attendanceType = $this->request->getVar("attendanceType");
				$attendance = $this->request->getVar("attendance");
				$attendanceLatt = $this->request->getVar("attendanceLatt");
				$attendanceLong = $this->request->getVar("attendanceLong");
				$picture = $this->request->getVar("picture");
				$notes = $this->request->getVar("notes");
				$distanceFromHQ = 0;
				$status = "PENDING";
				$uploadFolder = "uploads/";

				$now = date("Y-m-d H:i:s");
				$settings = $this->settings->findById(1);
				$morningStart = $settings->morningAttendanceStart;
				$morningStart = date("Y-m-d ").$morningStart.":00";
				$morningEnd = $settings->morningAttendanceEnd;
				$morningEnd = date("Y-m-d ").$morningEnd.":00";

				$eveningStart = $settings->eveningAttendanceStart;
				$eveningStart = date("Y-m-d ").$eveningStart.":00";
				$eveningEnd = $settings->eveningAttendanceEnd;
				$eveningEnd = date("Y-m-d ").$eveningEnd.":00";

				if($now >= $morningStart && $now <= $morningEnd)
				{
					$attendanceType = "MORNING";
				}
				else if($now >= $eveningStart && $now <= $eveningEnd)
				{
					$attendanceType = "EVENING";
				}

				if($this->request->getVar("picture"))
				{
					$imageName = "attendance_".$userId."_".rand(1,1000).".jpg";
					if(file_exists($uploadFolder.$imageName))
					{
						$imageName = rand(1,1000)."_".$imageName;
					}

					file_put_contents($uploadFolder.$imageName, base64_decode($picture));
				}

				$attendanceData = array(
					'userId' => $userId,
					'laborName' => $laborName,
					'laborMobile' => $laborMobile,
					'date' => $date,
					'attendanceType' => $attendanceType,
					'attendance' => $attendance,
					'attendanceLatt' => $attendanceLatt,
					'attendanceLong' => $attendanceLong,
					'distanceFromHQ' => $distanceFromHQ,
					'picture' => $uploadFolder.$imageName,
					'notes' => $notes,
					'status' => $status,
					'nextApprover' => $nextApprover
				);

				if($this->loborAttendance->insert($attendanceData))
				{
					
					$response = [
						"status" => 200,
						"message" => "Labor Attendance recorded successfully",
						"error" => false,
						"data" => []
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Error recording attendance",
						"error" => true,
						"data" => $this->loborAttendance->errors()
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listExpenses()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$limit = $offset = 0;

				if ($this->request->getVar("limit"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}

				if ($limit <= 0) {
					$limit = 10000;
				}

				if ($offset <= 0) {
					$offset = 0;
				}

				//Content Goes Here

				if ($limit >= 1 && !$offset)
				{
					$expenses = $this->expense->orderBy('expenseId', 'DESC')->where('userId', $userId)->limit($limit)->find();
				}
				else if($limit >= 1 && $offset >= 1)
				{
					$expenses = $this->expense->orderBy('expenseId', 'DESC')->where('userId', $userId)->limit($offset, $limit)->find();
				}
				else
				{
					$expenses = $this->expense->orderBy('expenseId', 'DESC')->where('userId', $userId)->findAll();
				}
				
				if($expenses)
				{


					foreach($expenses as $expense)
					{
						$expense->expenseCategory = $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory;

						if($expense->picture)
						{
							$expense->picture = site_url($expense->picture);
						}

						if($expense->vehicleId >= 1)
						{
							$expense->vehicleRegNo = $this->vehicles->findById($expense->vehicleId)->vehicleRegNo;
						}
						else
						{
							$expense->vehicleRegNo = null;
						}

						if($expense->status != "PENDING")
						{
							$expense->approvedBy = $this->users->findById($expense->approvedBy)->empName;
						}
					}
					
					$response = [
						"status" => 200,
						"message" => "Expenses Fetched successfully",
						"error" => false,
						"data" => $expenses
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No records found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function newExpense()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$nextApprover = $decoded_data->userinfo->reportTo;

				//Content Goes Here

				$expenseDate = date("Y-m-d");
				$expenseCategoryId = $this->request->getVar("expenseCategoryId");
				$expenseAmount = $this->request->getVar("expenseAmount");
				$vehicleId = $this->request->getVar("vehicleId");
				$movementFrom = $this->request->getVar("movementFrom");
				$movementTo = $this->request->getVar("movementTo");
				$meterReadingStart = $this->request->getVar("meterReadingStart");
				$meterReadingEnd = $this->request->getVar("meterReadingEnd");
				$totalKMTravelled = (int)$meterReadingEnd - (int)$meterReadingStart;
				$status = "PENDING";
				$imageName = null;

				//New Picture Upload
				$picture = $this->request->getVar("picture");
				$uploadFolder = "uploads/";

				if($this->request->getVar("picture"))
				{
					$imageName = "expense_".$userId."_".rand(1,1000).".jpg";
					if(file_exists($uploadFolder.$imageName))
					{
						$imageName = rand(1,1000)."_".$imageName;
					}

					file_put_contents($uploadFolder.$imageName, base64_decode($picture));
				}
				//New Picture Upload

				$data = array(
					'userId' => $userId,
					'expenseDate' => $expenseDate,
					'expenseCategoryId' => $expenseCategoryId,
					'expenseAmount' => $expenseAmount,
					'vehicleId' => $vehicleId,
					'movementFrom' => $movementFrom,
					'movementTo' => $movementTo,
					'meterReadingStart' => $meterReadingStart,
					'meterReadingEnd' => $meterReadingEnd,
					'totalKMTravelled' => $totalKMTravelled,
					'picture' => $uploadFolder.$imageName,
					'status' => $status,
					'nextApprover' => $nextApprover,
				);

				if($this->expense->insert($data))
				{
					$response = [
						"status" => 200,
						"message" => "Expense recorded successfully",
						"error" => false,
						"data" => []
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Error recording expense",
						"error" => true,
						"data" => $this->attendance->errors()
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function listLeaves()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$limit = $offset = 0;

				if ($this->request->getVar("limit"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}

				if ($limit <= 0) {
					$limit = 10000;
				}

				if ($offset <= 0) {
					$offset = 0;
				}

				//Content Goes Here

				if ($limit >= 1 && !$offset)
				{
					$leaves = $this->leaves->orderBy('leaveId', 'DESC')->where('userId', $userId)->limit($limit)->find();
				}
				else if($limit >= 1 && $offset >= 1)
				{
					$leaves = $this->leaves->orderBy('leaveId', 'DESC')->where('userId', $userId)->limit($offset, $limit)->find();
				}
				else
				{
					$leaves = $this->leaves->orderBy('leaveId', 'DESC')->where('userId', $userId)->findAll();
				}
				
				if($leaves)
				{


					foreach($leaves as $leave)
					{
						$leave->leaveCategory = $this->leaveCategories->findById($leave->leaveCategoryId)->leaveCategory;

						if($leave->status != "PENDING")
						{
							$leave->approvedBy = $this->users->findById($leave->approvedBy)->empName;
						}
					}
					
					$response = [
						"status" => 200,
						"message" => "Leaved Fetched successfully",
						"error" => false,
						"data" => $leaves
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "No records found",
						"error" => false,
						"data" => []
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function newLeave()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$nextApprover = $decoded_data->userinfo->reportTo;

				//Content Goes Here

				$fromDate = $this->request->getVar("fromDate");
				$toDate = $this->request->getVar("toDate");
				$leaveCategoryId = $this->request->getVar("leaveCategoryId");
				$status = "PENDING";
				

				$data = array(
					'userId' => $userId,
					'fromDate' => $fromDate,
					'toDate' => $toDate,
					'leaveCategoryId' => $leaveCategoryId,
					'status' => $status,
					'nextApprover' => $nextApprover
				);

				if($this->leaves->insert($data))
				{
					$response = [
						"status" => 200,
						"message" => "Leave recorded successfully",
						"error" => false,
						"data" => []
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Error recording leaves",
						"error" => true,
						"data" => $this->attendance->errors()
					];
				}

				//Content Goes Here
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function checkAttendance()
	{
		$now = date("H");
		$settings = $this->settings->findById(1);
		$morningStart = $settings->morningAttendanceStart;
		$morningStart = date("Y-m-d ").$morningStart.":00";
		$morningStart = date("H", strtotime($morningStart));
		$morningEnd = $settings->morningAttendanceEnd;
		$morningEnd = date("Y-m-d ").$morningEnd.":00";
		$morningEnd = date("H", strtotime($morningEnd));

		$eveningStart = $settings->eveningAttendanceStart;
		$eveningStart = date("Y-m-d ").$eveningStart.":00";
		$eveningStart = date("H", strtotime($eveningStart));
		$eveningEnd = $settings->eveningAttendanceEnd;
		$eveningEnd = date("Y-m-d ").$eveningEnd.":00";
		$eveningEnd = date("H", strtotime($eveningEnd));

		if($now >= $morningStart && $now <= $morningEnd)
		{
			$data = array('status' => 'accept', 'attendanceTye' => 'MORNING');
			$response = [
				"status" => 200,
				"message" => "ACCEPT",
				"error" => true,
				"data" => $data
			];
		}
		else if($now >= $eveningStart && $now <= $eveningEnd)
		{
			$data = array('status' => 'accept', 'attendanceTye' => 'EVENING');
			$response = [
				"status" => 200,
				"message" => "ACCEPT",
				"error" => true,
				"data" => $data
			];
		}
		else
		{
			$response = [
				"status" => 500,
				"message" => "REJECT",
				"error" => true,
				"data" => "Sorry, the time to report Attendance is over"
			];
		}

		return $this->respondCreated($response);

	}

	public function approvalsAttendance()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				if ($this->request->getVar("offset"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}
				else
				{
					$limit = 20;
					$offset = 0;
				}

				if ($limit <= 0)
				{
					$limit = 20;
				}
		
				if ($offset <= 0)
				{
					$offset = 0;
				}

				$attendanceList = $this->attendance->where('nextApprover', $userId)->limit($limit, $offset)->find();
				$total = $this->attendance->select('COUNT(attendanceId) AS total')->where('nextApprover', $userId)->first()->total;

				foreach($attendanceList as $attendance)
				{
					$headQuarterId = $this->users->findById($attendance->userId)->headQuarterId;
					$attendance->userName = $this->users->findById($attendance->userId)->empName;

					if($this->users->findById($attendance->userId)->headQuarterId)
					{
					$distance = 0;
					$headQuarterLatt = $this->headquarters->findById($headQuarterId)->headQuarterLatt;
					$headQuarterLong = $this->headquarters->findById($headQuarterId)->headQuarterLong;

					$coordinate1 = new Coordinate($headQuarterLatt, $headQuarterLong); // Mauna Kea Summit
					$coordinate2 = new Coordinate($attendance->attendanceLatt, $attendance->attendanceLong); // Haleakala Summit

					$calculator = new Vincenty();
					$distance = $calculator->getDistance($coordinate1, $coordinate2);
					$distance = round(($distance/1000),2);

					$attendance->distanceFromHQ =  $distance. " Km";
					
					}
					else
					{
						$attendance->distanceFromHQ = "-";
					}

					if($attendance->picture)
					{

						if(strpos($attendance->picture, "uploads/") !== false)
						{
							$attendance->picture = site_url($attendance->picture);
						}
						else
						{
							$attendance->picture = site_url("uploads/".$attendance->picture);
						}
						
					}

				}

				$data = array(
					'total' => $total,
					'attendanceList' => $attendanceList
				);

				$response = [
					"status" => 200,
					"message" => "Approvals list fetched successfully",
					"error" => false,
					"data" => $data
				];


			}
		}catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approvalsExpense()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				if ($this->request->getVar("offset"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}
				else
				{
					$limit = 20;
					$offset = 0;
				}

				if ($limit <= 0)
				{
					$limit = 20;
				}
		
				if ($offset <= 0)
				{
					$offset = 0;
				}

				
				$total = $this->expense->select('COUNT(expenseId) AS total')->where('nextApprover', $userId)->first()->total;

				$expensesList = $this->expense->where('nextApprover', $userId)->limit($limit, $offset)->find();

				foreach($expensesList as $expense)
				{
					$headQuarterId = $this->users->findById($expense->userId)->headQuarterId;
					$expense->userName = $this->users->findById($expense->userId)->empName;

					if($this->expenseCategories->findById($expense->expenseCategoryId))
					{
						$expense->expenseCategoryId = $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory;
					}
					else
					{
						$expense->expenseCategoryId = "NA";
					}
					

					if($expense->vehicleId >= 1)
					{
						$expense->vehicleId = $this->vehicles->findById($expense->vehicleId)->vehicleRegNo;
					}
				}

				$data = array(
					'total' => $total,
					'expenseList' => $expensesList
				);

				$response = [
					"status" => 200,
					"message" => "Approvals list fetched successfully",
					"error" => false,
					"data" => $data
				];


			}
		}catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approvalsLabor()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				if ($this->request->getVar("offset"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}
				else
				{
					$limit = 20;
					$offset = 0;
				}

				if ($limit <= 0)
				{
					$limit = 20;
				}
		
				if ($offset <= 0)
				{
					$offset = 0;
				}

				$laborAttendanceList = $this->loborAttendance->where('nextApprover', $userId)->limit($limit, $offset)->find();
				$total = $this->loborAttendance->select('COUNT(attendanceId) AS total')->where('nextApprover', $userId)->first()->total;

				foreach($laborAttendanceList as $attendance)
				{
					$headQuarterId = $this->users->findById($attendance->userId)->headQuarterId;
					$attendance->userName = $this->users->findById($attendance->userId)->empName;

					if($this->users->findById($attendance->userId)->headQuarterId)
					{
					$distance = 0;
					$headQuarterLatt = $this->headquarters->findById($headQuarterId)->headQuarterLatt;
					$headQuarterLong = $this->headquarters->findById($headQuarterId)->headQuarterLong;

					$coordinate1 = new Coordinate($headQuarterLatt, $headQuarterLong); // Mauna Kea Summit
					$coordinate2 = new Coordinate($attendance->attendanceLatt, $attendance->attendanceLong); // Haleakala Summit

					$calculator = new Vincenty();
					$distance = $calculator->getDistance($coordinate1, $coordinate2);
					$distance = round(($distance/1000),2);

					$attendance->distanceFromHQ =  $distance. " Km";
					
					}
					else
					{
						$attendance->distanceFromHQ = "-";
					}

					if($attendance->picture)
					{
						if(strpos($attendance->picture, "uploads/") !== false)
						{
							$attendance->picture = site_url($attendance->picture);
						}
						else
						{
							$attendance->picture = site_url("uploads/".$attendance->picture);
						}
					}

				}

				$data = array(
					'total' => $total,
					'attendanceList' => $laborAttendanceList
				);

				$response = [
					"status" => 200,
					"message" => "Approvals list fetched successfully",
					"error" => false,
					"data" => $data
				];


			}
		}catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approvalsLeaves()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				if ($this->request->getVar("offset"))
				{
					$limit = esc(intval($this->request->getVar("limit")));
					$offset = esc(intval($this->request->getVar("offset")));
				}
				else
				{
					$limit = 20;
					$offset = 0;
				}

				if ($limit <= 0)
				{
					$limit = 20;
				}
		
				if ($offset <= 0)
				{
					$offset = 0;
				}

				$leavesList = $this->leaves->where('nextApprover', $userId)->limit($limit, $offset)->find();
				$total = $this->leaves->select('COUNT(leaveId) AS total')->where('nextApprover', $userId)->first()->total;

				foreach($leavesList as $leave)
				{
					$leave->userName = $this->users->findById($leave->userId)->empName;
					if($this->leaveCategories->findById($leave->leaveCategoryId))
					{
						$leave->leaveCategoryId = $this->leaveCategories->findById($leave->leaveCategoryId)->leaveCategory;
					}
					else
					{
						$leave->leaveCategoryId = "NA";
					}
				}

				$data = array(
					'total' => $total,
					'leavesList' => $leavesList
				);

				$response = [
					"status" => 200,
					"message" => "Approvals list fetched successfully",
					"error" => false,
					"data" => $data
				];


			}
		}catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approvals()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$attendanceList = $this->attendance->where('nextApprover', $userId)->find();
				$expensesList = $this->expense->where('nextApprover', $userId)->find();
				$laborAttendanceList = $this->loborAttendance->where('nextApprover', $userId)->find();
				$leavesList = $this->leaves->where('nextApprover', $userId)->find();

				foreach($attendanceList as $attendance)
				{
					$headQuarterId = $this->users->findById($attendance->userId)->headQuarterId;
					$attendance->userName = $this->users->findById($attendance->userId)->empName;

					if($this->users->findById($attendance->userId)->headQuarterId)
					{
					$distance = 0;
					$headQuarterLatt = $this->headquarters->findById($headQuarterId)->headQuarterLatt;
					$headQuarterLong = $this->headquarters->findById($headQuarterId)->headQuarterLong;

					$coordinate1 = new Coordinate($headQuarterLatt, $headQuarterLong); // Mauna Kea Summit
					$coordinate2 = new Coordinate($attendance->attendanceLatt, $attendance->attendanceLong); // Haleakala Summit

					$calculator = new Vincenty();
					$distance = $calculator->getDistance($coordinate1, $coordinate2);
					$distance = round(($distance/1000),2);

					$attendance->distanceFromHQ =  $distance. " Km";
					
					}
					else
					{
						$attendance->distanceFromHQ = "-";
					}

					if($attendance->picture)
					{
						$attendance->picture = site_url($attendance->picture);
					}

				}

				foreach($expensesList as $expense)
				{
					$headQuarterId = $this->users->findById($expense->userId)->headQuarterId;
					$expense->userName = $this->users->findById($expense->userId)->empName;
					$expense->expenseCategoryId = $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory;

					if($expense->vehicleId >= 1)
					{
						$expense->vehicleId = $this->vehicles->findById($expense->vehicleId)->vehicleRegNo;
					}
				}

				foreach($laborAttendanceList as $attendance)
				{
					$headQuarterId = $this->users->findById($attendance->userId)->headQuarterId;
					$attendance->userName = $this->users->findById($attendance->userId)->empName;

					if($this->users->findById($attendance->userId)->headQuarterId)
					{
					$distance = 0;
					$headQuarterLatt = $this->headquarters->findById($headQuarterId)->headQuarterLatt;
					$headQuarterLong = $this->headquarters->findById($headQuarterId)->headQuarterLong;

					$coordinate1 = new Coordinate($headQuarterLatt, $headQuarterLong); // Mauna Kea Summit
					$coordinate2 = new Coordinate($attendance->attendanceLatt, $attendance->attendanceLong); // Haleakala Summit

					$calculator = new Vincenty();
					$distance = $calculator->getDistance($coordinate1, $coordinate2);
					$distance = round(($distance/1000),2);

					$attendance->distanceFromHQ =  $distance. " Km";
					
					}
					else
					{
						$attendance->distanceFromHQ = "-";
					}

					if($attendance->picture)
					{
						$attendance->picture = site_url($attendance->picture);
					}

				}

				foreach($leavesList as $leave)
				{
					$leave->userName = $this->users->findById($leave->userId)->empName;
					$leave->leaveCategoryId = $this->leaveCategories->findById($leave->leaveCategoryId)->leaveCategory;
				}

				$data = array(
					'attendanceList' => $attendanceList,
                    'expensesList' => $expensesList,
                    'laborAttendanceList' => $laborAttendanceList,
                    'leavesList' => $leavesList
				);

				$response = [
					"status" => 200,
					"message" => "Approvals list updated successfully",
					"error" => false,
					"data" => $data
				];


			}
		}catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function updateProfile()
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');

		try
		{
			if (isset($auth))
			{
				$token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

				$dob = $this->request->getVar("dob");
				$doj = $this->request->getVar("doj");
				$highestQualification = $this->request->getVar("highestQualification");
				$photo = $this->request->getVar("photo");
				$bloodGroup = $this->request->getVar("bloodGroup");
				$motherName = $this->request->getVar("motherName");
				$fatherName = $this->request->getVar("fatherName");
				$uid = $this->request->getVar("uid");
				$pan = $this->request->getVar("pan");
				$dl = $this->request->getVar("dl");
				$personalInsurance = $this->request->getVar("personalInsurance");
				$healthInsurance = $this->request->getVar("healthInsurance");
				$accidentalInsurance = $this->request->getVar("accidentalInsurance");
				$marritalStatus = $this->request->getVar("marritalStatus");
				$childrens = $this->request->getVar("childrens");
				$height = $this->request->getVar("height");
				$weight = $this->request->getVar("weight");
				$permanentAddress = $this->request->getVar("permanentAddress");
				$presentAddress = $this->request->getVar("presentAddress");

				$uploadFolder = "uploads/";

				if(strpos($this->request->getVar("photo"), "uploads/") !== false)
				{
					$imageName = null;
				}
				else
				{
					$imageName = "profile_".$userId."_".rand(1,1000).".jpg";
					if(file_exists($uploadFolder.$imageName))
					{
						$imageName = rand(1,1000)."_".$imageName;
					}

					file_put_contents($uploadFolder.$imageName, base64_decode($photo));
				}

				if($imageName == null)
				{
					$updateArray = array(
						'dob' => $dob,
						'doj' => $doj,
						'bloodGroup' => $bloodGroup,
						'motherName' => $motherName,
						'highestQualification' => $highestQualification,
						'fatherName' => $fatherName,
						'uid' => $uid,
						'pan' => $pan,
						'dl' => $dl,
						'personalInsurance' => $personalInsurance,
						'healthInsurance' => $healthInsurance,
						'accidentalInsurance' => $accidentalInsurance,
						'marritalStatus' => $marritalStatus,
						'childrens' => $childrens,
						'height' => $height,
						'weight' => $weight,
						'permanentAddress' => $permanentAddress,
						'presentAddress' => $presentAddress
					);
				}
				else
				{
					$updateArray = array(
						'dob' => $dob,
						'doj' => $doj,
						'photo' => $uploadFolder.$imageName,
						'bloodGroup' => $bloodGroup,
						'motherName' => $motherName,
						'highestQualification' => $highestQualification,
						'fatherName' => $fatherName,
						'uid' => $uid,
						'pan' => $pan,
						'dl' => $dl,
						'personalInsurance' => $personalInsurance,
						'healthInsurance' => $healthInsurance,
						'accidentalInsurance' => $accidentalInsurance,
						'marritalStatus' => $marritalStatus,
						'childrens' => $childrens,
						'height' => $height,
						'weight' => $weight,
						'permanentAddress' => $permanentAddress,
						'presentAddress' => $presentAddress
					);
				}

				

				if($this->users->set($updateArray)->where('userId', $userId)->update())
				{
					$user = $this->users->findById($userId);

					if($user->projectId)
					{
						$projectName = $this->projects->findById($user->projectId) ? $this->projects->findById($user->projectId)->projectName: "-";
						$user->projectId = $projectName;
					}

					if($user->photo)
					{
						$user->photo = site_url($user->photo);
					}

					$response = [
						"status" => 200,
						"message" => "Profile updated successfully",
						"error" => false,
						"data" => $user
					];
				}
				else
				{
					$response = [
						"status" => 500,
						"message" => "Error updating Profile",
						"error" => true,
						"data" => $this->users->errors()
					];
				}
				

			}
			else
			{

				$response = [
					"status" => 500,
					"message" => "Token is required",
					"error" => true,
					"data" => []
				];
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	*/
}
