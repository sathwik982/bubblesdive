<?php

namespace App\Models;
class Projects extends \CodeIgniter\Model
{
    
    protected $table = 'projects';
    protected $primaryKey = 'projectId';
    protected $allowedFields = ['projectName', 'projectLocation', 'headQuarterId', 'createdDate', 'lastModifiedDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'projectName' => 'required',
        'projectLocation' => 'required'
    ];

    protected $validationMessages = [
        'projectName' => [
            'required' => 'Project Name is required'
        ],
        'projectLocation' => [
            'required' => 'Project Location is required'
        ]
    ];

    public function findById($projectId)
    {
        return $this->where('projectId', $projectId)->first();
    }
}
?>