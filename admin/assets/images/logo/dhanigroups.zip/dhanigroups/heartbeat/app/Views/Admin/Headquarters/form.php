<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="headQuarterName">Headquarter Name <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="headQuarterName" name="headQuarterName" required placeholder="Headquarter Name" value="<?= old('headQuarterName', $data->headQuarterName); ?>">
        <div class="invalid-feedback">Please enter the Headquarter Name</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="headQuarterLatt">Headquarter Latitude <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="headQuarterLatt" name="headQuarterLatt" required placeholder="Headquarter Latitude" value="<?= old('headQuarterLatt', $data->headQuarterLatt); ?>">
        <div class="invalid-feedback">Please enter the Headquarter Latitude</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="headQuarterLong">Headquarter Longitude <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="headQuarterLong" name="headQuarterLong" required placeholder="Headquarter Longitude" value="<?= old('headQuarterLong', $data->headQuarterLong); ?>">
        <div class="invalid-feedback">Please enter the Headquarter Longitude</div>
    </div>
</div>