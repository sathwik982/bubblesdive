<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>Dashboard<?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0">Welcome !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item active">Dashboard</li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<div class="row">
   <div class="col-xl-4">
      <div class="card bg-primary">
         <div class="card-body">
            <div class="text-center py-3">
               <ul class="bg-bubbles ps-0">
                  <li><i class="bx bx-grid-alt font-size-24"></i></li>
                  <li><i class="bx bx-tachometer font-size-24"></i></li>
                  <li><i class="bx bx-store font-size-24"></i></li>
                  <li><i class="bx bx-cube font-size-24"></i></li>
                  <li><i class="bx bx-cylinder font-size-24"></i></li>
                  <li><i class="bx bx-command font-size-24"></i></li>
                  <li><i class="bx bx-hourglass font-size-24"></i></li>
                  <li><i class="bx bx-pie-chart-alt font-size-24"></i></li>
                  <li><i class="bx bx-coffee font-size-24"></i></li>
                  <li><i class="bx bx-polygon font-size-24"></i></li>
               </ul>
               <div class="main-wid position-relative pt-2 pb-3">
                  <h3 class="text-white">Dhani Groups</h3>
                  <h3 class="text-white mb-0"> Welcome Back, <?= session()->get('employeeName'); ?>!</h3>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col-xl-8">
      <div class="row">
         <div class="col-lg-3 col-md-6">
         <a href="<?= site_url("attendance"); ?>">
            <div class="card" style="background-color:#164a77;">
               <div class="card-body">
                  <div class="avatar">
                     <span class="avatar-title bg-soft-primary rounded">
                     <i class="bx bx-time-five text-white font-size-24"></i>
                     </span>
                  </div>
                  <p class="text-white mt-4 mb-0">Total Attendances</p>
                  <h4 class="text-white mt-1 mb-0">
                  <?php
                  $successCount = 0; 
                  foreach ($attendance as $list) 
                  {
                  if($list->status == "APPROVED") 
                  {
                  $successCount++;
                  }
                  }
                  echo $successCount; 
                  ?>
                  </h4>
               </div>
            </div>
            </a>
         </div>
         <div class="col-lg-3 col-md-6">
         <a href="<?= site_url("labourattendance"); ?>">
            <div class="card" style="background-color:#1F4D76;">
               <div class="card-body">
                  <div class="avatar">
                     <span class="avatar-title bg-soft-primary rounded">
                     <i class="bx bx-file text-white font-size-24"></i>
                     </span>
                  </div>
                  <p class="text-white mt-1 mb-0">Total Labour Attendances</p>
                  <h4 class="text-white mt-1 mb-0">
                  <?php
                  $successCount = 0; 
                  foreach ($labourAttendance as $list) 
                  {
                  if($list->status == "APPROVED") 
                  {
                  $successCount++;
                  }
                  }
                  echo $successCount; 
                  ?>
                  </h4>
               </div>
            </div>
            </a>
         </div>
         <div class="col-lg-3 col-md-6">
         <a href="<?= site_url("expenses"); ?>">
            <div class="card" style="background-color:#2A5378;">
               <div class="card-body">
                  <div class="avatar">
                     <span class="avatar-title bg-soft-primary rounded">
                     <i class="bx bx-pie-chart-alt-2 text-white font-size-24"></i>
                     </span>
                  </div>
                  <p class="text-white mt-4 mb-0">Total Expenses</p>
                  <h4 class="text-white mt-1 mb-0">
                  <?php
                  $successCount = 0; 
                  foreach ($expense as $list) 
                  {
                  if($list->status == "APPROVED") 
                  {
                  $successCount++;
                  }
                  }
                  echo $successCount; 
                  ?> 
                  </h4>
               </div>
            </div>
          </a>
         </div>
         <div class="col-lg-3 col-md-6">
         <a href="<?= site_url("leaves"); ?>">
            <div class="card" style="background-color:#395874;">
               <div class="card-body">
                  <div class="avatar">
                     <span class="avatar-title bg-soft-primary rounded">
                     <i class="bx bx-add-to-queue text-white font-size-24"></i>
                     </span>
                  </div>
                  <p class="text-white mt-4 mb-0">Total Leaves</p>
                  <h4 class="text-white mt-1 mb-0">
                  <?php
                  $successCount = 0; 
                  foreach ($leaves as $leave) 
                  {
                  if($leave->status == "APPROVED") 
                  {
                  $successCount++;
                  }
                  }
                  echo $successCount; 
                  ?>
                  </h4>
               </div>
            </div>
         </div>
         </a>
      </div>
   </div>
</div>
<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <div class="d-flex flex-wrap align-items-center mb-3">
               <h5 class="card-title mb-0">Trends</h5>
            </div>
            <div class="row align-items-center">
               <div class="col-xl-12">
                  <div>
                     <div id="sales-statistics" data-colors='["#eff1f3","#eff1f3","#eff1f3","#eff1f3","#33a186","#3980c0","#eff1f3","#eff1f3","#eff1f3", "#eff1f3"]' class="apex-chart"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="<?= site_url(); ?>assets/js/pages/chartjs.js"></script>
<script>
   var alterationsTrendData = {
      chart: {
         height: 435,
         type: 'area',
         zoom: {
            enabled: true
         },
         toolbar: {
            show: true,
         }
      },
      dataLabels: {
         enabled: true
      },
      stroke: {
         curve: 'smooth'
      },
      series: [{
         name: "Total Attendances",
         data: <?= json_encode($data["attendanceTrend"]) ?>
      },
      {
         name: "Total Labour Attendances",
         data: <?= json_encode($data["labourAttendanceTrend"]) ?>
      },
      {
         name: "Total Expenses",
         data: <?= json_encode($data["expensesTrend"]) ?>
      },
      {
         name: "Total Leaves",
         data: <?= json_encode($data["leavesTrend"]) ?>
      }],
      grid: {
         row: {
            colors: ['#f1f2f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
         },
      },
   }
   
   var alterationsTrendGraph = new ApexCharts(document.querySelector("#sales-statistics"), alterationsTrendData);
   alterationsTrendGraph.render();
</script>
<?= $this->endSection() ?>
