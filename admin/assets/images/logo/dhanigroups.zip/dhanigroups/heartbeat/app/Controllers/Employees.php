<?php

namespace App\Controllers;
use App\Entities\Entity;
use App\Models\Profile;
use Dompdf\Dompdf;
use \Hermawan\DataTables\DataTable;


class Employees extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Users();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Employees/');
        define('ITEM','Employee');
        define('ITEMS','Employees');
        define('DBTABLE','users');
        define('VARIABLE','data');
        define('ROUTE','employees');

        session()->set('activate', "employees");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('users.userId, users.employeeId, users.employeeName, users.mobileNumber, users.userStatus, users.userRole, profile.reportTo')->join('profile', 'profile.userId = users.userId','left');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->userId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a href="'.site_url(ROUTE."/view/".$row->userId).'" class="text-primary"><i class="bx bx-show-alt" style="font-size:20px;"></i></a>
                    <a href="'.site_url(ROUTE."/download/".$row->userId).'" class="text-primary"><i class="bx bxs-file-pdf" style="font-size:20px;"></i></a>
                   ';
        })
        ->edit('userStatus', function($row)
        {
            if($row->userStatus == "ACTIVE")
            {
                return "<span class='badge badge-soft-success font-size-12'>" .$row->userStatus. "</span>";
            }
            else
            {
                return "<span class='badge badge-soft-danger font-size-12'>" .$row->userStatus. "</span>";
            }
        })
		->edit('reportTo', function($row)
        {
            $reportTo = $this->users->findById($row->reportTo) ? $this->users->findById($row->reportTo )->employeeName: "-";
            return $reportTo;
        })
		
       //->hide('userId')
        ->toJson();
    }

    public function download($userId)
    {

        $data = $this->check($userId);
        $profile = $this->profile->where('userId', $userId)->first();

		$profile->dateOfBirth = date("d, M, Y", strtotime($profile->dateOfBirth));

		$profile->dateOfJoining = date("d, M, Y", strtotime($profile->dateOfJoining));
		
        $profile->designationId = $this->designations->findById($profile->designationId) ? $this->designations->findById($profile->designationId)->designation: "NA";

        $profile->headquarterId = $this->headquarters->findById($profile->headquarterId) ? $this->headquarters->findById($profile->headquarterId)->headQuarterName: "NA";

        $profile->highestQualification = $this->qualifications->findById($profile->highestQualification) ? $this->qualifications->findById($profile->highestQualification)->qualificationName: "NA";

        $profile->projectId = $this->projects->findById($profile->projectId) ? $this->projects->findById
        ($profile->projectId)->projectName: "NA";

        $profile->profilePicture = site_url($profile->profilePicture);

        $html = '<!DOCTYPE html>
        <html lang="en">
        <head>
        <title>Document</title>
        <style type="text/css">
        @page {
            margin: 0;
        }    
        body
        {
            font-family: Helvetica;            
        }
        th
        {
            font-size:12px;
            font-weight: bolder;
            border:1px solid #000000;
            padding:5px;
        }
        .tdproduct
        {
            font-size:12px;
            border:1px solid #000000;
            padding:5px 5px; 5px 8px;
        }
    </style>
    </head>
    <body>
    

    <table cellspacing="0" cellpadding="0" align="center" border="0" width="90%">
    <tr>
        <td>
            
            <table cellspacing="0" cellpadding="0" align="center" border="0" width="100%">
            <tr>
                <td>
                    <!-- Top -->
                    <table cellspacing="0" cellpadding="10" align="center" border="0" width="100%">
                    <tr>
							<td colspan="3" style="height: 40px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:40px;" /></td>
						</tr>
				<tr>
					<td valign="top">
						
						<table cellspacing="0" cellpadding="0" align="center" border="0" width="100%">
						<tr>
							<td colspan="3" style="font-size:25px; font-weight: bolder;">'.$data->employeeName.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 40px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:40px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="150" style="font-size:12px; font-weight: bolder;">Employee Name</td>
							<td style="font-size:12px; width:20px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$data->employeeName.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Employee ID#</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$data->employeeId.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Highesh Qualification</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->highestQualification.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Blood Group</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->bloodGroup.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Date of Birth</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->dateOfBirth.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Date of Joining</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->dateOfJoining.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Salary</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->salary.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Designation</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->designationId.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Project</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->projectId.'</td>
						</tr>
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Headquarter</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->headquarterId.'</td>
						</tr>
						</table>

					</td>
					<td width="40%" valign="top"><img width="100%" src="'.$profile->profilePicture.'" /></td>
				</tr>
				</table>
			</td>
		</tr>
        <tr>
            <td><hr></td>
        </tr>
		<tr>
			<td style="padding:10px;">
				<!-- Bottom -->
				<table cellspacing="0" cellpadding="0" align="center" border="0" width="100%">
				<tr>
					<td>
						
						<!-- Left Area -->
						<table cellspacing="0" cellpadding="0" align="center" border="0" width="100%">
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Father Name</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->fatherName.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Mother Name</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->motherName.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Present Address</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->presentAddress.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Permanent Address</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->permanentAddess.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Adhaar Number</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->adhaarNumber.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Pan Number</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->panNumber.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Driving License Number</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->drivingLicenseNumber.'</td>
						</tr>
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">ESIC Number</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->esicNumber.'</td>
						</tr>
						</table>
						<!-- Left Area -->

					</td>
					<td>
						
						<!-- Right Area -->
						<table cellspacing="0" cellpadding="0" align="center" border="0" width="100%">
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Personal Insurance</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->personalInsurance.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Health Insurance</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->healthInsurance.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Accidental Insurance</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->accidentalInsurance.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Martial Status</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->martialStatus.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">No of Children</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->noOfChildren.'</td>
						</tr>
						<!-- Gap -->
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Height</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->height.'</td>
						</tr>
						<tr>
							<td colspan="3" style="height: 10px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFyGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDIgNzkuMTY0NDYwLCAyMDIwLzA1LzEyLTE2OjA0OjE3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0xMS0yMVQwODo0MTo0MCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDplOGRhYTk0My1hYzZiLWQwNGYtYmQ5MS1iYjM3NGVkNWYzODgiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo1ZTI0NWU1Yy1jOWM5LTdhNDAtYTExYy03OWRhNDhjOWZhMDYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ODQyOGVjZS00NjkwLWJiNGItYWVkZC0wOTU3ZGU2MzE0OTEiIHN0RXZ0OndoZW49IjIwMjItMTEtMjFUMDg6NDE6NDArMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZThkYWE5NDMtYWM2Yi1kMDRmLWJkOTEtYmIzNzRlZDVmMzg4IiBzdEV2dDp3aGVuPSIyMDIyLTExLTIxVDA4OjQxOjQwKzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjEuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+jFKnmQAAAA1JREFUCJlj+P//PwMACPwC/oXNqzQAAAAASUVORK5CYII=" style="display: block; height:10px;" /></td>
						</tr>
						<!-- Gap -->
						<tr>
							<td width="100" style="font-size:12px; font-weight: bolder;">Weight</td>
							<td style="font-size:12px; width:30px; text-align: center;">:</td>
							<td style="font-size:12px; text-align: left">'.$profile->weight.'</td>
						</tr>
						</table>
						<!-- Right Area -->

					</td>
				</tr>
				</table>
			</td>
		</tr>
		</table>

	</td>
  </tr>
  </table>


 </body>
</html>
';

        $dompdf = new Dompdf(array('enable_remote' => true));
        $dompdf->loadHtml($html);

        // (Optional) Setup the paper size and orientation
        $dompdf->setPaper('A4', 'portrait');
        // Render the HTML as PDF
        $dompdf->render();

        // Output the generated PDF to Browser
        $this->response->setHeader('Content-Type', 'application/pdf');
        header("Content-type:application/pdf");
        header('Content-Disposition: inline');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
        $dompdf->stream("Employee_Profile_".rand()."_".$userId.".pdf", array("Attachment" => false));

    }

    public function edit($userId)
    {
        $data = $this->check($userId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->employeeName,
            'id'=> $data->userId
        );
         
		$profile = $this->profile->where('userId', $userId)->first();
        $designations = $this->designations->findAll();
        $qualifications = $this->qualifications->findAll();
        $projects = $this->projects->findAll();
        $headquarters = $this->headquarters->findAll();
		$users = $this->users->findAll();
       
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'profile' => $profile, 'designations' => $designations, 'projects' => $projects, 'qualifications' => $qualifications, 'headquarters' => $headquarters, 'users' => $users]);
    }

    public function update($userId)
	{
    if ($_SERVER['REQUEST_METHOD'] != 'POST') 
	{
        $response = service("response");
        $response->setStatusCode(403);
        $response->setBody("You do not have permission to access this page directly");
        return $response;
    }

		$post = $this->request->getPost();
		$data = $this->check($userId);
		$profileData = $this->profile->findByUserId($userId);
		$data->lastModifiedDate = date("Y-m-d H:i:s"); 
		$data->fill($post);
		$profileData->lastModifiedDate = date("Y-m-d H:i:s"); 
		$profileData->fill($post);

		if (!$data->hasChanged() && !$profileData->hasChanged()) 
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		} 
		else if ($this->model->save($data) && $this->profile->save($profileData))
		{
			return redirect()->to(ROUTE)->with('success', ITEM . ' updated successfully')->withInput();
		} 
		else 
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}

	}


    public function view($userId)
    {
        $data = $this->check($userId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->employeeName,
            'id'=> $data->userId
        );
         
		$profile = $this->profile->where('userId', $userId)->first();
        $designations = $this->designations->findAll();
        $qualifications = $this-> qualifications->findAll();
        $projects = $this->projects->findAll();
        $headquarters = $this->headquarters->findAll();
		$users = $this->users->findAll();
       
        return view(VIEWFOLDER."view", [VARIABLE => $data, 'const' => $const, 'profile' => $profile, 'designations' => $designations, 'projects' => $projects, 'qualifications' => $qualifications, 'headQuarters' => $headquarters, 'users' => $users]);
    }

    public function check($userId)
	{
		$data = $this->model->findById($userId);
		if($data===null)
		{
			throw \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $userId not found");
		}
		return $data;
	}
}