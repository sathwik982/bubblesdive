<?php

namespace App\Models;
class Attendance extends \CodeIgniter\Model
{
    
    protected $table = 'attendance';
    protected $primaryKey = 'attendanceId';
    protected $allowedFields = ['userId', 'date', 'attendanceType', 'attendance', 'attendanceLatt', 'attendanceLong', 'distanceFromHQ', 'status', 'approvedBy',  'createdDate', 'lastModifiedDate', 'picture', 'approverRemarks', 'nextApprover', 'remarks'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'userId' => 'required',
        'date' => 'required',
        'attendanceType' => 'required',
        'attendance' => 'required',
        'attendanceLatt' => 'required',
        'attendanceLong' => 'required',
        'status' => 'required',
        'nextApprover' => 'required',
        'approvedBy' => 'required',
        'picture' => 'required'
    ];

    protected $validationMessages = [
        'userId' => [
            'required' => 'Please choose the Employee'
        ],
        'date' => [
            'required' => 'Attendance date is required'
        ],
        'attendanceType' => [
            'required' => 'Attendance Type is required'
        ],
        'attendanceLatt' => [
            'required' => 'Attendance Lattitude is required'
        ],
        'attendanceLong' => [
            'required' => 'Attendance Longitude is required'
        ],
        'attendance' => [
            'required' => 'Attendance is required'
        ],
        'status' => [
            'required' => 'Status is required'
        ],
        'nextApprover' => [
            'required' => 'Next Approver is required'
        ],
        'approvedBy' => [
            'required' => 'Approved By is required'
        ],
        'picture' => [
            'required' => 'Attendance Picture is required'
        ]

    ];

    public function findById($attendanceId)
    {
        return $this->where('attendanceId', $attendanceId)->first();
    }

}
?>