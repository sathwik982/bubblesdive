<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Expensereports extends BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Expenses();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Reports/ExpenseReports/');
        define('ITEM','Expense');
        define('ITEMS','Expense Reports');
        define('DBTABLE','expense');
        define('VARIABLE','data');
        define('ROUTE','expensereports');

        session()->set('activate', "reports");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        if ($_SERVER['REQUEST_METHOD'] == 'POST') 
        {
            
            $data = array();
        
            $post = $this->request->getPost();
        
            $fromDate = date("Y-m-d", strtotime($post["fromDate"]));
            $toDate = date("Y-m-d", strtotime($post["toDate"]));

            $query = $this->expense->select('expenseId, userId, expenseDate, expenseCategoryId, expenseAmount, vehicleId, status, nextApprover, approvedBy');

            if ($post["fromDate"] && $post["toDate"]) 
            {
                $query->where("DATE(expenseDate) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'");
            }
            elseif ($post["fromDate"]) 
            {
                $query->where("DATE(expenseDate) >= '" . $fromDate . "'");
            } 
            elseif ($post["toDate"]) 
            {
                $query->where("DATE(expenseDate) <= '" . $toDate . "'");
            }
            if ($post["status"]) 
            {
                $query->where('status', $post["status"]);
            }

            $expense = $query->findAll();
        
            foreach ($expense as $price) 
            {
                $price->userId = $this->users->findById($price->userId) ? $this->users->findById($price->userId)->employeeName:"-";
                $price->expenseCategoryId = $this->expenseCategories->findById($price->expenseCategoryId) ? $this->expenseCategories->findById($price->expenseCategoryId)->expenseCategory : "-";
                $price->vehicleId = $this->vehicles->findById($price->vehicleId) ? $this->vehicles->findById($price->vehicleId)->vehicleType : "-";
                $price->nextApprover = $this->users->findById($price->nextApprover) ? $this->users->findById($price->nextApprover)->employeeName : "-";
                $price->approvedBy = $this->users->findById($price->approvedBy) ? $this->users->findById($price->approvedBy)->employeeName : "-";
                if($price->status == "PENDING")
                {
                    $price->status = "<span class='badge badge-soft-danger font-size-12'>".$price->status."</span>";
                }
                else
                {
                    $price->status = "<span class='badge badge-soft-success font-size-12'>".$price->status."</span>";
                }

            }
        
        $data = array('expense' => $expense);

        }
        else
        {
        
        $post = array();
        $data = array();
    
        }

        $users = $this->users->findAll();
        $expenseCategories = $this->expenseCategories->findAll();
        $vehicles = $this->vehicles->findAll();
        
        return view(VIEWFOLDER.'index', ['const' => $const, 'data' => $data, 'post' => $post, 'users' => $users, 'expenseCategories' => $expenseCategories, 'vehicles' => $vehicles]);
    }
    

}
