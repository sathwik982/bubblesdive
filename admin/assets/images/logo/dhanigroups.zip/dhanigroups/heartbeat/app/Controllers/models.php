<?php

$this->attendance = new \App\Models\Attendance;
$this->designations = new \App\Models\Designations;
$this->expense = new \App\Models\Expenses;
$this->expenseCategories = new \App\Models\ExpenseCategories;
$this->expense_documents = new \App\Models\ExpenseDocuments;
$this->headquarters = new \App\Models\Headquarters;
$this->labourAttendance = new \App\Models\LabourAttendance;
$this->leaves = new \App\Models\Leaves;
$this->leave_documents = new \App\Models\LeaveDocuments;
$this->leaveCategories = new \App\Models\LeaveCategories;
$this->leaveDeposits = new \App\Models\LeaveDeposits;
$this->logs = new \App\Models\Logs;
$this->profile = new \App\Models\Profile;
$this->projects = new \App\Models\Projects;
$this->qualifications = new \App\Models\Qualifications;
$this->settings = new \App\Models\Settings;
$this->users = new \App\Models\Users;
$this->vehicles = new \App\Models\Vehicles;

?>