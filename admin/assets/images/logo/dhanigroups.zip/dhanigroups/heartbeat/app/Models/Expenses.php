<?php

namespace App\Models;
class Expenses extends \CodeIgniter\Model
{
    
    protected $table = 'expense';
    protected $primaryKey = 'expenseId';
    protected $allowedFields = ['userId', 'expenseDate', 'expenseCategoryId', 'expenseAmount', 'vehicleId', 'movementFrom', 'movementTo', 'meterReadingStart', 'meterReadingEnd', 'totalKMTravelled', 'status', 'approvedBy', 'createdDate', 'lastModifiedDate', 'nextApprover', 'remarks', 'approverRemarks'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'userId' => 'required',
        'expenseDate' => 'required',
        'expenseCategoryId' => 'required',
        'expenseAmount' => 'required',
        'status' => 'required',
        'nextApprover' => 'required',
        'approvedBy' => 'required',
    ];

    protected $validationMessages = [
        'userId' => [
            'required' => 'Please choose the Employee'
        ],
        'expenseDate' => [
            'required' => 'Expense Date is required'
        ],
        'expenseCategoryId' => [
            'required' => 'Please choose the Expense Category'
        ],
        'expenseAmount' => [
            'required' => 'Please enter Expense Amount'
        ],
        'status' => [
            'required' => 'Please choose the Status'
        ],
        'nextApprover' => [
            'required' => 'Please choose the Next Approver'
        ],
        'approvedBy' => [
            'required' => 'Please choose the User'
        ],
    ];

    
    public function findById($expenseId)
    {
        return $this->where('expenseId', $expenseId)->first();
    }
}
?>