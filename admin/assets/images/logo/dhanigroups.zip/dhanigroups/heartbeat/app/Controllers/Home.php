<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Home extends BaseController
{
    public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
        $this->expenseDocuments = new \App\Models\ExpenseDocuments;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
        $this->leaveDocuments = new \App\Models\LeaveDocuments;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

    public function index()
    {
        if(service('auth')->isLoggedIn())
        {
            $redirect_url = session('redirect_url') ?? '/dashboard';
            unset($_SESSION['redirect_url']);
            return redirect()->to($redirect_url);
        }
        else
        {
            return view('login');
        }
    }
}
