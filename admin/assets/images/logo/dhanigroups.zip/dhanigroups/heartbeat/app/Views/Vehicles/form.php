<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
   <div class="col-md-3">
    <div class="mb-3">
    <label for="vehicleType">Vehicle Type <span style="color:#ff0000;"><sup>*</sup></span></label>
        <select class="form-control" id="vehicleType" name="vehicleType" required>
            <option value="">Please Select</option>
            <option value="TWO WHEELER" <?php if(old('vehicleType', $data->vehicleType) == "TWO WHEELER") { echo "selected"; } ?>>TWO WHEELER</option>
            <option value="FOUR WHEELER" <?php if(old('vehicleType', $data->vehicleType) == "FOUR WHEELER") { echo "selected"; } ?>>FOUR WHEELER</option>
        </select>
        <div class="invalid-feedback">Please Choose the Vehicle Type</div>
    </div>
   </div>
   <div class="col-md-3 mb-3">
        <label for="vehicleRegNumber">Registration Number <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="vehicleRegNumber" name="vehicleRegNumber" required placeholder="Registration number" value="<?= old('vehicleRegNumber', $data->vehicleRegNumber); ?>">
        <div class="invalid-feedback">Please enter the Registration Number</div>
    </div>
   <div class="col-md-3 mb-3">
        <label for="vehiclePucNumber">PUC Number <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="vehiclePucNumber" name="vehiclePucNumber" required placeholder="PUC number" value="<?= old('vehiclePucNumber', $data->vehiclePucNumber); ?>">
        <div class="invalid-feedback">Please enter the PUC Number</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="vehiclePucValidity">PUC Validity <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="vehiclePucValidity" name="vehiclePucValidity" required value="<?= old('vehiclePucValidity', $data->vehiclePucValidity); ?>">
        <div class="invalid-feedback">Please choose the PUC Validity</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="vehicleInsuranceNumber">Insurance Number <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="vehicleInsuranceNumber" name="vehicleInsuranceNumber" required placeholder="Insurance number" value="<?= old('vehicleInsuranceNumber', $data->vehicleInsuranceNumber); ?>">
        <div class="invalid-feedback">Please enter the Insurance Number</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="vehicleInsuranceValidity">Insurance Validity <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="vehicleInsuranceValidity" name="vehicleInsuranceValidity" required value="<?= old('vehicleInsuranceValidity', $data->vehicleInsuranceValidity); ?>">
        <div class="invalid-feedback">Please choose the Insurance Validity</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="vehicleLastServiceDate">Last Service Date <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="vehicleLastServiceDate" name="vehicleLastServiceDate" required value="<?= old('vehicleLastServiceDate', $data->vehicleLastServiceDate); ?>">
        <div class="invalid-feedback">Please choose the Last Service Date</div>
    </div>
    <div class="col-md-3" id="ownership">
        <div class="mb-3">
            <label for="ownership">Vehicle Ownership <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="ownership" name="ownership" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->ownership) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Vehicle Ownership</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="picture">Vehicle Picture <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="file" class="form-control" id="picture" name="picture" required value="<?= old('picture', $data->picture); ?>">
        <div class="invalid-feedback">Please upload the Vehicle Picture</div>
    </div>
</div>