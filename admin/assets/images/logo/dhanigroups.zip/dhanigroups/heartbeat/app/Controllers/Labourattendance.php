<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Labourattendance extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\LabourAttendance();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Labourattendance/');
        define('ITEM','Attendance');
        define('ITEMS','Labour Attendances');
        define('DBTABLE','labor_attendance');
        define('VARIABLE','data');
        define('ROUTE','labourattendance');

        session()->set('activate', "attendance");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('attendanceId, userId, date, laborName, attendanceType, attendance, distanceFromHQ, picture, status, nextApprover, approvedBy');
        
        return DataTable::of($builder)
       // ->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->attendanceId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a href="'.site_url(ROUTE."/view/".$row->attendanceId).'" class="text-primary"><i class="bx bx-show-alt" style="font-size:20px;"></i></a>
                    ';
        })
        ->edit('userId', function($row)
        {
            $employeeName = $this->users->findById($row->userId) ? $this->users->findById($row->userId)->employeeName: "-";
            return $employeeName;
        })
        ->edit('nextApprover', function($row)
        {
            $nextApprover = $this->users->findById($row->nextApprover) ? $this->users->findById($row->nextApprover)->employeeName: "-";
            return $nextApprover;
        })
        ->edit('approvedBy', function($row)
        {
            $approvedBy = $this->users->findById($row->approvedBy) ? $this->users->findById($row->approvedBy)->employeeName: "-";
            return $approvedBy;
        })
        ->edit('status', function($row)
        {
            if($row->status == "APPROVED")
            {
                return "<span class='badge badge-soft-success font-size-12'>" .$row->status. "</span>";
            }
            else
            {
                return "<span class='badge badge-soft-danger font-size-12'>" .$row->status. "</span>";
            }
        })
        ->edit('picture', function($row)
        {
            if($row->picture!="")
            {
                return "<a href='" . site_url($row->picture) . "' target = _blank> Click me </a>";
            }
            else
            {
                return "<a href='" . site_url() . "'> - </a>"; 
            }
            
        })
        ->edit('attendance', function($row)
        {
            if($row->attendance == '0')
            {
                return "<span class='badge badge-soft-danger font-size-12'>ABSENT</span>";
            }
            else if($row->attendance == '0.5')
            {
                return "<span class='badge badge-soft-warning font-size-12'>HALF-DAY</span>";
            }
            else
            {
                return "<span class='badge badge-soft-success font-size-12'>PRESENT</span>";
            }
        })

        
        ->edit('distanceFromHQ', function($row) 
        {
            if ($row->distanceFromHQ!="") 
            {
               return $row->distanceFromHQ . " kms";
            } 
        })
        ->filter(function ($builder, $request)
        {
            if ($this->request->getGet("status"))
            $builder->where("status", $this->request->getGet("status"));

            if ($this->request->getGet("attendance"))
            $builder->where("attendance", $this->request->getGet("attendance"));


            if ($this->request->getGet("fromDate") && $this->request->getGet("toDate"))
            {
                $from = date("Y-m-d", strtotime($this->request->getGet("fromDate")));
                $to = date("Y-m-d", strtotime($this->request->getGet("toDate")));

                $builder->where("DATE(date) BETWEEN '" . $from . "' AND '" . $to . "'", NULL, FALSE);
            }
        })

        //->hide('attendanceId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        $users = $this->users->findAll();

        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'users' => $users]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->request->getFile('picture'))
        {
            //file upload
            $file = $this->request->getFile('picture');
            $uploadedFile = $file->getName();
            if($this->request->getFile('picture') && $uploadedFile != "")
            {
                $validated = $this->validate([
                    'picture' => [
                        'uploaded[picture]',
                        'mime_in[picture,image/jpg,image/jpeg,image/gif,image/png,application/pdf]',
                        'max_size[picture,8096]',
                    ]
                ]);
        
                if (!$validated)
                {
                    if($this->validator->getError('picture'))
                    {
                        return redirect()->back()->with('warning', $this->validator->getError('picture'))->withInput();
                    }
                    
                }

                $uploadedFile = $file->getName();
                if($uploadedFile != "")
                {
                    if (! $file->hasMoved())
                    {
                        $extension = $file->getClientExtension(); //.pdf
                        $newName = "Labour_Attendanceref_".rand().".".$extension; // rf_345454545.pdf
                        $file->move('uploads/', $newName); // 
                        $uploadedFile = "uploads/".$newName; //uploads/rf_345454545.pdf
                        $data->picture = $uploadedFile;
                    }
                }
            }
            //file upload
        }
        else
        {
            $data->picture = null;
        }

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($attendanceId)
    {
        $data = $this->check($attendanceId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->attendanceId,
            'id'=> $data->attendanceId
        );

        $users = $this->users->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'users' => $users]);
    }

    public function update($attendanceId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($attendanceId);
        if($this->request->getFile('picture'))
        {
            //file upload
            $file = $this->request->getFile('picture');
            $uploadedFile = $file->getName();
            if($this->request->getFile('picture') && $uploadedFile != "")
            {
                $validated = $this->validate([
                    'picture' => [
                        'uploaded[picture]',
                        'mime_in[picture,image/jpg,image/jpeg,image/gif,image/png,application/pdf]',
                        'max_size[picture,8096]',
                    ]
                ]);
        
                if (!$validated)
                {
                    if($this->validator->getError('picture'))
                    {
                        return redirect()->back()->with('warning', $this->validator->getError('picture'))->withInput();
                    }
                    
                }

                $uploadedFile = $file->getName();
                if($uploadedFile != "")
                {
                    if (! $file->hasMoved())
                    {
                        $extension = $file->getClientExtension(); //.pdf
                        $newName = "Labour_Attendanceref_".rand().".".$extension; // rf_345454545.pdf
                        $file->move('uploads/', $newName); // 
                        $uploadedFile = "uploads/".$newName; //uploads/rf_345454545.pdf
                        $data->picture = $uploadedFile;
                    }
                }
            }
            //file upload
        }
        else
        {
            $data->picture = null;
        }
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function view($userId)
    {
        $data = $this->check($userId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->userId,
            'id'=> $data->userId
        );
         
        
        $users = $this->users->findAll();
       
        return view(VIEWFOLDER."view", [VARIABLE => $data, 'const' => $const, 'users' => $users ]);
    }

    public function check($attendanceId)
	{
		$data = $this->model->findById($attendanceId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $attendanceId not found");
		}
		return $data;
	}
}
