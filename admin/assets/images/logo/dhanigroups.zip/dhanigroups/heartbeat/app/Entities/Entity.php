<?php
namespace App\Entities;

class Entity extends \CodeIgniter\Entity\Entity
{

}

?>