<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Expenses extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
    	$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
        $this->expenseDocuments = new \App\Models\ExpenseDocuments;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
        $this->leaveDocuments = new \App\Models\LeaveDocuments;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside expenses/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

    public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->expense->select('COUNT(expenseId) as total')->where('userId', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->expense->where('userId', $userId)->orderBy('expenseId', 'DESC')->limit($limit, $offset)->find();

                    if($data)
                    {
                        foreach($data as $expense)
                        {
                            $expenseId = $expense->expenseId;
                            $documents = $this->expenseDocuments->where('expenseId', $expenseId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->expenseDocumentId);
                                unset($document->expenseId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }
                            
                            $nextApproverName = $this->users->findById($expense->nextApprover) ? $this->users->findById($expense->nextApprover)->employeeName: "-";
                            $expense->nextApproverName = $nextApproverName;

                            $expenseCategoryName = $this->expenseCategories->findById($expense->expenseCategoryId) ? $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory: "-";
                            $expense->expenseCategoryName = $expenseCategoryName;

                            if($expense->vehicleId >= 1)
                            {
                                $vehicleRegNumber = $this->vehicles->findById($expense->vehicleId) ? $this->vehicles->findById($expense->vehicleId)->vehicleRegNumber: "-";
                                $expense->vehicleRegNumber = $vehicleRegNumber;
                            }

                            $expense->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{

                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");
                    $expenseCategoryId = $this->request->getVar("expenseCategoryId");

                    //Content Goes Here
                    $query = $this->expense->where('userId', $userId);

                    if($startDate && $endDate)
                    {
                        $query = $query->where("expenseDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE);
                    }

                    if($expenseCategoryId && $expenseCategoryId >= 1)
                    {
                        $query = $query->where("expenseCategoryId", $expenseCategoryId);
                    }

                    $data = $query = $query->orderBy('expenseId', 'DESC')->find();

                    if($data)
                    {
                        foreach($data as $expense)
                        {
                            $expenseId = $expense->expenseId;
                            $documents = $this->expenseDocuments->where('expenseId', $expenseId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->expenseDocumentId);
                                unset($document->expenseId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }
                            
                            $nextApproverName = $this->users->findById($expense->nextApprover) ? $this->users->findById($expense->nextApprover)->employeeName: "-";
                            $expense->nextApproverName = $nextApproverName;

                            $expenseCategoryName = $this->expenseCategories->findById($expense->expenseCategoryId) ? $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory: "-";
                            $expense->expenseCategoryName = $expenseCategoryName;

                            if($expense->vehicleId >= 1)
                            {
                                $vehicleRegNumber = $this->vehicles->findById($expense->vehicleId) ? $this->vehicles->findById($expense->vehicleId)->vehicleRegNumber: "-";
                                $expense->vehicleRegNumber = $vehicleRegNumber;
                            }

                            $expense->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function new()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

                $reportTo = $this->profile->findByUserId($userId) ? $this->profile->findByUserId($userId)->reportTo: null;
				$user = $this->checkUser($userId);

				if($user)
				{
                    $uploadFolder = "uploads/";
                    //Content Goes Here
                    $post = json_decode(json_encode($this->request->getVar()), true);
                    $data = new Entity($post);

                    $data->userId = $userId;
                    $data->nextApprover = $reportTo;

                    $expense = $this->expense->where('userId', $userId)->where('expenseDate', $this->request->getVar('expenseDate'))->where('expenseCategoryId', $this->request->getVar('expenseCategoryId'))->where('expenseAmount', $this->request->getVar('expenseAmount'))->first();

                    if(!$expense)
                    {
                        if ($this->expense->insert($data))
                        {
                            $expenseId = $this->expense->getInsertID();
                            $documentsArray = $this->request->getVar("documents");

                            foreach($documentsArray as $documentArray)
                            {
                                $file = $documentArray->document;
                                $imageName = "exp_".$expenseId."_".date("Ymd")."_".rand(1,1000).".pdf";
                                if(file_exists($uploadFolder.$imageName))
                                {
                                    $imageName = rand(1,1000)."_".$imageName;
                                }

                                file_put_contents($uploadFolder.$imageName, base64_decode($file));
                                $document = $uploadFolder.$imageName;

                                $insertArray = array(
                                    'expenseId' => $expenseId,
                                    'document' => $document,
                                );

                                if(!$this->expenseDocuments->insert($insertArray))
                                {
                                    $response = [
                                        "status" => 500,
                                        "message" => "Documents upload error",
                                        "error" => true,
                                        "data" => $this->expenseDocuments->errors()
                                    ];
                                }

                            }

                            $response = [
                                "status" => 200,
                                "message" => "Expense recorded successfully",
                                "error" => false,
                                "data" => []
                            ];
                        }
                        else
                        {
                            $response = [
                                "status" => 500,
                                "message" => "Sorry, unable to record expense",
                                "error" => true,
                                "data" => $this->expense->errors()
                            ];
                        }
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "Duplicate Expense",
                            "error" => true,
                            "data" => []
                        ];
                    }

                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

}
