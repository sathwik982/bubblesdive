<?php

namespace App\Models;
class Logs extends \CodeIgniter\Model
{
    
    protected $table = 'logs';
    protected $primaryKey = 'logId';
    protected $allowedFields = ['userId', 'attendanceId', 'laborAttendanceId', 'expenseId', 'leaveId', 'log', 'createdDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	//protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'log' => 'required'
    ];

    protected $validationMessages = [
        'log' => [
            'required' => 'Please enter the Log'
        ]
    ];

    public function findById($logId)
    {
        return $this->where('logId', $logId)->first();
    }
}
?>