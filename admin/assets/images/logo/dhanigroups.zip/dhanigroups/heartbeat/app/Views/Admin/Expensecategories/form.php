<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="expenseCategory">Expense Category <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="expenseCategory" name="expenseCategory" placeholder="Expense Category" required value="<?= old('expenseCategory', $data->expenseCategory); ?>">
        <div class="invalid-feedback">Please enter the Expense Category</div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="requireLabor">Require Labour <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="requireLabor" name="requireLabor" required>
                <option value="">Please Select</option>
                <option value="YES" <?php if(old('requireLabor', $data->requireLabor) == "YES") { echo "selected"; } ?>>YES</option>
                <option value="NO" <?php if(old('requireLabor', $data->requireLabor) == "NO") { echo "selected"; } ?>>NO</option>
            </select>
            <div class="invalid-feedback">Please Choose the Option</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="id">Require Vehicle <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="requireVehicle" name="requireVehicle" required>
                <option value="">Please Select</option>
                <option value="YES" <?php if(old('requireVehicle', $data->requireVehicle) == "YES") { echo "selected"; } ?>>YES</option>
                <option value="NO" <?php if(old('requireVehicle', $data->requireVehicle) == "NO") { echo "selected"; } ?>>NO</option>
            </select>
            <div class="invalid-feedback">Please Choose the Option</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="display">Display <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="display" name="display" required>
                <option value="">Please Select</option>
                <option value="ALL" <?php if(old('display', $data->display) == "ALL") { echo "selected"; } ?>>ALL</option>
                <option value="WEB" <?php if(old('display', $data->display) == "WEB") { echo "selected"; } ?>>WEB</option>
            </select>
            <div class="invalid-feedback">Please Choose the Option</div>
        </div>
    </div>
</div>