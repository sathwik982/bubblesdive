<?php

namespace App\Models;

use CodeIgniter\Model;

class LeaveDocuments extends Model
{
    protected $table = 'leave_documents';
    protected $primaryKey = 'leaveDocumentId';
    protected $allowedFields = ['leaveId', 'documents', 'createdDate', 'lastModifiedDate'];
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'createdDate';
    protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules = [
        'leaveId' => 'required|integer'
    ];

    protected $validationMessages = [
        'leaveId' => [
            'required' => 'Leave ID is required.',
            'integer' => 'Leave ID must be an integer.',
        ]
    ];

    public function findById($leaveDocumentId)
    {
        return $this->where('leaveDocumentId', $leaveDocumentId)->first();
    }
}
