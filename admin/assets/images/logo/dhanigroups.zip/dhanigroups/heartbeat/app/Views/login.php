<!doctype html>
<html lang="en" >
   <head>
      <meta charset="utf-8" />
      <title>Dhani Communications | Login</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta content="" name="description" />
      <meta content="Crisant Technologies" name="author" />
      <link rel="shortcut icon" href="<?= site_url(); ?>assets/images/favicon.ico">
      <link href="<?= site_url(); ?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/snackbar.min.css" id="app-style" rel="stylesheet" type="text/css" />
   </head>
   <body data-layout="horizontal" data-topbar="dark">
      <div class="authentication-bg min-vh-100">
         <div class="bg-overlay"></div>
         <div class="container">
            <div class="d-flex flex-column min-vh-100 px-3 pt-4">
               <div class="row justify-content-center my-auto">
                  <div class="col-md-8 col-lg-6 col-xl-5">
                     <div class="card">
                        <div class="card-body p-4">
                           <div class="text-center mt-2">
                              <a href="<?= site_url(); ?>"><img src="<?= site_url('assets/images/logo.png'); ?>" width="250" /></a>
                           </div>
                           <div class="p-2 mt-4">
                              <?php $attributes = array('class' => 'needs-validation', 'novalidate' => 'novalidate'); ?>
                              <?= form_open("login/login", $attributes); ?>
                                 <div class="mb-3 position-relative">
                                    <label class="form-label" for="mobileNumber">Mobile Number</label>
                                    <input type="number" step="1" class="form-control" id="mobileNumber" name="mobileNumber" type="text" class="form-control" placeholder="Mobile Number" required>
                                 </div>
                                 <div class="mb-3">
                                    <div class="float-end">
                                       <a href="javascript:void(0);" class="text-muted">Forgot password?</a>
                                    </div>
                                    <label class="form-label" for="userPassword">Password</label>
                                    <input name="userPassword" type="password" class="form-control" placeholder="Enter Password" required>
                                 </div>
                                 <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="auth-remember-check">
                                    <label class="form-check-label" for="auth-remember-check">Remember me</label>
                                 </div>
                                 <div class="mt-3 text-end">
                                    <button class="btn btn-primary w-sm waves-effect waves-light" type="submit">Log In</button>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-lg-12">
                     <div class="text-center text-muted p-4">
                        <p class="text-white-50">
                           &copy; <script>document.write(new Date().getFullYear())</script> Dhani Communications. All rights reserved.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end container -->
      </div>
      <!-- end authentication section -->
      <!-- JAVASCRIPT -->
      <script src="<?= site_url(); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/metismenujs/metismenujs.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/simplebar/simplebar.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/feather-icons/feather.min.js"></script>
      <script src="<?= site_url(); ?>assets/js/pages/form-validation.init.js"></script>
      <script src="<?= site_url(); ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>
      <script src="<?= site_url(); ?>assets/js/snackbar.js"></script>
      <?php if (session()->has('success')) : ?>
      <script>
         Swal.fire({
            title: 'Good job!',
            text: "<?= session('success') ?>",
            icon: "success",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('warning')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('warning') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('danger')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('danger') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('reload')) : ?>
          <script>
            var t;
            Swal.fire({
              title: "Please wait !",
              html: "<?= session('reload') ?>",
              timer: 2e3,
              timerProgressBar: !0,
              didOpen: function() {
                  Swal.showLoading(), t = setInterval(function() {
                      var t, e = Swal.getHtmlContainer();
                      !e || (t = e.querySelector("b")) && (t.textContent = Swal.getTimerLeft())
                  }, 100)
              },
              onClose: function() {
                  clearInterval(t)
              }
          });
          </script>
      <?php endif; ?>
      <?php if (session()->has('toast')) : ?>
          <script>
            Snackbar.show(
              {
                text: "<?= session('toast') ?>",
                pos: 'bottom-left'
              });
          </script>
      <?php endif; ?>
   </body>
</html>
