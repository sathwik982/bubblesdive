<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="employeeId">Employee ID <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="employeeId" name="employeeId" placeholder="Enter the Employee Id" required value="<?= old('employeeId', $data->employeeId); ?>">
        <div class="invalid-feedback">Please enter a valid Employee ID</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="employeeName">Employee Name <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="employeeName" name="employeeName" placeholder="Enter the Employee Name" required value="<?= old('employeeName', $data->employeeName); ?>">
        <div class="invalid-feedback">Please enter the Employee Name</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="mobileNumber">Mobile Number <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="number" class="form-control" id="mobileNumber" name="mobileNumber" placeholder="Enter the Mobile number" required  value="<?= old('mobileNumber', $data->mobileNumber); ?>">
        <div class="invalid-feedback">Please enter the Mobile Number</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="userPassword ">Password <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="password" class="form-control" id="userPassword" name="userPassword" placeholder="Password" <?php if($data->userRole == "") echo "required"; ?> value="<?= old('userPassword'); ?>">
        <div class="invalid-feedback">Please enter the Password</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="password_confirmation">Repeat Password <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password" <?php if($data->userRole == "") echo "required"; ?> value="<?= old('password_confirmation'); ?>">
        <div class="invalid-feedback">Please enter Repeat Password</div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="userStatus">Status <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="userStatus" name="userStatus" required>
                <option value="">Please Select</option>
                <option value="ACTIVE" <?php if(old('userStatus', $data->userStatus) == "ACTIVE") { echo "selected"; } ?>>ACTIVE</option>
                <option value="INACTIVE" <?php if(old('userStatus', $data->userStatus) == "INACTIVE") { echo "selected"; } ?>>INACTIVE</option>
            </select>
            <div class="invalid-feedback">Please choose the Status</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="userRole">User Role <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="userRole" name="userRole" required>
                <option value="">Please Select</option>
                <option value="ADMIN" <?php if(old('userRole', $data->userRole) == "ADMIN") { echo "selected"; } ?>>ADMIN</option>
                <option value="USER" <?php if(old('userRole', $data->userRole) == "USER") { echo "selected"; } ?>>USER</option>
            </select>
            <div class="invalid-feedback">Please choose the User Role</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="canHireLabour">Can Hire Labour <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="canHireLabour" name="canHireLabour" required>
                <option value="">Please Select</option>
                <option value="YES" <?php if(old('canHireLabour', $data->canHireLabour) == "YES") { echo "selected"; } ?>>YES</option>
                <option value="NO" <?php if(old('canHireLabour', $data->canHireLabour) == "NO") { echo "selected"; } ?>>NO</option>
            </select>
            <div class="invalid-feedback">Please choose the Hire Labour</div>
        </div>
    </div>
</div>