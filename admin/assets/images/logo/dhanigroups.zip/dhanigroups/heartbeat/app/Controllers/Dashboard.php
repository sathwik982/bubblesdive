<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;


class Dashboard extends \App\Controllers\BaseController
{
    public function __construct()
    {
        include_once "heartbeat/app/Controllers/models.php";
        session()->set('activate', "dashboard");
    }

    public function index()
    {
        $data = array();
        $attendanceTrend = array();
        $labourAttendanceTrend = array();
        $expensesTrend = array();
        $leavesTrend = array();
        $daysofMonth = date('t');

        $Variable1 = strtotime(date("Y-m-01"));
        $Variable2 = strtotime(date("Y-m-".$daysofMonth));

            for ($currentDate = $Variable1; $currentDate <= $Variable2; $currentDate += (86400))
            {
                
                $dateFormatted = date('Y-m-d', $currentDate);
                $attendance = $this->attendance->select('COUNT(attendanceId) AS total')->where('DATE(createdDate)', $dateFormatted)->where('status', 'APPROVED')->first()->total;
                $labourAttendance = $this->labourAttendance->select('COUNT(attendanceId) AS total')->where('DATE(createdDate)', $dateFormatted)->where('status', 'APPROVED')->first()->total;
                $expense = $this->expense->select('COUNT(expenseId) AS total')->where('DATE(createdDate)', $dateFormatted)->where('status', 'APPROVED')->first()->total;
                $leaves = $this->leaves->select('COUNT(leaveId) AS total')->where('DATE(createdDate)', $dateFormatted)->where('status', 'APPROVED')->first()->total;

                array_push($attendanceTrend, $attendance);
                array_push($labourAttendanceTrend, $labourAttendance);
                array_push($expensesTrend, $expense);
                array_push($leavesTrend, $leaves);
            }

            $data = array(
                'attendanceTrend' => $attendanceTrend,
                'labourAttendanceTrend' => $labourAttendanceTrend,
                'expensesTrend' => $expensesTrend,
                'leavesTrend' => $leavesTrend,
            );

        $attendance = $this->attendance->findAll();
        $labourAttendance = $this->labourAttendance->findAll();
        $leaves = $this->leaves->findAll();
        $expense = $this->expense->findAll();
        
        return view('dashboard', ['data' => $data, 'attendance' => $attendance, 'labourAttendance' => $labourAttendance, 'expense' => $expense, 'leaves' => $leaves]);
    }
}
