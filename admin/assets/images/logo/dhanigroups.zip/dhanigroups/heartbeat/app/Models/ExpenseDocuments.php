<?php

namespace App\Models;

use CodeIgniter\Model;

class ExpenseDocuments extends Model
{
    protected $table = 'expense_documents';
    protected $primaryKey = 'expenseDocumentId';
    protected $allowedFields = ['expenseId', 'documents', 'createdDate', 'lastModifiedDate'];
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'createdDate';
    protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules = [
        'expenseId' => 'required|integer'
    ];

    protected $validationMessages = [
        'expenseId' => [
            'required' => 'Expense ID is required.',
            'integer' => 'Expense ID must be an integer.',
        ]
    ];

    public function findById($expenseDocumentId)
    {
        return $this->where('expenseDocumentId', $expenseDocumentId)->first();
    }
}
