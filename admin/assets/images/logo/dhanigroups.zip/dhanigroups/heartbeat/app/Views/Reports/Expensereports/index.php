<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?><?= $const["items"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?>
<link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/datatables.css">
<link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/dt-global_style.css">
<?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0"><?= $const["items"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item active"><?= $const["items"]; ?></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <div class="card-body">
            <?php $attributes = array('class' => 'needs-validation'); ?>
            <?= form_open_multipart($const["route"].'/index', $attributes); ?>
            <?php if (session()->has('error') && is_array(session('error'))) : ?>
            <div class="row">
               <div class="col-md-6">
                     <div class="alert alert-danger" role="alert">
                        <ul style="margin-bottom: 0px;">
                           <?php foreach (session('error') as $error) : ?>
                           <li><?= $error ?></li>
                           <?php endforeach; ?>
                        </ul>
                     </div>
               </div>
            </div>
            <?php endif; ?>
            <div class="row">
               <div class="col-lg-10">
                  <div class="row">
                     <div class="col-md-3">
                        <label>From Date</label>
                        <input type="date" class="form-control" id="fromDate" name="fromDate" placeholder="From Date" required value="<?php if($post){ $fromDate = $post["fromDate"]; } else { $fromDate = null; } echo old('fromDate', $fromDate) ?>">
                     </div>
                     <div class="col-md-3">
                        <label>To Date</label>
                        <input type="date" class="form-control" id="toDate" name="toDate" placeholder="To Date" value="<?php if($post){ $toDate = $post["toDate"]; } else { $toDate = null; } echo old('toDate', $toDate) ?>">
                     </div>
                     <div class="col-md-3">
                        <label for="status">Status</label>
                        <select class="form-control" id="status" name="status">
                           <option value="">Show All</option>
                           <option value="PENDING" <?php if (isset($_POST['status']) && $_POST['status'] == 'PENDING') echo 'selected="selected"'; ?>>PENDING</option>
                           <option value="APPROVED" <?php if (isset($_POST['status']) && $_POST['status'] == 'APPROVED') echo 'selected="selected"'; ?>>APPROVED</option>
                        </select>
                  </div>
                  </div>
               </div>
               <div class="col-lg-2" style="text-align: left; padding-top:32px;"><button type="submit" class="btn btn-success waves-effect btn-label waves-light"><i class="bx bx-plus-medical label-icon"></i> Generate</button></div>
            </div>
            <div class="table-responsive">
            </div>
         </div>
         </form>
      </div>
   </div>
</div>
<!-- end row -->
<?php if($data) : ?>
   <div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex flex-wrap align-items-center">
                    <h5 class="card-title mb-0">Expenses</h5>
                </div>
            </div>
            <div class="card-body pt-xl-1">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-striped table-centered align-middle table-nowrap mb-0">
                        <thead >
                            <tr>
                                <th>Employee</th>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Amount</th>
                                <th>Vehicle</th>
                                <th>Status</th>
                                <th>Next Approver</th>
                                <th>Approved By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $a = 1;
                            foreach($data["expense"] as $price)
                            {
                                ?>
                                <tr>
                                    <td><?= $price->userId; ?></td>
                                    <td><?= $price->expenseDate; ?></td>
                                    <td><?= $price->expenseCategoryId; ?></td>
                                    <td><?= $price->expenseAmount; ?></td>
                                    <td><?= $price->vehicleId; ?></td>
                                    <td><?= $price->status; ?></td>
                                    <td><?= $price->nextApprover; ?></td>
                                    <td><?= $price->approvedBy; ?></td>
                                </tr>
                                <?php
                            
                            $a++;

                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>plugins/table/datatable/datatables.js"></script>
<?= $this->endSection() ?>
