<?php

namespace App\Models;
use CodeIgniter\Model;

class Profile extends Model
{
    protected $table = 'profile';
    protected $primaryKey = 'profileId';
    protected $allowedFields = [
        'userId', 'designationId', 'dateOfBirth', 'dateOfJoining', 'bloodGroup', 'motherName', 'fatherName',
        'adhaarNumber', 'panNumber', 'drivingLicenseNumber', 'esicNumber', 'personalInsurance', 'healthInsurance', 'accidentalInsurance', 'highestQualification', 'martialStatus', 'noOfChildren', 'height', 'weight', 'presentAddress', 'permanentAddess', 'projectId', 'headquarterId', 'salary', 'reportTo', 'leaveBalance', 'profilePicture'
    ];
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'createdDate';
    protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

   

    public function findById($profileId)
    {
        return $this->where('profileId', $profileId)->first();
    }

    public function findByUserId($userId)
    {
        return $this->where('userId', $userId)->first();
    }
}
