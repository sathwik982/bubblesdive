<?php

namespace App\Models;
class Headquarters extends \CodeIgniter\Model
{
    
    protected $table = 'headquarters';
    protected $primaryKey = 'headQuarterId';
    protected $allowedFields = ['headQuarterName', 'projectId', 'headQuarterLatt', 'headQuarterLong', 'createdDate', 'lastModifiedDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'headQuarterName' => 'required'
    ];

    protected $validationMessages = [
        'headQuarterName' => [
            'required' => 'HeadQuarter Name is required'
        ]
    ];

    public function findById($headQuarterId)
    {
        return $this->where('headQuarterId', $headQuarterId)->first();
    }
}
?>