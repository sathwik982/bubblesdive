<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>View <?= $const["item"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0">View <?= $const["item"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item"><a href="<?= site_url($const["route"]); ?>"><?= $const["items"]; ?></a></li>
               <li class="breadcrumb-item active"><a href="<?= site_url($const["route"].'/edit/'.$const["id"]); ?>"><?= $const["identifier"]; ?></a></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<!-- end row -->
<div class="row">
   <div class="col-lg-12">
      <?php $attributes = array('class' => 'needs-validation', 'id' => 'updateForm', 'novalidate' => 'novalidate'); ?>
      <?= form_open_multipart($const["route"].'/update/'.$const["id"], $attributes); ?>
      <div class="card">
         <div class="card-body">
            <?php if (session()->has('error')) : ?>
            <div class="row">
               <div mg="6" class="col">
                  <div class="alert alert-danger" role="alert">
                     <ul style="margin-bottom:0px;">
                        <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                        <?php endforeach; ?>
                     </ul>
                  </div>
               </div>
            </div>
            <?php endif ?>
            <div class="row">
               <div class="col-md-3" id="userId">
                  <div class="mb-3">
                     <label for="userId">Employee</label>
                     <select class="form-control" id="userId" name="userId" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($users as $user)
                           {
                               $selected = null;
                           
                               (old('userId', $data->userId) == $user->userId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3 mb-3">
                  <label for="expenseDate">Expense Date</label>
                  <input type="date" class="form-control" id="expenseDate" name="expenseDate" value="<?= old('expenseDate', $data->expenseDate); ?>" disabled>
               </div>
               <div class="col-md-3">
                  <div class="mb-3">
                     <label for="expenseCategoryId">Expense Category</label>
                     <select class="form-control" id="expenseCategoryId" name="expenseCategoryId" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($expenseCategories as $expenseCategory)
                           {
                               $selected = null;
                           
                               (old('expenseCategoryId', $data->expenseCategoryId) == $expenseCategory->expenseCategoryId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$expenseCategory->expenseCategoryId.'" '.$selected.'>'.$expenseCategory->expenseCategory.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3 mb-3">
                  <label for="expenseAmount">Expense Amount</label>
                  <input type="number" class="form-control" id="expenseAmount" name="expenseAmount" placeholder="Expense amount" value="<?= old('expenseAmount', $data->expenseAmount); ?>" disabled>
               </div>
               <div class="col-md-3" id="vehicleNumber" style="display:none">
                  <div class="mb-3">
                     <label for="vehicleId">Vehicle</label>
                     <select class="form-control" id="vehicleId" name="vehicleId">
                        <option value="">Please Select</option>
                        <?php
                           foreach($vehicles as $vehicle)
                           {
                               $selected = null;
                           
                               (old('vehicleId', $data->vehicleId) == $vehicle->vehicleId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$vehicle->vehicleId.'" '.$selected.'>'.$vehicle->vehicleType.'</option>';
                           }
                           ?>
                     </select>
                     <div class="invalid-feedback">Please choose the Vehicle</div>
                  </div>
               </div>
               <div class="col-md-3 mb-3" id="movementFr" style="display:none">
                  <label for="movementFrom">Movement From</label>
                  <input type="number" class="form-control" id="movementFrom" name="movementFrom" placeholder="Movement From" required value="<?= old('movementFrom', $data->movementFrom); ?>">
               </div>
               <div class="col-md-3 mb-3" id="movementTr" style="display:none">
                  <label for="movementTo">Movement To</label>
                  <input type="number" class="form-control" id="movementTo" name="movementTo" placeholder="Movement To" required value="<?= old('movementTo', $data->movementTo); ?>">
               </div>
               <div class="col-md-3 mb-3" id="movementStart" style="display:none">
                  <label for="meterReadingStart">Meter Reading Start</label>
                  <input type="number" class="form-control" id="meterReadingStart" name="meterReadingStart" placeholder="Meter Reading Start" required value="<?= old('meterReadingStart', $data->meterReadingStart); ?>">
               </div>
               <div class="col-md-3 mb-3" id="movementEnd" style="display:none">
                  <label for="meterReadingStart">Meter Reading End</label>
                  <input type="number" class="form-control" id="meterReadingEnd" name="meterReadingEnd"  placeholder="Meter Reading End" required value="<?= old('meterReadingEnd', $data->meterReadingEnd); ?>">
               </div>
               <div class="col-md-3" id="nextApprover">
                  <div class="mb-3">
                     <label for="nextApprover">Next Approver</label>
                     <select class="form-control" id="nextApprover" name="nextApprover" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($users as $user)
                           {
                               $selected = null;
                           
                               (old('userId', $data->nextApprover) == $user->userId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="mb-3">
                     <label for="status">Status</label>
                     <select class="form-control" id="status" name="status" disabled>
                        <option value="">Please Select</option>
                        <option value="PENDING" <?php if(old('status', $data->status) == "PENDING") { echo "selected"; } ?>>PENDING</option>
                        <option value="APPROVED" <?php if(old('status', $data->status) == "APPROVED") { echo "selected"; } ?>>APPROVED</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="approvedBy">
                  <div class="mb-3">
                     <label for="approvedBy">Approved By</label>
                     <select class="form-control" id="approvedBy" name="approvedBy" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($users as $user)
                           {
                               $selected = null;
                           
                               (old('userId', $data->approvedBy) == $user->userId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-12 mb-3">
                  <label for="approverRemarks">Approver Remarks  <small>(If Any)</small></label>
                  <textarea id="approverRemarks" name="approverRemarks" class="form-control" placeholder="Approver Remarks (Optional)" disabled><?= old('approverRemarks', $data->approverRemarks); ?></textarea>
               </div>
               <div class="col-md-12 mb-3">
                  <label for="remarks">Remarks <small>(If Any)</small></label>
                  <textarea id="remarks" name="remarks" class="form-control" placeholder="Remarks (Optional)" disabled><?= old('remarks', $data->remarks); ?></textarea>
               </div>
            <div class="row">
            <div class="col-md-12">
               <h4>Documents:</h4>
                  <div class="table-responsive mt-3">
                     <table class="table table-striped table-bordered mb-0">
                        <thead>
                           <tr>
                              <th>SL No:</th>
                              <th>Expense Documents</th>
                              <th>Created Date</th>
                           </tr>
                        </thead>
                        <tbody>
                       <?php
                       if (!($expense_documents)) 
                       {
                       echo '<tr><td colspan="3">No documents found..</td></tr>';
                       } 
                       else 
                       {
                      $a = 1;
                     foreach ($expense_documents as $expense_document) 
                     {
                     ?>
                     <tr>
                     <td><?= $a; ?></td>
                     <td><a href="<?= $expense_document->documents; ?>" target="_blank">Click Here</a></td>
                     <td><?= $expense_document->createdDate; ?></td>
                     </tr>
                     <?php
                     $a++;
                     }
                     }
                     ?>
                     </tbody>
                     </table>
                  </div>
                  </div>
                  </div>
            </div>
         </div>
         <div class="card-footer">
            <div class="d-flex flex-wrap gap-2">
               <a href="<?= site_url($const["route"]); ?>" class="btn btn-danger waves-effect waves-light">
               <i class="bx bx-left-arrow-alt font-size-16 align-middle me-2"></i> Back
               </a>
            </div>
         </div>
      </div>
      </form>
   </div>
</div>
<!-- end row -->
<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>assets/js/pages/form-validation.init.js"></script>
<?= $this->endSection() ?>
