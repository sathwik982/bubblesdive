<?php

namespace App\Controllers\Admin;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Leavedeposits extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\LeaveDeposits();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Admin/Leavedeposits/');
        define('ITEM','Leave Deposit');
        define('ITEMS','Leave Deposits');
        define('DBTABLE','leave_deposits');
        define('VARIABLE','data');
        define('ROUTE','admin/leavedeposits');

        session()->set('activate', "admin");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('depositId, userId, leaveCategoryId, leaves, depositedBy');
        
        return DataTable::of($builder)
       //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->depositId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a style="padding-left:10px;" href="'.site_url(ROUTE."/delete/".$row->depositId).'" class="text-danger"><i class="bx bx-trash" style="font-size:20px;"></i></a>
                   ';
        })
        ->edit('leaveCategoryId', function($row)
        {
            $leaveCategory = $this->leaveCategories->findById($row->leaveCategoryId) ? $this->leaveCategories->findById($row->leaveCategoryId)->leaveCategory: "-";
            return $leaveCategory;
        })
        ->edit('userId', function($row)
        {
            $username = $this->users->findById($row->userId) ? $this->users->findById($row->userId)->employeeName: "-";
            return $username;
        })
        ->edit('depositedBy', function($row)
        {
            $username = $this->users->findById($row->userId) ? $this->users->findById($row->userId)->employeeName: "-";
            return $username;
        })
        ->edit('leaves', function($row) 
        {
            if ($row->leaves!= "") 
            {
               return $row->leaves . " days";
            } 
        })
        //->hide('depositId')
        ->toJson();
    }


    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );
  
        $leaveCategory = $this->leaveCategories->findAll();
        $users = $this->users->findAll();
        
        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'leaveCategories' => $leaveCategory, 'users' => $users]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($depositId)
    {
        $data = $this->check($depositId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->depositId,
            'id'=> $data->depositId
        );

        $leaveCategory = $this->leaveCategories->findAll();
        $users = $this->users->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'leaveCategories' => $leaveCategory, 'users' => $users]);
    }

    public function update($depositId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($depositId);
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function delete($depositId)
    {
        $data = $this->check($depositId);
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
            $const = array(
                'route' => ROUTE,
                'variable'=> VARIABLE,
                'item'=> ITEM,
                'items'=> ITEMS,
                'viewfolder'=> VIEWFOLDER,
                'identifier'=> $data->depositId,
                'id'=> $data->depositId
            );
			return view(VIEWFOLDER."delete", [VARIABLE => $data, 'const' => $const]);
		}
		else
		{
			$data = $this->check($depositId);
			if ($this->model->delete($depositId))
			{
				return redirect()->to(ROUTE)->with('success', ITEM.' deleted successfully');
			}
			else
			{
				return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
			}
		}
    }

    public function check($depositId)
	{
		$data = $this->model->findById($depositId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $depositId not found");
		}
		return $data;
	}
}
