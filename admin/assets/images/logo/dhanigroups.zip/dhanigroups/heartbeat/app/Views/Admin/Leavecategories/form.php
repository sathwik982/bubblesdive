<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="leaveCategory">Leave Category <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="leaveCategory" name="leaveCategory" placeholder="Leave Category" required value="<?= old('leaveCategory', $data->leaveCategory); ?>">
        <div class="invalid-feedback">Please choose the Leave Category</div>
    </div>
</div>