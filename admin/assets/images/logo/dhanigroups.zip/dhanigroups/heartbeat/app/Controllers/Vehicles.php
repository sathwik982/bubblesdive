<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Vehicles extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Vehicles();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Vehicles/');
        define('ITEM','Vehicle');
        define('ITEMS','Vehicles');
        define('DBTABLE','vehicles');
        define('VARIABLE','data');
        define('ROUTE','vehicles');

        session()->set('activate', "vehicles");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('vehicleId, vehicleType, vehicleRegNumber, vehicleInsuranceValidity, ownership, picture');
         
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->vehicleId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a style="padding-left:10px;" href="'.site_url(ROUTE."/delete/".$row->vehicleId).'" class="text-danger"><i class="bx bx-trash" style="font-size:20px;"></i></a>
                   ';
        })
        ->edit('ownership', function($row)
        {
            $ownerName = $this->users->findById($row->ownership) ? $this->users->findById($row->ownership)->employeeName: "-";
            return $ownerName;
        })
        ->edit('picture', function($row)
        {
            if($row->picture!="")
            {
                return "<a href='" . site_url($row->picture) . "' target = _blank>Click me</a>";
            }
            else
            {
                return "<a href='" . site_url('') . "'> - </a>"; 
            }
            
        })

        //->hide('vehicleId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );
    
        $users = $this->users->findAll();
        
        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'users' => $users]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->request->getFile('picture'))
        {
            //file upload
            $file = $this->request->getFile('picture');
            $uploadedFile = $file->getName();
            if($this->request->getFile('picture') && $uploadedFile != "")
            {
                $validated = $this->validate([
                    'picture' => [
                        'uploaded[picture]',
                        'mime_in[picture,image/jpg,image/jpeg,image/gif,image/png,application/pdf]',
                        'max_size[picture,8096]',
                    ]
                ]);
        
                if (!$validated)
                {
                    if($this->validator->getError('picture'))
                    {
                        return redirect()->back()->with('warning', $this->validator->getError('picture'))->withInput();
                    }
                    
                }

                $uploadedFile = $file->getName();
                if($uploadedFile != "")
                {
                    if (! $file->hasMoved())
                    {
                        $extension = $file->getClientExtension(); //.pdf
                        $newName = "Vehicleref_".rand().".".$extension; // rf_345454545.pdf
                        $file->move('uploads/', $newName); // 
                        $uploadedFile = "uploads/".$newName; //uploads/rf_345454545.pdf
                        $data->picture = $uploadedFile;
                    }
                }
            }
            //file upload
        }
        else
        {
            $data->picture = null;
        }

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($vehicleId)
    {
        $data = $this->check($vehicleId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->vehicleRegNumber,
            'id'=> $data->vehicleId
        );

        $users = $this->users->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'users' => $users]);
    }

    public function update($vehicleId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($vehicleId);
        if($this->request->getFile('picture'))
        {
            //file upload
            $file = $this->request->getFile('picture');
            $uploadedFile = $file->getName();
            if($this->request->getFile('picture') && $uploadedFile != "")
            {
                $validated = $this->validate([
                    'picture' => [
                        'uploaded[picture]',
                        'mime_in[picture,image/jpg,image/jpeg,image/gif,image/png,application/pdf]',
                        'max_size[picture,8096]',
                    ]
                ]);
        
                if (!$validated)
                {
                    if($this->validator->getError('picture'))
                    {
                        return redirect()->back()->with('warning', $this->validator->getError('picture'))->withInput();
                    }
                    
                }

                $uploadedFile = $file->getName();
                if($uploadedFile != "")
                {
                    if (! $file->hasMoved())
                    {
                        $extension = $file->getClientExtension(); //.pdf
                        $newName = "Vehicleref_".rand().".".$extension; // rf_345454545.pdf
                        $file->move('uploads/', $newName); // 
                        $uploadedFile = "uploads/".$newName; //uploads/rf_345454545.pdf
                        $data->picture = $uploadedFile;
                    }
                }
            }
            //file upload
        }
        else
        {
            $data->picture = null;
        }
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function delete($vehicleId)
    {
        $data = $this->check($vehicleId);
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
            $const = array(
                'route' => ROUTE,
                'variable'=> VARIABLE,
                'item'=> ITEM,
                'items'=> ITEMS,
                'viewfolder'=> VIEWFOLDER,
                'identifier'=> $data->vehicleRegNumber,
                'id'=> $data->vehicleId
            );
			return view(VIEWFOLDER."delete", [VARIABLE => $data, 'const' => $const]);
		}
		else
		{
			$data = $this->check($vehicleId);
			if ($this->model->delete($vehicleId))
			{
				return redirect()->to(ROUTE)->with('success', ITEM.' deleted successfully');
			}
			else
			{
				return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
			}
		}
    }

    public function check($vehicleId)
	{
		$data = $this->model->findById($vehicleId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $vehicleId not found");
		}
		return $data;
	}
}
