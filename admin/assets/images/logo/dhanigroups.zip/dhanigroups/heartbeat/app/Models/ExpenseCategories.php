<?php

namespace App\Models;
class ExpenseCategories extends \CodeIgniter\Model
{
    protected $table = 'expense_categories';
    protected $primaryKey = 'expenseCategoryId';
    protected $allowedFields = ['expenseCategory', 'display', 'createdDate', 'lastModifiedDate', 'requireLabor', 'requireVehicle'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'expenseCategory' => 'required',
        'requireLabor' => 'required',
        'display' => 'required',
        'requireVehicle' => 'required'
    ];

    protected $validationMessages = [
        'expenseCategory' => [
            'required' => 'Category Name is required'
        ],
        'requireLabor' => [
            'required' => 'Require Labour is required'
        ],
        'display' => [
            'required' => 'Display is required'
        ],
        'requireVehicle' => [
            'required' => 'Require Vehicle is required'
        ],
    ];

    public function findById($expenseCategoryId)
    {
        return $this->where('expenseCategoryId', $expenseCategoryId)->first();
    }
}
?>