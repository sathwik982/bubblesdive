<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?><?= $const["items"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?>
    <link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/datatables.css">
    <link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/dt-global_style.css">
<?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0"><?= $const["items"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item active"><?= $const["items"]; ?></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
        <div class="card-header">
                <div class="card-title" style="margin-bottom:0px;">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Start accordion -->
                        <div class="accordion accordion-flush" id="accordionFlushExample">
                            <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                                <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne" style="padding-top:5px; padding-bottom:5px;">
                                <i class="bx bx-filter-alt" style="font-size:20px;"></i> &nbsp; Filters
                                </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample" style="">
                                <!-- Data Filter -->
                                <div class="row" style="padding-top:10px;">
                                    <div class="col-md-2">
                                        <label style="color:#000000; font-size:12px;" for="fromDate">From Date</label>
                                        <input type="date" class="form-control" id="fromDate" name="fromDate" value="" placeholder="From Date" max="<?php echo date("Y-m-d"); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <label style="color:#000000; font-size:12px;" for="toDate">To Date</label>
                                        <input type="date" class="form-control" id="toDate" name="toDate" value="" placeholder="To Date" max="<?php echo date("Y-m-d"); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <label style="color:#000000; font-size:12px;" for="attendance">Attendance</label>
                                        <select class="form-control" id="attendance" name="attendance">
                                            <option value="">Show All</option>
                                            <option value="1">PRESENT</option>
                                            <option value="0.5">HALF-DAY</option>
                                            <option value="0">ABSENT</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label style="color:#000000; font-size:12px;" for="status">Status</label>
                                        <select class="form-control" id="status" name="status">
                                            <option value="">Show All</option>
                                            <option value="PENDING">PENDING</option>
                                            <option value="APPROVED">APPROVED</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Data Filter -->
                            </div>
                            </div>
                        </div>
                        <!-- end accordion -->
                    </div>
                </div>
                </div>
            </div>
            <div class="card-body">  
                <div class="table-responsive">
                    <table class="table table-striped" id="dataTable"> <!-- table mb-0-->
                        <thead class="thead-dark">
                            <tr>
                                <th width="30">#</th>
                                <th>Employee</th>
                                <th>Date</th>
                                <th>Labour</th>
                                <th>Type</th>
                                <th>Attendance</th>
                                <th>Distance</th>
                                <th>Picture</th>
                                <th>Status</th>
                                <th>Approver</th>
                                <th>Approved</th>
                                <th width="100">Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row -->

<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>plugins/table/datatable/datatables.js"></script>
<script>
    $(function () {
        if ($("#dataTable").length > 0) {
            c2 = $("#dataTable").DataTable({
                "processing": true,
                "serverSide": true,
                "stateSave": true,
                "responsive": true,
                "language": {
                    searchPlaceholder: "Search..."
                },
                ajax: {
                        url: basePath + "<?= $const["route"]; ?>/load",
                        data: function (d)
                        {
                            d.fromDate = $('#fromDate').val();
                            d.toDate = $('#toDate').val();
                            d.attendance = $('#attendance').val();
                            d.status = $('#status').val();
                           
                        }
                    },
                "dom": "<'dt--top-section'<'row'<'col-12 col-sm-2 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-8 d-flex justify-content-sm-center justify-content-center mt-sm-0 mt-3'f><'col-12 col-sm-2 d-flex justify-content-sm-end justify-content-center mt-sm-0 pt-2'<'newBtn'>>>>" +
            "<'table-responsive'tr>" +
            "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
            initComplete: function(){
                $("div.newBtn").html('<a href="<?= site_url($const["route"].'/new'); ?>" class="btn btn-success btn-sm waves-effect btn-label waves-light"><i class="bx bx-plus-medical label-icon"></i> New <?= $const["item"]; ?></a>');           
            },
            "oLanguage": {
                "oPaginate": {
                    "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
                    "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
                },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
                "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
                columnDefs: [
                    {
                        targets: 11,
                        orderable: false
                    }                      
                    ]
            });
        }
        $('#fromDate').change(function(event) {
            c2.ajax.reload();
        });
   
        $('#toDate').change(function(event) {
            c2.ajax.reload();
        });

        $('#status').change(function(event) {
            c2.ajax.reload();
        });
        $('#attendance').change(function(event) {
            c2.ajax.reload();
        });
    });
</script>
<?= $this->endSection() ?>
