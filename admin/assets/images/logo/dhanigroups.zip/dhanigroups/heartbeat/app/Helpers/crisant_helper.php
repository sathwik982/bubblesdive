<?php

if(!function_exists('util_array_trim'))
{
   function util_array_trim(array &$array, $filter = true)
    {
        array_walk_recursive($array, function (&$value) use ($filter) {
            $value = trim($value);
            if ($filter)
            {
                $value = filter_var($value, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                $value = htmlspecialchars($value);
                $value = stripslashes($value);
                $value = trim($value);
            }
        });

        return $array;
    }
}

?>