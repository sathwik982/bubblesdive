<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?><?= $const["items"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?>
    <link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/datatables.css">
    <link rel="stylesheet" type="text/css" href="<?= site_url(); ?>plugins/table/datatable/dt-global_style.css">
<?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0"><?= $const["items"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item active"><?= $const["items"]; ?></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">  
                <div class="table-responsive">
                    <table class="table table-striped" id="dataTable"> <!-- table mb-0-->
                        <thead class="thead-dark">
                            <tr>
                                <th width="30">#</th>
                                <th>Vehicle Type</th>
                                <th>Vehicle Registration No</th>
                                <th>Vehicle Insurance Validity</th>
                                <th>Ownership</th>
                                <th>Vehicle Picture</th>
                                <th width="100">Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row -->

<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>plugins/table/datatable/datatables.js"></script>
<script>
    $(function () {
        if ($("#dataTable").length > 0) {
            $("#dataTable").DataTable({
                "processing": true,
                "serverSide": true,
                "stateSave": true,
                "responsive": true,
                "language": {
                    searchPlaceholder: "Search..."
                },
                "ajax": basePath + "<?= $const["route"]; ?>/load",
                "dom": "<'dt--top-section'<'row'<'col-12 col-sm-2 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-8 d-flex justify-content-sm-center justify-content-center mt-sm-0 mt-3'f><'col-12 col-sm-2 d-flex justify-content-sm-end justify-content-center mt-sm-0 pt-2'<'newBtn'>>>>" +
            "<'table-responsive'tr>" +
            "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
            initComplete: function(){
                $("div.newBtn").html('<a href="<?= site_url($const["route"].'/new'); ?>" class="btn btn-success btn-sm waves-effect btn-label waves-light"><i class="bx bx-plus-medical label-icon"></i> New <?= $const["item"]; ?></a>');           
            },
            "oLanguage": {
                "oPaginate": {
                    "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
                    "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
                },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
                "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
                columnDefs: [
                    {
                        targets: 6,
                        orderable: false
                    }                      
                    ]
            });
        }
    });
</script>
<?= $this->endSection() ?>
