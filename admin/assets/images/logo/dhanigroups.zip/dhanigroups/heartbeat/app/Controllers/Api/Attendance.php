<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Attendance extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside attendance/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

    public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->attendance->select('COUNT(attendanceId) as total')->where('userId', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->attendance->where('userId', $userId)->orderBy('attendanceId', 'DESC')->limit($limit, $offset)->find();

                    foreach($data as $attendance)
                    {
                        if($attendance->picture)
                        {
                            $attendance->picture = site_url($attendance->picture);
                        }
                        
                        $nextApproverName = $this->users->findById($attendance->nextApprover) ? $this->users->findById($attendance->nextApprover)->employeeName: "-";
                        $attendance->nextApproverName = $nextApproverName;
                    }

                    if($data)
                    {
                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");

                    if(!$startDate || !$endDate)
                    {
                        $response = [
                            "status" => 500,
                            "message" => "Please provide Start Date & End Date",
                            "error" => true,
                            "data" => []
                        ];
                    }
                    else
                    {
                        //Content Goes Here
                        $data = $this->attendance->where('userId', $userId)->where("date BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE)->findAll();

                        if($data)
                        {
                            foreach($data as $attendance)
                            {
                                if($attendance->picture)
                                {
                                    $attendance->picture = site_url($attendance->picture);
                                }
                                
                                $nextApproverName = $this->users->findById($attendance->nextApprover) ? $this->users->findById($attendance->nextApprover)->employeeName: "-";
                                $attendance->nextApproverName = $nextApproverName;
                            }

                            $response = [
                                "status" => 200,
                                "message" => "Data Fetched successfully",
                                "error" => false,
                                "data" => $data
                            ];
                        }
                        else
                        {
                            $response = [
                                "status" => 500,
                                "message" => "Sorry, no records found for the specified dates.",
                                "error" => true,
                                "data" => []
                            ];
                        }
                        //Content Goes Here
                    }
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function check()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    $now = date("H");
                    $settings = $this->settings->findById(1);
                    $morningStart = $settings->morningAttendanceStart;
                    $morningStart = date("Y-m-d ").$morningStart.":00";
                    $morningStart = date("H", strtotime($morningStart));
                    $morningEnd = $settings->morningAttendanceEnd;
                    $morningEnd = date("Y-m-d ").$morningEnd.":00";
                    $morningEnd = date("H", strtotime($morningEnd));

                    $eveningStart = $settings->eveningAttendanceStart;
                    $eveningStart = date("Y-m-d ").$eveningStart.":00";
                    $eveningStart = date("H", strtotime($eveningStart));
                    $eveningEnd = $settings->eveningAttendanceEnd;
                    $eveningEnd = date("Y-m-d ").$eveningEnd.":00";
                    $eveningEnd = date("H", strtotime($eveningEnd));

                    if($now >= $morningStart && $now <= $morningEnd)
                    {
                        $data = array('status' => 'ACCEPT', 'attendanceTye' => 'MORNING');
                        $response = [
                            "status" => 200,
                            "message" => "ACCEPT",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else if($now >= $eveningStart && $now <= $eveningEnd)
                    {
                        $data = array('status' => 'ACCEPT', 'attendanceTye' => 'EVENING');
                        $response = [
                            "status" => 200,
                            "message" => "ACCEPT",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $data = array('status' => 'REJECT');
                        $response = [
                            "status" => 500,
                            "message" => "REJECT",
                            "error" => true,
                            "data" => $data
                        ];
                    }

                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function new()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

                $headquarterId = $this->profile->findByUserId($userId) ? $this->profile->findByUserId($userId)->headquarterId: null;

                $reportTo = $this->profile->findByUserId($userId) ? $this->profile->findByUserId($userId)->reportTo: null;

                $headquarter = ($headquarterId) ? $this->headquarters->findById($headquarterId) : null;

				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $uploadFolder = "uploads/";

                    $attendanceLatt = $this->request->getVar("attendanceLatt");
				    $attendanceLong = $this->request->getVar("attendanceLong");

                    $coordinate1 = new Coordinate($attendanceLatt, $attendanceLong); // Mauna Kea Summit
                    $coordinate2 = new Coordinate($headquarter->headQuarterLatt, $headquarter->headQuarterLong); // Haleakala Summit

                    $calculator = new Vincenty();
                    $distance = $calculator->getDistance($coordinate1, $coordinate2);
                    $distance = round(($distance/1000),2);

                    $distanceFromHQ = $distance;
                    $nextApprover = $reportTo;

                    $post = json_decode(json_encode($this->request->getVar()), true);

                    if(!$this->request->getVar("picture"))
                    {
                        $post["picture"] = null;
                    }
                    else
                    {
                        $picture = $this->request->getVar("picture");
                        $imageName = "attendance_".$userId."_".date("Ymd")."_".rand(1,1000).".jpg";
                        if(file_exists($uploadFolder.$imageName))
                        {
                            $imageName = rand(1,1000)."_".$imageName;
                        }

                        file_put_contents($uploadFolder.$imageName, base64_decode($picture));
                        $post["picture"] = $uploadFolder.$imageName;
                    }

                    $data = new Entity($post);
                    $data->userId = $userId;
                    $data->date = date("Y-m-d");
                    $data->distanceFromHQ = $distanceFromHQ;
                    $data->nextApprover = $nextApprover;

                    $attendance = $this->attendance->where('userId', $userId)->where('date', date("Y-m-d"))->where('attendanceType', $this->request->getVar('attendanceType'))->first();

                    if(!$attendance)
                    {
                        if ($this->attendance->insert($data))
                        {
                            $response = [
                                "status" => 200,
                                "message" => "Attendance recorded successfully",
                                "error" => false,
                                "data" => []
                            ];
                        }
                        else
                        {
                            $response = [
                                "status" => 500,
                                "message" => "Sorry, unable to record attendance",
                                "error" => true,
                                "data" => $this->attendance->errors()
                            ];
                        }
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "Duplicate attendance",
                            "error" => true,
                            "data" => []
                        ];
                    }

                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

}
