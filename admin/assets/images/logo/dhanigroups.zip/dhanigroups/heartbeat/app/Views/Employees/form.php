<?php if (session()->has('error')) : ?>
<div class="row">
   <div mg="6" class="col">
      <div class="alert alert-danger" role="alert">
         <ul style="margin-bottom:0px;">
            <?php foreach (session('error') as $error) : ?>
            <li><?= $error ?></li>
            <?php endforeach; ?>
         </ul>
      </div>
   </div>
</div>
<?php endif ?>
<div class="row">
   <div class="col-md-3">
      <div class="mb-3">
         <label for="employeeId">Employee ID</label>
         <input type="text" class="form-control" id="employeeId" name="employeeId" placeholder="Employee ID"  required value="<?= old('employeeId', $data->employeeId); ?>">
      </div>
   </div>
   <div class="col-md-3">
      <div class="mb-3">
         <label for="employeeName">Employee Name</label>
         <input type="text" class="form-control" id="employeeName" name="employeeName" placeholder="Employee Name" value="<?= old('employeeName', $data->employeeName); ?>">
      </div>
   </div>
   <div class="col-md-3 mb-3">
      <label for="mobileNumber">Mobile Number </label>
      <input type="number" class="form-control" id="mobileNumber" name="mobileNumber" placeholder = "Mobile Number" value="<?= old('mobileNumber', $data->mobileNumber); ?>" oninput="this.value = this.value.replace(/\D/g, '').slice(0, 10)" pattern="[0-9]{10}" minlength="10" laxlength="10" required>
   </div>
   <div class="col-md-3" id="designationId">
      <div class="mb-3">
         <label for="designationId">Designation</label>
         <select class="form-control" id="designationId" name="designationId">
            <option value="">Please Select</option>
            <?php
               foreach($designations as $designation)
               {
                   $selected = null;
               
                   (old('designationId', $profile->designationId) == $designation->designationId) ? $selected = "selected" : $selected == "";
                   echo '<option value="'.$designation->designationId.'" '.$selected.'>'.$designation->designation.'</option>';
               
               }
               ?>
         </select>
      </div>
   </div>
   <div class="col-md-3" id="dateOfBirth">
      <div class="mb-3">
         <label for="dateOfBirth">Date Of Birth</label>
         <input class="form-control" value="<?= $profile->dateOfBirth; ?>" id="dateOfBirth" name="dateOfBirth" placeholder="Date Of Birth">
      </div>
   </div>
   <div class="col-md-3" id="dateOfJoining">
      <div class="mb-3">
         <label for="dateOfJoining">Date of Joining</label>
         <input class="form-control" value="<?= $profile->dateOfJoining; ?>" id="dateOfJoining" name="dateOfJoining" placeholder="Date of Joining">
      </div>
   </div>
   <div class="col-md-3" id="motherName">
      <div class="mb-3">
         <label for="motherName">Mother Name</label>
         <input class="form-control" value="<?= $profile->motherName; ?>" id="motherName" name="motherName" placeholder="Mother Name">
      </div>
   </div>
   <div class="col-md-3" id="fatherName">
      <div class="mb-3">
         <label for="fatherName">Father Name</label>
         <input class="form-control" value="<?= $profile->fatherName; ?>" id="fatherName" name="fatherName" placeholder="Father Name">
      </div>
   </div>
   <div class="col-md-3" id="adhaarNumber">
      <div class="mb-3">
         <label for="adhaarNumber">Adhaar Number</label>
         <input class="form-control" value="<?= $profile->adhaarNumber; ?>" id="adhaarNumber" name="adhaarNumber" placeholder="Adhaar Number">
      </div>
   </div>
   <div class="col-md-3" id="panNumber">
      <div class="mb-3">
         <label for="panNumber">Pan Number</label>
         <input class="form-control" value="<?= $profile->panNumber; ?>" id="panNumber" name="panNumber" placeholder="Pan Number">
      </div>
   </div>
   <div class="col-md-3" id="drivingLicenseNumber">
      <div class="mb-3">
         <label for="drivingLicenseNumber">DL Number</label>
         <input class="form-control" value="<?= $profile->drivingLicenseNumber; ?>" id="drivingLicenseNumber" name="drivingLicenseNumber" placeholder="DL Number">
      </div>
   </div>
   <div class="col-md-3" id="esicNumber">
      <div class="mb-3">
         <label for="esicNumber">ESIC Number</label>
         <input class="form-control" value="<?= $profile->esicNumber; ?>" id="esicNumber" name="esicNumber" placeholder="ESIC Number">
      </div>
   </div>
   <div class="col-md-3" id="personalInsurance">
      <div class="mb-3">
         <label for="personalInsurance">Personal Insurance</label>
         <input class="form-control" value="<?= $profile->personalInsurance; ?>" id="personalInsurance" name="personalInsurance" placeholder="Personal Insurance">
      </div>
   </div>
   <div class="col-md-3" id="healthInsurance">
      <div class="mb-3">
         <label for="healthInsurance">Health Insurance</label>
         <input class="form-control" value="<?= $profile->healthInsurance; ?>" id="healthInsurance" name="healthInsurance" placeholder="Health Insurance">
      </div>
   </div>
   <div class="col-md-3" id="accidentalInsurance">
      <div class="mb-3">
         <label for="accidentalInsurance">Accidental Insurance</label>
         <input class="form-control" value="<?= $profile->accidentalInsurance; ?>" id="accidentalInsurance" name="accidentalInsurance" placeholder="Accidental Insurance">
      </div>
   </div>
   <div class="col-md-3" id="highestQualification">
      <div class="mb-3">
         <label for="highestQualification">Highesh Qualification</label>
         <select class="form-control" id="highestQualification" name="highestQualification">
            <option value="">Please Select</option>
            <?php
               foreach($qualifications as $qualification)
               {
                   $selected = null;
               
                   (old('qualificationId', $profile->highestQualification) == $qualification->qualificationId) ? $selected = "selected" : $selected == "";
               
                   echo '<option value="'.$qualification->qualificationId.'" '.$selected.'>'.$qualification->qualificationName.'</option>';
               }
               ?>
         </select>
      </div>
   </div>
   <div class="col-md-3" id="martialStatus">
      <div class="mb-3">
         <label for="martialStatus">Martial Status</label>
         <input class="form-control" value="<?= $profile->martialStatus; ?>" id="martialStatus" name="martialStatus" placeholder="Martial Status">
      </div>
   </div>
   <div class="col-md-3" id="noOfChildren">
      <div class="mb-3">
         <label for="noOfChildren">No of Children</label>
         <input class="form-control" value="<?= $profile->noOfChildren; ?>" id="noOfChildren" name="noOfChildren" placeholder="No of Children">
      </div>
   </div>
   <div class="col-md-3" id="height">
      <div class="mb-3">
         <label for="height">Height</label>
         <input class="form-control" value="<?= $profile->height; ?>" id="height" name="height" placeholder="Height">
      </div>
   </div>
   <div class="col-md-3" id="weight">
      <div class="mb-3">
         <label for="weight">Weight</label>
         <input class="form-control" value="<?= $profile->weight; ?>" id="weight" name="weight" placeholder="Weight">
      </div>
   </div>
   <div class="col-md-3" id="presentAddress">
      <div class="mb-3">
         <label for="presentAddress">Present Address</label>
         <input class="form-control" value="<?= $profile->presentAddress; ?>" id="presentAddress" name="presentAddress" placeholder="Present Address">
      </div>
   </div>
   <div class="col-md-3" id="permanentAddess">
      <div class="mb-3">
         <label for="permanentAddess">Permanent Address</label>
         <input class="form-control" value="<?= $profile->permanentAddess; ?>" id="permanentAddess" name="permanentAddess" placeholder="Permanent Address">
      </div>
   </div>
   <div class="col-md-3" id="projectId">
      <div class="mb-3">
         <label for="projectId">Project</label>
         <select class="form-control" id="projectId" name="projectId">
            <option value="">Please Select</option>
            <?php
               foreach($projects as $project)
               {
                   $selected = null;
               
                   (old('projectId', $profile->projectId) == $project->projectId) ? $selected = "selected" : $selected == "";
               
                   echo '<option value="'.$project->projectId.'" '.$selected.'>'.$project->projectName.'</option>';
               }
               ?>
         </select>
      </div>
   </div>
   <div class="col-md-3" id="headquarterId">
      <div class="mb-3">
         <label for="headquarterId">Headquarter</label>
         <select class="form-control" id="headquarterId" name="headquarterId">
            <option value="">Please Select</option>
            <?php
               foreach($headquarters as $headquarter)
               {
                   $selected = null;
               
                   (old('headQuarterId', $profile->headquarterId) == $headquarter->headQuarterId) ? $selected = "selected" : $selected == "";
               
                   echo '<option value="'.$headquarter->headQuarterId.'" '.$selected.'>'.$headquarter->headQuarterName.'</option>';
               }
               ?>
         </select>
      </div>
   </div>
   <div class="col-md-3" id="salary">
      <div class="mb-3">
         <label for="salary">Salary</label>
         <input class="form-control" value="<?= $profile->salary; ?>" id="salary" name="salary" placeholder="Salary">
      </div>
   </div>
   <div class="col-md-3">
      <div class="mb-3">
         <label for="reportTo">Report To</label>
         <select class="form-control" id="reportTo" name="reportTo">
            <option value="">Please Select</option>
            <?php
               foreach($users as $user)
               {
                  $selected = null;
               
                  (old('userId', $profile->reportTo) == $user->userId) ? $selected = "selected" : $selected == "";
               
                  echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
               }
               ?>
         </select>
      </div>
   </div>
   <div class="col-md-3" id="leaveBalance">
      <div class="mb-3">
         <label for="leaveBalance">Leave Balance</label>
         <input class="form-control" value="<?= $profile->leaveBalance; ?>" id="leaveBalance" name="leaveBalance" placeholder="Leave Balance">
      </div>
   </div>
</div>
