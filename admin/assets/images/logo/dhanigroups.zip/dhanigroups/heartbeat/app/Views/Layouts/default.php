<!doctype html>
<html lang="en" >
   <head>
      <meta charset="utf-8" />
      <title>Dhani Groups | <?= $this->renderSection("title") ?></title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta content="" name="description" />
      <meta content="Crisant Technologies" name="author" />
      <link rel="shortcut icon" href="<?= site_url('assets/images/logo-small.png'); ?>">
      <link href="<?= site_url(); ?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
      <link href="<?= site_url(); ?>assets/css/snackbar.min.css" id="app-style" rel="stylesheet" type="text/css" />
      <?= $this->renderSection("headercss") ?>
      <?= $this->renderSection("headerjs") ?>
   </head>
   <body data-layout="horizontal" data-topbar="dark">
      <!-- Begin page -->
      <div id="layout-wrapper">
         <!-- Left Sidebar End -->
         <header id="page-topbar" class="ishorizontal-topbar">
            <div class="navbar-header">
               <div class="d-flex">
                  <!-- LOGO -->
                  <div class="navbar-brand-box">
                     <a href="<?= site_url(); ?>" class="logo logo-dark">
                     <span class="logo-sm">
                     <img src="<?= site_url(); ?>assets/images/logo-small.png" alt="" height="40">
                     </span>
                     <span class="logo-lg">
                     <img src="<?= site_url(); ?>assets/images/logo-small.png" alt="" height="40">
                     </span>
                     </a>
                     <a href="<?= site_url(); ?>" class="logo logo-light">
                     <span class="logo-sm">
                     <img src="<?= site_url(); ?>assets/images/logo-small.png" alt="" height="40">
                     </span>
                     <span class="logo-lg">
                     <img src="<?= site_url(); ?>assets/images/logo-small.png" alt="" height="40">
                     </span>
                     </a>
                  </div>
                  <button type="button" class="btn btn-sm px-3 font-size-16 d-lg-none header-item" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                  <i class="fa fa-fw fa-bars"></i>
                  </button>
                  <div class="topnav">
                     <nav class="navbar navbar-light navbar-expand-lg topnav-menu">
                        <div class="collapse navbar-collapse" id="topnav-menu-content">
                           <ul class="navbar-nav">
                              <li class="nav-item">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "dashboard") echo "active"; ?>" href="<?= site_url('dashboard'); ?>" id="topnav-dashboard" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <i class='bx bx-tachometer'></i>
                                 <span data-key="t-dashboards">Dashboard</span>
                                 </a>
                              </li>
                              <li class="nav-item dropdown">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "attendance") echo "active"; ?>" href="javascript:void(0);" id="topnav-pages" role="button">
                                    <i class='bx bx-time-five'></i>
                                    <span data-key="t-apps">Attendance</span> 
                                    <div class="arrow-down"></div>
                                 </a>
                                 <div class="dropdown-menu" aria-labelledby="topnav-pages">
                                    <a href="<?= site_url('attendance'); ?>" class="dropdown-item">Attendance</a>
                                    <a href="<?= site_url('labourattendance'); ?>" class="dropdown-item">Labour Attendance</a>
                                 </div>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "expenses") echo "active"; ?>" href="<?= site_url('expenses'); ?>" id="topnav-dashboard" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <i class='bx bx-pie-chart-alt-2'></i>
                                 <span data-key="t-dashboards">Expenses</span>
                                 </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "leaves") echo "active"; ?>" href="<?= site_url('leaves'); ?>" id="topnav-dashboard" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <i class='bx bx-add-to-queue'></i>
                                 <span data-key="t-dashboards">Leaves</span>
                                 </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "vehicles") echo "active"; ?>" href="<?= site_url('vehicles'); ?>" id="topnav-dashboard" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <i class='bx bx-buoy'></i>
                                 <span data-key="t-dashboards">Vehicles</span>
                                 </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "employees") echo "active"; ?>" href="<?= site_url('employees'); ?>" id="topnav-dashboard" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <i class='bx bx-user'></i>
                                 <span data-key="t-dashboards">Employees</span>
                                 </a>
                              </li>
                              <li class="nav-item dropdown">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "reports") echo "active"; ?>" href="javascript:void(0);" id="topnav-pages" role="button">
                                    <i class='bx bx-stats'></i>
                                    <span data-key="t-apps">Reports</span> 
                                    <div class="arrow-down"></div>
                                 </a>
                                 <div class="dropdown-menu" aria-labelledby="topnav-pages">
                                    <a href="<?= site_url('expensereports'); ?>" class="dropdown-item">Expense Reports</a>
                                    <a href="<?= site_url('attendancereports'); ?>" class="dropdown-item">Attendance Reports</a>
                                    <a href="<?= site_url('labourattendancereports'); ?>" class="dropdown-item">Labour Attendance Reports</a>
                                    <a href="<?= site_url('leavereports'); ?>" class="dropdown-item">Leave Reports</a>
                                 </div>
                              </li>
                              <?php if(session()->get('userRole') == "ADMIN") : ?>
                              <li class="nav-item dropdown">
                                 <a class="nav-link dropdown-toggle arrow-none <?php if (session()->get('activate') == "admin") echo "active"; ?>" href="javascript:void(0);" id="topnav-pages" role="button">
                                    <i class='bx bx-grid-alt'></i>
                                    <span data-key="t-apps">Admin</span> 
                                    <div class="arrow-down"></div>
                                 </a>
                                 <div class="dropdown-menu" aria-labelledby="topnav-pages">
                                    <a href="<?= site_url('admin/headquarters'); ?>" class="dropdown-item">Headquarters</a>
                                    <a href="<?= site_url('admin/expensecategories'); ?>" class="dropdown-item">Expense Categories</a>
                                    <a href="<?= site_url('admin/leavecategories'); ?>" class="dropdown-item">Leave Categories</a>
                                    <a href="<?= site_url('admin/designations'); ?>" class="dropdown-item">Designations</a>
                                    <a href="<?= site_url('admin/qualifications'); ?>" class="dropdown-item">Qualifications</a>
                                    <a href="<?= site_url('admin/projects'); ?>" class="dropdown-item">Projects</a>
                                    <a href="<?= site_url('admin/leavedeposits'); ?>" class="dropdown-item">Leave Deposits</a>
                                    <a href="<?= site_url('admin/users'); ?>" class="dropdown-item">System Users</a>
                                    <a href="<?= site_url('admin/settings'); ?>" class="dropdown-item">Settings</a>
                                 </div>
                              </li>
                              <?php endif; ?>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
               <div class="d-flex">
                  <div class="dropdown d-none d-sm-inline-block">
                     <button type="button" class="btn header-item light-dark" id="mode-setting-btn">
                     <i data-feather="moon" class="icon-sm layout-mode-dark "></i>
                     <i data-feather="sun" class="icon-sm layout-mode-light"></i>
                     </button>
                  </div>
                  <div class="dropdown d-inline-block">
                     <button type="button" class="btn header-item user text-start d-flex align-items-center" id="page-header-user-dropdown"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="bx bxs-user me-3 rounded-circle avatar-sm" style="font-size:30px;"></i>
                     </button>
                     <div class="dropdown-menu dropdown-menu-end pt-0">
                        <a class="dropdown-item" href="<?= site_url('login/logout'); ?>"><i class='bx bx-log-out text-muted font-size-18 align-middle me-1'></i> <span class="align-middle">Logout</span></a>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <!-- ============================================================== -->
         <!-- Start right Content here -->
         <!-- ============================================================== -->
         <div class="main-content">
            <div class="page-content">
               <div class="container-fluid">
                  <?= $this->renderSection("content") ?>
               </div>
               <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <footer class="footer">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-sm-6">
                     &copy; <script>document.write(new Date().getFullYear())</script> Dhani Groups. All rights reserved.
                     </div>
                     <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">
                           <small>version 1.0 &nbsp; - &nbsp; Last updated on 26<sup>th</sup> June 2023</small>
                        </div>
                     </div>
                  </div>
               </div>
            </footer>
         </div>
         <!-- end main content-->
      </div>
      <!-- END layout-wrapper -->
      <script src="<?= site_url(); ?>assets/js/libs/jquery-3.1.1.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/metismenujs/metismenujs.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/simplebar/simplebar.min.js"></script>
      <script src="<?= site_url(); ?>assets/libs/feather-icons/feather.min.js"></script>
      <script src="<?= site_url(); ?>assets/js/snackbar.js"></script>
      <script src="<?= site_url(); ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>
      <?php if (session()->has('successok')) : ?>
      <script>
         Swal.fire({
            title: 'Good job!',
            text: "<?= session('successok') ?>",
            icon: "success",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('warning')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('warning') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('danger')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('danger') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
      <?php endif; ?>
      <?php if (session()->has('reload')) : ?>
          <script>
            var t;
            Swal.fire({
              title: "Please wait !",
              html: "<?= session('reload') ?>",
              timer: 2e3,
              timerProgressBar: !0,
              didOpen: function() {
                  Swal.showLoading(), t = setInterval(function() {
                      var t, e = Swal.getHtmlContainer();
                      !e || (t = e.querySelector("b")) && (t.textContent = Swal.getTimerLeft())
                  }, 100)
              },
              onClose: function() {
                  clearInterval(t)
              }
          });
          </script>
      <?php endif; ?>
      <?php if (session()->has('success')) : ?>
          <script>
            var t;
            Swal.fire({
              title: "Please wait !",
              html: "<?= session('success') ?>",
              timer: 1e3,
              timerProgressBar: !1,
              didOpen: function() {
                  Swal.showLoading(), t = setInterval(function() {
                      var t, e = Swal.getHtmlContainer();
                      !e || (t = e.querySelector("b")) && (t.textContent = Swal.getTimerLeft())
                  }, 100)
              },
              onClose: function() {
                  clearInterval(t)
              }
          });
          </script>
      <?php endif; ?>
      <?php if (session()->has('toast')) : ?>
          <script>
            Snackbar.show(
              {
                text: "<?= session('toast') ?>",
                pos: 'bottom-left'
              });
          </script>
      <?php endif; ?>
      <script>
         var basePath = "<?= site_url('/'); ?>";
      </script>
      <?= $this->renderSection("footerjs") ?>
      <script src="<?= site_url(); ?>assets/js/app.js"></script>
   </body>
</html>
