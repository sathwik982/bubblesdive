<?php

namespace App\Controllers\Admin;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Projects extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Projects();
        include_once "heartbeat/app/Controllers/models.php";
        
        define('VIEWFOLDER','Admin/Projects/');
        define('ITEM','Project');
        define('ITEMS','Projects');
        define('DBTABLE','projects');
        define('VARIABLE','data');
        define('ROUTE','admin/projects');

        session()->set('activate', "admin");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        
        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('projectId, projectName, projectLocation, headQuarterId, createdDate, lastModifiedDate');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->projectId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a style="padding-left:10px;" href="'.site_url(ROUTE."/delete/".$row->projectId).'" class="text-danger"><i class="bx bx-trash" style="font-size:20px;"></i></a>
                   ';
        })
        ->edit('headQuarterId', function($row)
        {
            $headQuarterName = $this->headquarters->findById($row->headQuarterId) ? $this->headquarters->findById($row->headQuarterId)->headQuarterName: "-";
            return $headQuarterName;
        })
        
        
        //->hide('projectId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );
        
        
        $headquarters = $this->headquarters->findAll();

        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'headquarters' =>  $headquarters]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($projectId)
    {
        $data = $this->check($projectId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->projectName,
            'id'=> $data->projectId
        );

        $headquarters = $this->headquarters->findAll();

        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'headquarters' =>  $headquarters]);
    }

    public function update($projectId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($projectId);
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function delete($projectId)
    {
        $data = $this->check($projectId);
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
            $const = array(
                'route' => ROUTE,
                'variable'=> VARIABLE,
                'item'=> ITEM,
                'items'=> ITEMS,
                'viewfolder'=> VIEWFOLDER,
                'identifier'=> $data->projectName,
                'id'=> $data->projectId
            );
			return view(VIEWFOLDER."delete", [VARIABLE => $data, 'const' => $const]);
		}
		else
		{
			$data = $this->check($projectId);
			if ($this->model->delete($projectId))
			{
				return redirect()->to(ROUTE)->with('success', ITEM.' deleted successfully');
			}
			else
			{
				return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
			}
		}
    }

    public function check($projectId)
	{
		$data = $this->model->findById($projectId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $projectId not found");
		}
		return $data;
	}
}
