<?php

namespace App\Controllers\Admin;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Leavecategories extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\LeaveCategories();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Admin/Leavecategories/');
        define('ITEM','Leave Category');
        define('ITEMS','Leave Categories');
        define('DBTABLE','leave_categories');
        define('VARIABLE','data');
        define('ROUTE','admin/leavecategories');

        session()->set('activate', "admin");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('leaveCategoryId, leaveCategory, createdDate, lastModifiedDate');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->leaveCategoryId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a style="padding-left:10px;" href="'.site_url(ROUTE."/delete/".$row->leaveCategoryId).'" class="text-danger"><i class="bx bx-trash" style="font-size:20px;"></i></a>
                   ';
        })
        //->hide('leaveCategoryId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );  

        $leaveCategories = $this->leaveCategories->findAll();

        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'leaveCategories' => $leaveCategories]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($leaveCategoryId)
    {
        $data = $this->check($leaveCategoryId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->leaveCategory,
            'id'=> $data->leaveCategoryId
        );

        $leaveCategories = $this->leaveCategories->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'leaveCategories' => $leaveCategories]);
    }

    public function update($leaveCategoryId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($leaveCategoryId);
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function delete($leaveCategoryId)
    {
        $data = $this->check($leaveCategoryId);
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
            $const = array(
                'route' => ROUTE,
                'variable'=> VARIABLE,
                'item'=> ITEM,
                'items'=> ITEMS,
                'viewfolder'=> VIEWFOLDER,
                'identifier'=> $data->leaveCategory,
                'id'=> $data->leaveCategoryId
            );
			return view(VIEWFOLDER."delete", [VARIABLE => $data, 'const' => $const]);
		}
		else
		{
			$data = $this->check($leaveCategoryId);
			if ($this->model->delete($leaveCategoryId))
			{
				return redirect()->to(ROUTE)->with('success', ITEM.' deleted successfully');
			}
			else
			{
				return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
			}
		}
    }

    public function check($leaveCategoryId)
	{
		$data = $this->model->findById($leaveCategoryId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $leaveCategoryId not found");
		}
		return $data;
	}
}
