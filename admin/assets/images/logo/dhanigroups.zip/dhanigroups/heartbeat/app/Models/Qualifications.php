<?php

namespace App\Models;

use CodeIgniter\Model;

class Qualifications extends Model
{
    protected $table = 'qualifications';
    protected $primaryKey = 'qualificationId';
    protected $allowedFields = ['qualificationName', 'createdDate', 'lastModifiedDate'];
    protected $useTimestamps = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules = [
        'qualificationName' => 'required|max_length[255]'
    ];

    protected $validationMessages = [
        'qualificationName' => [
            'required' => 'Qualification Name is required.',
            'max_length' => 'Qualification Name exceeds the maximum length.'
        ]
    ];

    public function findById($qualificationId)
    {
        return $this->where('qualificationId', $qualificationId)->first();
    }
}
