<?php

namespace App\Models;
class LeaveDeposits extends \CodeIgniter\Model
{
    
    protected $table = 'leave_deposits';
    protected $primaryKey = 'depositId';
    protected $allowedFields = ['userId', 'leaveCategoryId', 'leaves', 'depositedBy', 'createdDate', 'lastModifiedDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'leaves' => 'required',
        'leaveCategoryId' => 'required',
         
    ];

    protected $validationMessages = [
        'leaves' => [
            'required' => 'Please enter the no of leaves'
        ],
        'leaveCategoryId' => [
            'required' => 'Please enter the leave category'
        ]
    ];

    public function findById($depositId)
    {
        return $this->where('depositId', $depositId)->first();
    }
}
?>