<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Leavereports extends BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Leaves();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Reports/Leavereports/');
        define('ITEM','Leave');
        define('ITEMS','Leave Reports');
        define('DBTABLE','leaves');
        define('VARIABLE','data');
        define('ROUTE','leavereports');

        session()->set('activate', "reports");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        if ($_SERVER['REQUEST_METHOD'] == 'POST') 
        {
            
            $data = array();
        
            $post = $this->request->getPost();
        
            $fromDate = date("Y-m-d", strtotime($post["fromDate"]));
            $toDate = date("Y-m-d", strtotime($post["toDate"]));
        
            $query = $this->leaves->select('leaveId, userId, leaveCategoryId, fromDate, toDate, total, status, nextApprover, approvedBy');
        
            if ($post["fromDate"] && $post["toDate"]) 
            {
                $query->where("DATE(createdDate) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'");
            } 
            elseif ($post["fromDate"]) 
            {
                $query->where("DATE(createdDate) >= '" . $fromDate . "'");
            } 
            elseif ($post["toDate"]) 
            {
                $query->where("DATE(createdDate) <= '" . $toDate . "'");
            }
            if ($post["status"]) 
            {
                $query->where('status', $post["status"]);
            }

        
            $leaves = $query->findAll();
        
            foreach ($leaves as $leave) 
            {
                $leave->userId = $this->users->findById($leave->userId) ? $this->users->findById($leave->userId)->employeeName:"-";
                $leave->leaveCategoryId = $this->leaveCategories->findById($leave->leaveCategoryId) ? $this->leaveCategories->findById($leave->leaveCategoryId)->leaveCategory: "-";
                $leave->nextApprover = $this->users->findById($leave->nextApprover) ? $this->users->findById($leave->nextApprover)->employeeName : "-";
                $leave->approvedBy = $this->users->findById($leave->approvedBy) ? $this->users->findById($leave->approvedBy)->employeeName : "-";
                if($leave->status == "PENDING")
                {
                    $leave->status = "<span class='badge badge-soft-danger font-size-12'>".$leave->status."</span>";
                }
                else
                {
                    $leave->status = "<span class='badge badge-soft-success font-size-12'>".$leave->status."</span>";
                }

            }
        
        $data = array('leaves' => $leaves);

        }
        else
        {
        
        $post = array();
        $data = array();
    
        }

        $users = $this->users->findAll();
        $leaveCategories = $this->leaveCategories->findAll();
       
        return view(VIEWFOLDER.'index', ['const' => $const, 'data' => $data, 'post' => $post, 'users' => $users, 'leaveCategories' => $leaveCategories]);
    }
    

}
