<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>View <?= $const["item"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0">View <?= $const["item"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item"><a href="<?= site_url($const["route"]); ?>"><?= $const["items"]; ?></a></li>
               <li class="breadcrumb-item active"><a href="<?= site_url($const["route"].'/edit/'.$const["id"]); ?>"><?= $const["identifier"]; ?></a></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->
<!-- end row -->
<div class="row">
   <div class="col-lg-12">
      <?php $attributes = array('class' => 'needs-validation', 'id' => 'updateForm', 'novalidate' => 'novalidate'); ?>
      <?= form_open_multipart($const["route"].'/update/'.$const["id"], $attributes); ?>
      <div class="card">
         <div class="card-body">
            <?php if (session()->has('error')) : ?>
            <div class="row">
               <div mg="6" class="col">
                  <div class="alert alert-danger" role="alert">
                     <ul style="margin-bottom:0px;">
                        <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                        <?php endforeach; ?>
                     </ul>
                  </div>
               </div>
            </div>
            <?php endif ?>
            <div class="row">
            <div class="col-md-3">
               <div class="mb-3">
                     <label for="employeeId">Employee ID</label>
                     <input type="text" class="form-control" id="employeeId" name="employeeId" placeholder="Employee ID" value="<?= old('employeeId', $data->employeeId); ?>" disabled>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="mb-3">
                     <label for="employeeName">Employee Name</label>
                     <input type="text" class="form-control" id="employeeName" name="employeeName" placeholder="Employee Name" value="<?= old('employeeName', $data->employeeName); ?>" disabled>
                  </div>
               </div>
               <div class="col-md-3 mb-3">
                  <label for="mobileNumber">Mobile Number </label>
                  <input type="number" class="form-control" id="mobileNumber" name="mobileNumber" placeholder = "Mobile Number" value="<?= old('mobileNumber', $data->mobileNumber); ?>" oninput="this.value = this.value.replace(/\D/g, '').slice(0, 10)" pattern="[0-9]{10}" minlength="10" laxlength="10" disabled>
               </div>
               <div class="col-md-3" id="designationId">
                  <div class="mb-3">
                     <label for="designationId">Designation</label>
                     <select class="form-control" id="designationId" name="designationId" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($designations as $designation)
                           {
                               $selected = null;
                           
                               (old('designationId', $profile->designationId) == $designation->designationId) ? $selected = "selected" : $selected == "";
                               echo '<option value="'.$designation->designationId.'" '.$selected.'>'.$designation->designation.'</option>';
                           
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="dateOfBirth">
                  <div class="mb-3">
                     <label for="dateOfBirth">Date Of Birth</label>
                     <input class="form-control" value="<?= $profile->dateOfBirth; ?>" id="dateOfBirth" name="dateOfBirth" placeholder="Date of Birth" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="dateOfJoining">
                  <div class="mb-3">
                     <label for="dateOfJoining">Date of Joining</label>
                     <input class="form-control" value="<?= $profile->dateOfJoining; ?>" id="dateOfJoining" name="dateOfJoining" placeholder="Date of Joining" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="motherName">
                  <div class="mb-3">
                     <label for="motherName">Mother Name</label>
                     <input class="form-control" value="<?= $profile->motherName; ?>" id="motherName" name="motherName" placeholder="Mother Name" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="fatherName">
                  <div class="mb-3">
                     <label for="fatherName">Father Name</label>
                     <input class="form-control" value="<?= $profile->fatherName; ?>" id="fatherName" name="fatherName" placeholder="Father Name" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="adhaarNumber">
                  <div class="mb-3">
                     <label for="adhaarNumber">Adhaar Number</label>
                     <input class="form-control" value="<?= $profile->adhaarNumber; ?>" id="adhaarNumber" name="adhaarNumber" placeholder="Adhaar Number" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="panNumber">
                  <div class="mb-3">
                     <label for="panNumber">Pan Number</label>
                     <input class="form-control" value="<?= $profile->panNumber; ?>" id="panNumber" name="panNumber" placeholder="Pan Number" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="drivingLicenseNumber">
                  <div class="mb-3">
                     <label for="drivingLicenseNumber">DL Number</label>
                     <input class="form-control" value="<?= $profile->drivingLicenseNumber; ?>" id="drivingLicenseNumber" name="drivingLicenseNumber" placeholder="DL Number" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="esicNumber">
                  <div class="mb-3">
                     <label for="esicNumber">ESIC Number</label>
                     <input class="form-control" value="<?= $profile->esicNumber; ?>" id="esicNumber" name="esicNumber" placeholder="ESIC Number" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="personalInsurance">
                  <div class="mb-3">
                     <label for="personalInsurance">Personal Insurance</label>
                     <input class="form-control" value="<?= $profile->personalInsurance; ?>" id="personalInsurance" name="personalInsurance" placeholder="Personal Insurance" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="healthInsurance">
                  <div class="mb-3">
                     <label for="healthInsurance">Health Insurance</label>
                     <input class="form-control" value="<?= $profile->healthInsurance; ?>" id="healthInsurance" name="healthInsurance" placeholder="Health Insurance" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="accidentalInsurance">
                  <div class="mb-3">
                     <label for="accidentalInsurance">Accidental Insurance</label>
                     <input class="form-control" value="<?= $profile->accidentalInsurance; ?>" id="accidentalInsurance" name="accidentalInsurance" placeholder="Accidental Insurance" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="highestQualification">
                  <div class="mb-3">
                     <label for="highestQualification">Highesh Qualification</label>
                     <select class="form-control" id="highestQualification" name="highestQualification" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($qualifications as $qualification)
                           {
                               $selected = null;
                           
                               (old('qualificationId', $profile->highestQualification) == $qualification->qualificationId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$qualification->qualificationId.'" '.$selected.'>'.$qualification->qualificationName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="martialStatus">
                  <div class="mb-3">
                     <label for="martialStatus">Martial Status</label>
                     <input class="form-control" value="<?= $profile->martialStatus; ?>" id="martialStatus" name="martialStatus" placeholder="Martial Status" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="noOfChildren">
                  <div class="mb-3">
                     <label for="noOfChildren">No of Children</label>
                     <input class="form-control" value="<?= $profile->noOfChildren; ?>" id="noOfChildren" name="noOfChildren" placeholder="No of Children" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="height">
                  <div class="mb-3">
                     <label for="height">Height</label>
                     <input class="form-control" value="<?= $profile->height; ?>" id="height" name="height" placeholder="Height" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="weight">
                  <div class="mb-3">
                     <label for="weight">Weight</label>
                     <input class="form-control" value="<?= $profile->weight; ?>" id="weight" name="weight" placeholder="Weight" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="presentAddress">
                  <div class="mb-3">
                     <label for="presentAddress">Present Address</label>
                     <input class="form-control" value="<?= $profile->presentAddress; ?>" id="presentAddress" name="presentAddress" placeholder="Present Address" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="permanentAddess">
                  <div class="mb-3">
                     <label for="permanentAddess">Permanent Address</label>
                     <input class="form-control" value="<?= $profile->permanentAddess; ?>" id="permanentAddess" name="permanentAddess" placeholder="Permanent Address" disabled>
                  </div>
               </div>
               <div class="col-md-3" id="projectId">
                  <div class="mb-3">
                     <label for="projectId">Project</label>
                     <select class="form-control" id="projectId" name="projectId" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($projects as $project)
                           {
                               $selected = null;
                           
                               (old('projectId', $profile->projectId) == $project->projectId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$project->projectId.'" '.$selected.'>'.$project->projectName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="headQuarterId">
                  <div class="mb-3">
                     <label for="headQuarterId">Headquarter</label>
                     <select class="form-control" id="headQuarterId" name="headQuarterId" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($headQuarters as $headQuarter)
                           {
                               $selected = null;
                           
                               (old('headQuarterId', $profile->headquarterId) == $headQuarter->headQuarterId) ? $selected = "selected" : $selected == "";
                           
                               echo '<option value="'.$headQuarter->headQuarterId.'" '.$selected.'>'.$headQuarter->headQuarterName.'</option>';
                           }
                           ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="salary">
                  <div class="mb-3">
                     <label for="salary">Salary</label>
                     <input class="form-control" value="<?= $profile->salary; ?>" id="salary" name="salary" placeholder="Salary" disabled>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="mb-3">
                     <label for="reportTo">Report To</label>
                     <select class="form-control" id="reportTo" name="reportTo" disabled>
                        <option value="">Please Select</option>
                        <?php
                           foreach($users as $user)
                           {
                              $selected = null;
               
                              (old('userId', $profile->reportTo) == $user->userId) ? $selected = "selected" : $selected == "";
               
                              echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                           }
                        ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3" id="leaveBalance">
                  <div class="mb-3">
                     <label for="leaveBalance">Leave Balance</label>
                     <input class="form-control" value="<?= $profile->leaveBalance; ?>" id="leaveBalance" name="leaveBalance" placeholder="Leave Balance" disabled>
                  </div>
               </div>
            </div>
         </div>
         <div class="card-footer">
            <div class="d-flex flex-wrap gap-2">
               <a href="<?= site_url($const["route"]); ?>" class="btn btn-danger waves-effect waves-light">
               <i class="bx bx-left-arrow-alt font-size-16 align-middle me-2"></i> Back
               </a>
            </div>
         </div>
      </div>
      </form>
   </div>
</div>
<!-- end row -->
<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>assets/js/pages/form-validation.init.js"></script>
<?= $this->endSection() ?>
