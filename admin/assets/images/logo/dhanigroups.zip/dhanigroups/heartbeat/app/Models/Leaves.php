<?php

namespace App\Models;
class Leaves extends \CodeIgniter\Model
{
    
    protected $table = 'leaves';
    protected $primaryKey = 'leaveId';
    protected $allowedFields = ['userId', 'leaveCategoryId', 'fromDate', 'toDate', 'total', 'approvedBy', 'status', 'nextApprover', 'remarks', 'approverRemarks','createdDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'userId' => 'required',
        'leaveCategoryId' => 'required',
        'fromDate' => 'required',
        'toDate' => 'required',
        'status' => 'required',
        'approvedBy' => 'required',
        'nextApprover' => 'required',
    ];

    protected $validationMessages = [
        'userId' => [
            'required' => 'Please select the Employee'
        ],
        'leaveCategoryId' => [
            'required' => 'Please select the Category'
        ],
        'fromDate' => [
            'required' => 'Please choose the Leave From Date'
        ],
        'toDate' => [
            'required' => 'Please choose the Leave To Date'
        ],
        'status' => [
            'required' => 'Please choose the Status'
        ],
        'nextApprover' => [
            'required' => 'Please choose the Next Approver'
        ],
        'approvedBy' => [
            'required' => 'Please choose the User'
        ]
    ];

    public function findById($leaveId)
    {
        return $this->where('leaveId', $leaveId)->first();
    }
}
?>