<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Leaves extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
	    $this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
        $this->expenseDocuments = new \App\Models\ExpenseDocuments;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
        $this->leaveDocuments = new \App\Models\LeaveDocuments;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside leaves/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

    public function balance()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $result = array();

                    $totalBalance = 0;
                    $leaveCategories = $this->leaveCategories->findAll();
                    foreach($leaveCategories as $leaveCategory)
                    {
                        $total = $this->leaveDeposits->select('SUM(leaves) as total')->where('leaveCategoryId', $leaveCategory->leaveCategoryId)->where('userId', $userId)->first()->total;

                        $consumed = $this->leaves->select('SUM(total) as total')
                                    ->where('leaveCategoryId', $leaveCategory->leaveCategoryId)
                                    ->where('userId', $userId)
                                    ->groupStart()
                                    ->where('status', 'APPROVED')
                                    ->orWhere('status', 'PENDING')
                                    ->groupEnd()
                                    ->first()->total;

                        $consumed = ($consumed) ? $consumed : 0;
                        $balance = $total - $consumed;
                        $totalBalance = $totalBalance + $balance;

                        $data = array('categoryName' => $leaveCategory->leaveCategory, 'leaveBalance' => $balance);
                        array_push($result, $data);

                    }

                    $data = array('categoryName' => "Total", 'leaveBalance' => $totalBalance);
                    array_push($result, $data);

                    $response = [
                        "status" => 200,
                        "message" => "Data fetched successfully",
                        "error" => false,
                        "data" => $result
                    ];

                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->leaves->select('COUNT(leaveId) as total')->where('userId', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->leaves->where('userId', $userId)->orderBy('leaveId', 'DESC')->limit($limit, $offset)->find();

                    if($data)
                    {

                        foreach($data as $leaves)
                        {
                            $nextApproverName = $this->users->findById($leaves->nextApprover) ? $this->users->findById($leaves->nextApprover)->employeeName: "-";
                            $leaves->nextApproverName = $nextApproverName;

                            $leaveCategoryName = $this->leaveCategories->findById($leaves->leaveCategoryId) ? $this->leaveCategories->findById($leaves->leaveCategoryId)->leaveCategory: "-";
                            $leaves->leaveCategoryName = $leaveCategoryName;

                            $leaveId = $leaves->leaveId;
                            $documents = $this->leaveDocuments->where('leaveId', $leaveId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->leaveDocumentId);
                                unset($document->leaveId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }

                            $leaves->documents = $documents;

                        }
                        
                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{

                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");

                    //Content Goes Here
                    $query = $this->leaves->where('userId', $userId);

                    if($startDate && $endDate)
                    {
                        $query = $query->where("fromDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE)->orWhere("toDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE);
                    }

                    $data = $query = $query->orderBy('leaveId', 'DESC')->find();

                    if($data)
                    {
                        foreach($data as $leaves)
                        {
                            $nextApproverName = $this->users->findById($leaves->nextApprover) ? $this->users->findById($leaves->nextApprover)->employeeName: "-";
                            $leaves->nextApproverName = $nextApproverName;

                            $leaveCategoryName = $this->leaveCategories->findById($leaves->leaveCategoryId) ? $this->leaveCategories->findById($leaves->leaveCategoryId)->leaveCategory: "-";
                            $leaves->leaveCategoryName = $leaveCategoryName;

                            $leaveId = $leaves->leaveId;
                            $documents = $this->leaveDocuments->where('leaveId', $leaveId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->leaveDocumentId);
                                unset($document->leaveId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }

                            $leaves->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function new()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;

                $reportTo = $this->profile->findByUserId($userId) ? $this->profile->findByUserId($userId)->reportTo: null;
				$user = $this->checkUser($userId);

				if($user)
				{
                    $uploadFolder = "uploads/";
                    //Content Goes Here
                    $post = json_decode(json_encode($this->request->getVar()), true);
                    $data = new Entity($post);

                    $data->userId = $userId;
                    $data->nextApprover = $reportTo;

                    $leave = $this->leaves->where('userId', $userId)->where('fromDate', $this->request->getVar('fromDate'))->where('toDate', $this->request->getVar('toDate'))->first();

                    if(!$leave)
                    {
                        if ($this->leaves->insert($data))
                        {
                            $leaveId = $this->leaves->getInsertID();
                            $documentsArray = $this->request->getVar("documents");

                            foreach($documentsArray as $documentArray)
                            {
                                $file = $documentArray->document;
                                $imageName = "exp_".$leaveId."_".date("Ymd")."_".rand(1,1000).".pdf";
                                if(file_exists($uploadFolder.$imageName))
                                {
                                    $imageName = rand(1,1000)."_".$imageName;
                                }

                                file_put_contents($uploadFolder.$imageName, base64_decode($file));
                                $document = $uploadFolder.$imageName;

                                $insertArray = array(
                                    'leaveId' => $leaveId,
                                    'document' => $document,
                                );

                                if(!$this->leaveDocuments->insert($insertArray))
                                {
                                    $response = [
                                        "status" => 500,
                                        "message" => "Documents upload error",
                                        "error" => true,
                                        "data" => $this->leaveDocuments->errors()
                                    ];
                                }

                            }

                            $response = [
                                "status" => 200,
                                "message" => "Leave recorded successfully",
                                "error" => false,
                                "data" => []
                            ];
                        }
                        else
                        {
                            $response = [
                                "status" => 500,
                                "message" => "Sorry, unable to record leave",
                                "error" => true,
                                "data" => $this->leaves->errors()
                            ];
                        }
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "Duplicate Expense",
                            "error" => true,
                            "data" => []
                        ];
                    }

                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

}
