<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Labourattendancereports extends BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\LabourAttendance();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Reports/Labourattendancereports/');
        define('ITEM','Labour Attendance');
        define('ITEMS','Labour Attendance Reports');
        define('DBTABLE','labor_attendance');
        define('VARIABLE','data');
        define('ROUTE','labourattendancereports');

        session()->set('activate', "reports");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        if ($_SERVER['REQUEST_METHOD'] == 'POST') 
        {
            
            $data = array();
        
            $post = $this->request->getPost();
        
            $fromDate = date("Y-m-d", strtotime($post["fromDate"]));
            $toDate = date("Y-m-d", strtotime($post["toDate"]));
        
            $query = $this->labourAttendance->select('attendanceId, userId, laborName, laborMobile, date, attendanceType, attendance, distanceFromHQ, status, nextApprover, approvedBy');
        
            if ($post["fromDate"] && $post["toDate"]) 
            {
                $query->where("DATE(date) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'");
            } 
            elseif ($post["fromDate"]) 
            {
                $query->where("DATE(date) >= '" . $fromDate . "'");
            } 
            elseif ($post["toDate"]) 
            {
                $query->where("DATE(date) <= '" . $toDate . "'");
            }
            if ($post["status"]) 
            {
                $query->where('status', $post["status"]);
            }

        
            $labourattendance = $query->findAll();
        
            foreach ($labourattendance as $list) 
            {
                $list->userId = $this->users->findById($list->userId) ? $this->users->findById($list->userId)->employeeName:"-";
                $list->nextApprover = $this->users->findById($list->nextApprover) ? $this->users->findById($list->nextApprover)->employeeName : "-";
                $list->approvedBy = $this->users->findById($list->approvedBy) ? $this->users->findById($list->approvedBy)->employeeName : "-";
                if($list->status == "PENDING")
                {
                    $list->status = "<span class='badge badge-soft-danger font-size-12'>".$list->status."</span>";
                }
                else
                {
                    $list->status = "<span class='badge badge-soft-success font-size-12'>".$list->status."</span>";
                }

            }
        
        $data = array('labor_attendance' => $labourattendance);

        }
        else
        {
        
        $post = array();
        $data = array();
    
        }

        $users = $this->users->findAll();
       
        return view(VIEWFOLDER.'index', ['const' => $const, 'data' => $data, 'post' => $post, 'users' => $users]);
    }
    

}
