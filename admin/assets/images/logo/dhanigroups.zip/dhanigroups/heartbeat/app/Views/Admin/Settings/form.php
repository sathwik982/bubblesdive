<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
<div class="col-md-3 mb-3">
        <label for="morningAttendanceStart">Morning Attendance Start <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="time" class="form-control" id="morningAttendanceStart" name="morningAttendanceStart" required value="<?= old('morningAttendanceStart', $data->morningAttendanceStart); ?>">
        <div class="invalid-feedback">Please choose the Morning Attendance Start</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="morningAttendanceEnd">Morning Attendance End <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="time" class="form-control" id="morningAttendanceEnd" name="morningAttendanceEnd" required value="<?= old('morningAttendanceEnd', $data->morningAttendanceEnd); ?>">
        <div class="invalid-feedback">Please choose the Morning Attendance Start</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="eveningAttendanceStart">Evening Attendance Start <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="time" class="form-control" id="eveningAttendanceStart" name="eveningAttendanceStart" required value="<?= old('eveningAttendanceStart', $data->eveningAttendanceStart); ?>">
        <div class="invalid-feedback">Please choose the Evening Attendance Start</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="eveningAttendanceEnd">Evening Attendance End <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="time" class="form-control" id="eveningAttendanceEnd" name="eveningAttendanceEnd" required value="<?= old('eveningAttendanceEnd', $data->eveningAttendanceEnd); ?>">
        <div class="invalid-feedback">Please choose the Evening Attendance End</div>
    </div>  
</div>