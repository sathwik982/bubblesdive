<?php

namespace App\Models;
class Users extends \CodeIgniter\Model
{
    
    protected $table = 'users';
    protected $primaryKey = 'userId';
    protected $allowedFields = ['employeeId', 'employeeName', 'mobileNumber', 'userPassword', 'userStatus', 'userRole', 'canHireLabour', 'createdDate', 'lastModifiedDate', 'otp'];
    protected $useTimestamps = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'employeeId' => 'required|is_unique[users.employeeId]',
        'mobileNumber' => 'required|numeric|is_unique[users.mobileNumber]',
        'canHireLabour' => 'required',
        'userPassword' => 'required|min_length[6]',
        'password_confirmation' => 'required|matches[userPassword]'
    ];

    protected $validationMessages = [
        'employeeId' => [
            'required' => 'Employee ID is required',
            'is_unique' => 'This Employee ID is already registered'
        ],
        'mobileNumber' => [
            'required' => 'Mobile Number is required',
            'numeric' => 'Only Numerics are accepted in Mobile Number field',
            'is_unique' => 'This Mobile Number is already registered'
        ],
        'canHireLabour' => [
            'required' => 'This field is required',
        ],
        'userPassword' => [
            'required' => 'Password field is required',
            'min_length' => 'Password is too short'
        ],
        'password_confirmation' => [
            'required' => 'Password Confirmation field is required',
            'matches' => 'Passwords do not match'
        ]
    ];

    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data)
    {
        if(isset($data['data']['userPassword']))
        {
            $data['data']['userPassword'] = md5($data['data']['userPassword']);
            unset($data['data']['password_confirmation']);
        }
        return $data;
    }

    public function findByMobileNumber($mobileNumber)
    {
        return $this->where('mobileNumber', $mobileNumber)->first();
    }

    public function findById($userId)
    {
        return $this->where('userId', $userId)->first();
    }

    public function disablePasswordValidation()
    {
        unset($this->validationRules['userPassword']);
        unset($this->validationRules['password_confirmation']);
    }

}
?>