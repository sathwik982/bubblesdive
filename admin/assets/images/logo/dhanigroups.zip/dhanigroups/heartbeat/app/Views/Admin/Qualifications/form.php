<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="qualificationName">Qualification Name <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="qualificationName" name="qualificationName" placeholder="Qualification Name" required value="<?= old('qualificationName', $data->qualificationName); ?>">
    </div>
    <div class="invalid-feedback">Please enter the Qualification Name</div>
</div>