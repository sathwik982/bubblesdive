<?php

namespace App\Models;
class LeaveCategories extends \CodeIgniter\Model
{
    
    protected $table = 'leave_categories';
    protected $primaryKey = 'leaveCategoryId';
    protected $allowedFields = ['leaveCategory'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'leaveCategory' => 'required'
    ];

    protected $validationMessages = [
        'leaveCategory' => [
            'required' => 'Category Name is required'
        ]
    ];

    public function findById($leaveCategoryId)
    {
        return $this->where('leaveCategoryId', $leaveCategoryId)->first();
    }
}
?>