<?php

namespace App\Models;
class Designations extends \CodeIgniter\Model
{
    
    protected $table = 'designations';
    protected $primaryKey = 'designationId';
    protected $allowedFields = ['designation', 'createdDate', 'lastModifiedDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'designation' => 'required'
    ];

    protected $validationMessages = [
        'designation' => [
            'required' => 'Designation is required'
        ]
    ];

    public function findById($designationId)
    {
        return $this->where('designationId', $designationId)->first();
    }
}
?>