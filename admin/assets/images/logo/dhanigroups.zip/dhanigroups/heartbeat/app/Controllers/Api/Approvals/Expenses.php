<?php

namespace App\Controllers\Api\Approvals;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Expenses extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseDocuments = new \App\Models\ExpenseDocuments;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveDocuments = new \App\Models\LeaveDocuments;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside expenses/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

	public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->expense->select('COUNT(expenseId) as total')->where('status', 'PENDING')->where('nextApprover', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->expense->where('status', 'PENDING')->where('nextApprover', $userId)->orderBy('expenseId', 'DESC')->limit($limit, $offset)->find();

                    if($data)
                    {
                        foreach($data as $expense)
                        {
                            $expenseId = $expense->expenseId;
                            $documents = $this->expenseDocuments->where('expenseId', $expenseId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->expenseDocumentId);
                                unset($document->expenseId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }
                            
                            $nextApproverName = $this->users->findById($expense->nextApprover) ? $this->users->findById($expense->nextApprover)->employeeName: "-";
                            $expense->nextApproverName = $nextApproverName;

                            $expenseCategoryName = $this->expenseCategories->findById($expense->expenseCategoryId) ? $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory: "-";
                            $expense->expenseCategoryName = $expenseCategoryName;

                           
                                $vehicleRegNumber = $this->vehicles->findById($expense->vehicleId) ? $this->vehicles->findById($expense->vehicleId)->vehicleRegNumber: "-";
                                $expense->vehicleRegNumber = $vehicleRegNumber;
                            

                            $expense->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

    public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{

                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");
                    $expenseCategoryId = $this->request->getVar("expenseCategoryId");

                    //Content Goes Here
                    $query = $this->expense->where('status', 'PENDING')->where('nextApprover', $userId);

                    if($startDate && $endDate)
                    {
                        $query = $query->where("expenseDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE);
                    }

                    if($expenseCategoryId && $expenseCategoryId >= 1)
                    {
                        $query = $query->where("expenseCategoryId", $expenseCategoryId);
                    }

                    $data = $query = $query->orderBy('expenseId', 'DESC')->find();

                    if($data)
                    {
                        foreach($data as $expense)
                        {
                            $expenseId = $expense->expenseId;
                            $documents = $this->expenseDocuments->where('expenseId', $expenseId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->expenseDocumentId);
                                unset($document->expenseId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }
                            
                            $nextApproverName = $this->users->findById($expense->nextApprover) ? $this->users->findById($expense->nextApprover)->employeeName: "-";
                            $expense->nextApproverName = $nextApproverName;

                            $expenseCategoryName = $this->expenseCategories->findById($expense->expenseCategoryId) ? $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory: "-";
                            $expense->expenseCategoryName = $expenseCategoryName;

                            if($expense->vehicleId >= 1)
                            {
                                $vehicleRegNumber = $this->vehicles->findById($expense->vehicleId) ? $this->vehicles->findById($expense->vehicleId)->vehicleRegNumber: "-";
                                $expense->vehicleRegNumber = $vehicleRegNumber;
                            }

                            $expense->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function view($id = null)
	{
		$auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$expenseId = $this->request->getVar("expenseId");
                    //Content Goes Here
                    $total = $this->expense->where('expenseId', $expenseId)->first()->total;
                    $data = $this->expense->where('expenseId', $expenseId)->first();

					$expense = $data;
                    if($expense)
                    {
                        $expenseId = $expense->expenseId;
						$documents = $this->expenseDocuments->where('expenseId', $expenseId)->findAll();

						foreach($documents as $document)
						{
							unset($document->expenseDocumentId);
							unset($document->expenseId);
							unset($document->createdDate);
							unset($document->lastModifiedDate);

							if($document->document)
							{
								$document->document = site_url($document->document);
							}
						}
						
						$nextApproverName = $this->users->findById($expense->nextApprover) ? $this->users->findById($expense->nextApprover)->employeeName: "-";
						$expense->nextApproverName = $nextApproverName;

						$expenseCategoryName = $this->expenseCategories->findById($expense->expenseCategoryId) ? $this->expenseCategories->findById($expense->expenseCategoryId)->expenseCategory: "-";
						$expense->expenseCategoryName = $expenseCategoryName;

						if($expense->vehicleId >= 1)
						{
							$vehicleRegNumber = $this->vehicles->findById($expense->vehicleId) ? $this->vehicles->findById($expense->vehicleId)->vehicleRegNumber: "-";
							$expense->vehicleRegNumber = $vehicleRegNumber;
						}

						$expense->documents = $documents;

						$logs = $this->logs->select('log, createdDate')->where('expenseId', $expenseId)->orderBy('logId', 'ASC')->findAll();
						$expense->logs = $logs;

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $expense
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
	}

	public function approve($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$expenseId = $this->request->getVar("expenseId");
					$currentApprover = $userId;
					$profile = $this->profile->where('userId', $userId)->first();
					$nextApprover = ($profile->reportTo && $profile->reportTo >= 1) ? $profile->reportTo : null;

					if($this->request->getVar("expenseId") && $this->request->getVar("expenseId") >= 1)
					{
					//Content Goes Here
						if($nextApprover)
						{
							$updateArray = array(
								'nextApprover' => $nextApprover,
								'status' => 'APPROVED'
							);

							if($this->expense->set($updateArray)->where('expenseId', $expenseId)->update())
							{
								$log = array(
									'userId' => $userId,
									'expenseId' => $expenseId,
									'log' => "Expense approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Expense approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->expense->errors()
								];
							}
						}
						else
						{
							$updateArray = array(
								'nextApprover' => null,
								'status' => 'APPROVED',
								'approvedBy' => $userId
							);

							if($this->expense->set($updateArray)->where('expenseId', $expenseId)->update())
							{
								$log = array(
									'userId' => $userId,
									'expenseId' => $expenseId,
									'log' => "Expense approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Expense approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->leaves->errors()
								];
							}
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Expense ID is required",
							"error" => true,
							"data" => []
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function reject($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$expenseId = $this->request->getVar("expenseId");
					$approverRemarks = $this->request->getVar("approverRemarks");

					if($this->request->getVar("expenseId") && $this->request->getVar("expenseId") >= 1 && $approverRemarks)
					{
					//Content Goes Here
						$updateArray = array(
							'status' => 'REJECTED',
							'approverRemarks' => $approverRemarks
						);

						if($this->expense->set($updateArray)->where('expenseId', $expenseId)->update())
						{
							$log = array(
								'userId' => $userId,
								'expenseId' => $expenseId,
								'log' => $approverRemarks
							);

							$this->logs->insert($log);

							$response = [
								"status" => 200,
								"message" => "Expense rejected successfully",
								"error" => false,
								"data" => []
							];
						}
						else
						{
							$response = [
								"status" => 500,
								"message" => "Sorry, unable to approve attendance",
								"error" => true,
								"data" => $this->expense->errors()
							];
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Expense ID & Remarks are required",
							"error" => true,
							"data" => []
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

}