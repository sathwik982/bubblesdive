<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3" id="userId">
        <div class="mb-3">
            <label for="userId">User <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="userId" name="userId" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->userId) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the User</div>
        </div>
    </div>
    <div class="col-md-3" id="leaveCategoryId">
        <div class="mb-3">
            <label for="leaveCategoryId">Leave Category <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="leaveCategoryId" name="leaveCategoryId" required>
                <option value="">Please Select</option>
                <?php
                    foreach($leaveCategories as $leaveCategory)
                    {
                        $selected = null;
    
                        (old('leaveCategoryId', $data->leaveCategoryId) == $leaveCategory->leaveCategoryId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$leaveCategory->leaveCategoryId.'" '.$selected.'>'.$leaveCategory->leaveCategory.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Leave Category</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="leaves">No of Leaves <small>(In days)</small><span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="number" class="form-control" id="leaves" name="leaves" required placeholder="No of Leaves" value="<?= old('leaves', $data->leaves); ?>">
        <div class="invalid-feedback">Please enter the No of Leaves</div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
            <label for="depositedBy">Depositer Name <span style="color:#ff0000;"><sup>*</sup></span></label>
            <input type="text" class="form-control" id="depositedBy" name="depositedBy" readonly  value="<?= old('depositedBy',session('employeeName')); ?>">
          
          
        </div>
    </div>
</div>