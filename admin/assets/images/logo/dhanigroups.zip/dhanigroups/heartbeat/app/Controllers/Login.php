<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Login extends BaseController
{
    public function index()
    {
        if(service('auth')->isLoggedIn())
        {
            $redirect_url = session('redirect_url') ?? '/dashboard';
            unset($_SESSION['redirect_url']);
            return redirect()->to($redirect_url);
        }
        else
        {
            return view('login');
        }
        
    }

    public function login()
    {
        $post = $this->request->getPost();
        $mobileNumber = $post['mobileNumber'];
        $password = $post['userPassword'];
        
        $auth = service('auth');

        if($auth->login($mobileNumber, $password))
        {
            $redirect_url = session('redirect_url') ?? '/dashboard';
            unset($_SESSION['redirect_url']);
            return redirect()->to($redirect_url)->with('success', 'Login Successful');
        }
        else
        {
            return redirect()->to('login')->withInput()->with('warning', 'Invalid Credentials');
        }
    }

    public function logout()
    {
        service('auth')->logout();
        return redirect()->to('login/showLogoutMessage');
    }

    public function showLogoutMessage()
    {
        return redirect()->to('login')->with('success', 'Logout Successful');
    }
}
