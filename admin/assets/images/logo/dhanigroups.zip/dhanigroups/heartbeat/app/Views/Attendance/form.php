<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3 mb-3">
        <label for="picture">Attendance Picture</label>
        <input type="file" class="form-control" id="picture" name="picture" value="<?= old('picture', $data->picture); ?>" required>
        <div class="invalid-feedback">Please upload the Attendance Picture</div>
    </div>
    <div class="col-md-3" id="userId">
        <div class="mb-3">
            <label for="userId">Employee <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="userId" name="userId" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->userId) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Employee</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="date">Date <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="date" name="date" required value="<?= old('date', $data->date); ?>">
        <div class="invalid-feedback">Please choose the Date</div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="attendanceType">Attendance Type <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="attendanceType" name="attendanceType" required>
                <option value="">Please Select</option>
                <option value="MORNING" <?php if(old('attendanceType', $data->attendanceType) == "MORNING") { echo "selected"; } ?>>MORNING</option>
                <option value="EVENING" <?php if(old('attendanceType', $data->attendanceType) == "EVENING") { echo "selected"; } ?>>EVENING</option>
            </select>
            <div class="invalid-feedback">Please choose the Attendance Type</div>
        </div>
    </div>
    <div class="col-md-3">
    <div class="mb-3">
    <label for="attendance">Attendance <span style="color:#ff0000;"><sup>*</sup></span></label>
        <select class="form-control" id="attendance" name="attendance" required>
            <option value="">Please Select</option>
            <option value="1" <?php if(old('attendance', $data->attendance) == "1") { echo "selected"; } ?>>PRESENT</option>
            <option value="0.5" <?php if(old('attendance', $data->attendance) == "0.5") { echo "selected"; } ?>>HALF-DAY</option>
            <option value="0" <?php if(old('attendance', $data->attendance) == "0") { echo "selected"; } ?>>ABSENT</option>
        </select>
        <div class="invalid-feedback">Please choose the Attendance</div>
    </div>
   </div>
   <div class="col-md-3 mb-3">
        <label for="attendanceLatt">Lattitude <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="attendanceLatt" name="attendanceLatt" placeholder="Lattitude"  required value="<?= old('attendanceLatt', $data->attendanceLatt); ?>">
        <div class="invalid-feedback">Please enter the Lattitude</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="attendanceLong">Longtitude <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="text" class="form-control" id="attendanceLong" name="attendanceLong" placeholder="Longtitude" required value="<?= old('attendanceLong', $data->attendanceLong); ?>">
        <div class="invalid-feedback">Please enter the Longtitude</div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="status">Status <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="status" name="status" required>
                <option value="">Please Select</option>
                <option value="PENDING" <?php if(old('status', $data->status) == "PENDING") { echo "selected"; } ?>>PENDING</option>
                <option value="APPROVED" <?php if(old('status', $data->status) == "APPROVED") { echo "selected"; } ?>>APPROVED</option>
            </select>
            <div class="invalid-feedback">Please choose the Status</div>
        </div>
    </div>
    <div class="col-md-3" id="nextApprover">
        <div class="mb-3">
            <label for="nextApprover">Next Approver <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="nextApprover" name="nextApprover" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->nextApprover) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Next Approver</div>
        </div>
    </div>
    <div class="col-md-3" id="approvedBy">
        <div class="mb-3">
            <label for="approvedBy">Approved By <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="approvedBy" name="approvedBy" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->approvedBy) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the User</div>
        </div>
    </div>
    <div class="col-md-12 mb-3">
        <label for="approverRemarks">Approver Remarks  <small>(If Any)</small></label>
        <textarea id="approverRemarks" name="approverRemarks" class="form-control" placeholder="Approver Remarks (Optional)"><?= old('approverRemarks', $data->approverRemarks); ?></textarea>
    </div>
    <div class="col-md-12 mb-3">
        <label for="remarks">Remarks <small>(If Any)</small></label>
        <textarea id="remarks" name="remarks" class="form-control" placeholder="Remarks (Optional)"><?= old('remarks', $data->remarks); ?></textarea>
    </div>
</div>
