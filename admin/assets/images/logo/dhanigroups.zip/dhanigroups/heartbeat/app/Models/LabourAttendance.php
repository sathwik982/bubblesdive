<?php

namespace App\Models;
class LabourAttendance extends \CodeIgniter\Model
{
    
    protected $table = 'labor_attendance';
    protected $primaryKey = 'attendanceId';
    protected $allowedFields = ['userId', 'laborName', 'laborMobile', 'date', 'attendanceType', 'attendance', 'attendanceLatt', 'attendanceLong', 'distanceFromHQ', 'status', 'approvedBy',  'createdDate', 'lastModifiedDate', 'picture', 'approverRemarks', 'nextApprover', 'remarks'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'userId' => 'required',
        'laborName' => 'required',
        'laborMobile' => 'required',
        'date' => 'required',
        'attendance' => 'required',
        'attendanceLatt' => 'required',
        'attendanceLong' => 'required',
        'attendanceType' => 'required',
        'status' => 'required',
        'nextApprover' => 'required',
        'approvedBy' => 'required',
        'picture' => 'required'
    ];

    protected $validationMessages = [
        'userId' => [
            'required' => 'Please choose the Employee'
        ],
        'laborName' => [
            'required' => 'Labor Name is required'
        ],
        'laborMobile' => [
            'required' => 'Labor Mobile is required'
        ],
        'attendanceType' => [
            'required' => 'Attendance Type is required'
        ],
        'attendanceLatt' => [
            'required' => 'Attendance Lattitude is required'
        ],
        'attendanceLong' => [
            'required' => 'Attendance Longitude is required'
        ],
        'attendance' => [
            'required' => 'Attendance is required'
        ],
        'status' => [
            'required' => 'Status is required'
        ],
        'nextApprover' => [
            'required' => 'Next Approver is required'
        ],
        'approvedBy' => [
            'required' => 'Approved By is required'
        ],
        'picture' => [
            'required' => 'Labour Attendance Picture is required'
        ]
    ];

    public function findById($attendanceId)
    {
        return $this->where('attendanceId', $attendanceId)->first();
    }

}
?>