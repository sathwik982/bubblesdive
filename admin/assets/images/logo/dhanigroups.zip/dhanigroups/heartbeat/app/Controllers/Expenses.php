<?php

namespace App\Controllers;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Expenses extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Expenses();
        include_once "heartbeat/app/Controllers/models.php";

        define('VIEWFOLDER','Expenses/');
        define('ITEM','Expense');
        define('ITEMS','Expenses');
        define('DBTABLE','expense');
        define('VARIABLE','data');
        define('ROUTE','expenses');

        session()->set('activate', "expenses");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );
        $expenseCategories = $this->expenseCategories->findAll();
        return view(VIEWFOLDER.'index', ['const' => $const, 'expenseCategories' => $expenseCategories]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('expenseId, userId, expenseDate, expenseCategoryId, expenseAmount, vehicleId, status, nextApprover, approvedBy');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->expenseId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a href="'.site_url(ROUTE."/view/".$row->expenseId).'" class="text-primary"><i class="bx bx-show-alt" style="font-size:20px;"></i></a>
                    ';
        })
        ->edit('userId', function($row)
        {
            $employeeName = $this->users->findById($row->userId) ? $this->users->findById($row->userId)->employeeName: "-";
            return $employeeName;
        })
        ->edit('expenseCategoryId', function($row)
        {
            $expenseCategory = $this->expenseCategories->findById($row->expenseCategoryId) ? $this->expenseCategories->findById($row->expenseCategoryId)->expenseCategory: "-";
            return $expenseCategory;
        })
        ->edit('vehicleId', function($row)
        {
            $vehicleType = $this->vehicles->findById($row->vehicleId) ? $this->vehicles->findById($row->vehicleId)->vehicleType: "-";
            return $vehicleType;
        })
        ->edit('nextApprover', function($row)
        {
            $nextApprover = $this->users->findById($row->nextApprover) ? $this->users->findById($row->nextApprover)->employeeName: "-";
            return $nextApprover;
        })
        ->edit('approvedBy', function($row)
        {
            $approvedBy = $this->users->findById($row->approvedBy) ? $this->users->findById($row->approvedBy)->employeeName: "-";
            return $approvedBy;
        })
        ->edit('status', function($row)
        {
            if($row->status == "APPROVED")
            {
                return "<span class='badge badge-soft-success font-size-12'>" .$row->status. "</span>";
            }
            else
            {
                return "<span class='badge badge-soft-danger font-size-12'>" .$row->status. "</span>";
            }
        })
        ->edit('expenseAmount', function($row) 
        {
            if ($row->expenseAmount != "") 
            {
               return $row->expenseAmount . " Rs";
            } 
        })
        ->filter(function ($builder, $request)
        {
            if ($this->request->getGet("expenseCategoryId"))
            $builder->where("expenseCategoryId", $this->request->getGet("expenseCategoryId"));

            if ($this->request->getGet("status"))
            $builder->where("status", $this->request->getGet("status"));

            if ($this->request->getGet("fromDate") && $this->request->getGet("toDate"))
            {
                $from = date("Y-m-d", strtotime($this->request->getGet("fromDate")));
                $to = date("Y-m-d", strtotime($this->request->getGet("toDate")));

                $builder->where("DATE(expenseDate) BETWEEN '" . $from . "' AND '" . $to . "'", NULL, FALSE);
            }
        })
    
        //->hide('expenseId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        $users = $this->users->findAll();
        $expenseCategories = $this->expenseCategories->findAll();
        $vehicles = $this->vehicles->findAll();
        $expense_documents= $this->expense_documents->findAll();

        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'expenseCategories' => $expenseCategories, 'vehicles' => $vehicles, 'expense_documents' => $expense_documents]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->model->insert($data))
        {
        
        $expenseId = $this->model->getInsertID();

        if($this->request->getFileMultiple('document'))
        {
            $expense_documents = $this->request->getFileMultiple('document');
                foreach($expense_documents as $document)
                {
                    $file = $document;
                    $uploadedFile = $file->getName();
                    $originalName = $file->getName();
                    if($document && $uploadedFile != "")
                    {
                        $uploadedFile = $file->getName();
                        if($uploadedFile != "")
                        {
                            if ($file->isValid() && !$file->hasMoved())
                            {
                                $extension = $file->getClientExtension();
                                $newName = $expenseId . "_closure_".rand().".".$extension;
                                $file->move('uploads/', $newName);
                                $uploadedFile = "uploads/".$newName;
                            }

                            //Save to Database
                            $insertArray = array(
                                'expenseId' => $expenseId,
                                'documents' => $uploadedFile,
                                'createdDate' => date("Y-m-d H:i:s"),
                                'lastModifiedDate' => date("Y-m-d H:i:s")
                            );

                            $this->expense_documents->insert($insertArray);

                        //Save to Database
                    }
                }
            }
        } 
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($expenseId)
    {
        $data = $this->check($expenseId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->expenseId,
            'id'=> $data->expenseId
        );

        $users = $this->users->findAll();
        $expenseCategories = $this->expenseCategories->findAll();
        $vehicles = $this->vehicles->findAll();
        $expense_documents= $this->expense_documents->findAll();
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'expenseCategories' => $expenseCategories, 'vehicles' => $vehicles, 'expense_documents' => $expense_documents]);
    }

    public function update($expenseId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($expenseId);
        $data->lastModifiedDate = date("Y-m-d H:i:s");
        if($this->request->getFileMultiple('document'))
        {
            $expense_documents  = $this->request->getFileMultiple('document');
            foreach($expense_documents  as $document)
            {
                $file = $document;
                $uploadedFile = $file->getName();
                if($document && $uploadedFile != "")
                {
                    $uploadedFile = $file->getName();
                    if($uploadedFile != "")
                    {
                        if ($file->isValid() && !$file->hasMoved())
                        {
                            $extension = $file->getClientExtension();
                            $newName = $expenseId . "_closure_".rand().".".$extension;
                            $file->move('uploads/', $newName);
                            $uploadedFile = "uploads/".$newName;
                        }

                        //Save to Database
                        $insertArray = array(
                            'expenseId' => $expenseId,
                            'documents' => $uploadedFile,
                            'createdDate' => date("Y-m-d H:i:s"),
                            'lastModifiedDate' => date("Y-m-d H:i:s")
                        );

                        $this->expense_documents->insert($insertArray);
                        //Save to Database
                    }
                }
            }
        }
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function view($expenseId)
    {
        $data = $this->check($expenseId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->expenseId,
            'id'=> $data->expenseId
        );
         
        
        $users = $this->users->findAll();
        $expenseCategories = $this->expenseCategories->findAll();
        $vehicles = $this->vehicles->findAll();
        $expense_documents= $this->expense_documents->where('expenseId', $expenseId)->findAll();
        foreach($expense_documents as $expense_document)
        {
            if($expense_document->documents)
            {
                $expense_document->documents = site_url($expense_document->documents);
            }
        }

        return view(VIEWFOLDER."view", [VARIABLE => $data, 'const' => $const, 'users' => $users, 'expenseCategories' => $expenseCategories, 'vehicles' => $vehicles, 'expense_documents' => $expense_documents]);
    }

    public function check($expenseId)
	{
		$data = $this->model->findById($expenseId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $expenseId not found");
		}
		return $data;
	}

}
