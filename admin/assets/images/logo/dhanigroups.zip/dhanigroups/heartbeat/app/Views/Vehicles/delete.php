<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>Delete <?= $const["item"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<!--  BEGIN CONTENT PART  -->
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <h4 class="mb-0">Delete <?= $const["item"]; ?> !</h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
            <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
               <li class="breadcrumb-item"><a href="<?= site_url($const["route"]); ?>"><?= $const["items"]; ?></a></li>
               <li class="breadcrumb-item active"><a href="<?= site_url($const["route"].'/delete/'.$const["id"]); ?>"><?= $const["identifier"]; ?></a></li>
            </ol>
         </div>
      </div>
   </div>
</div>
<!-- end page title -->

<!-- end row -->
<div class="row">
    <div class="col-lg-12">
        <?= form_open($const["route"].'/delete/' . $const["id"]); ?>
        <div class="card">
            <div class="card-body">
                <?php if (session()->has('error')) : ?>
                    <div class="row">
                        <div mg="6" class="col">
                            <div class="alert alert-danger" role="alert">
                                <ul style="margin-bottom:0px;">
                                    <?php foreach (session('error') as $error) : ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-block-helper me-2"></i>
                    <strong>Warning!</strong> Are you sure, you would like to delete <strong><?= $const["identifier"]; ?></strong> ?
                </div>
            </div>
            <div class="card-footer">
               <div class="d-flex flex-wrap gap-2">
                  <button type="submit" class="btn btn-success waves-effect waves-light">
                  <i class="bx bx-right-arrow-alt font-size-16 align-middle me-2"></i> Yes, Delete
                  </button>
                  <a href="<?= site_url($const["route"]); ?>" class="btn btn-danger waves-effect waves-light">
                     <i class="bx bx-left-arrow-alt font-size-16 align-middle me-2"></i> Cancel
                  </a>
               </div>
            </div>
        </div>
        </form>
    </div>
</div>
<!-- end row -->

<!--  END CONTENT PART  -->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>assets/js/pages/form-validation.init.js"></script>
<?= $this->endSection() ?>
