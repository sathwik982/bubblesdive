<?php if (session()->has('error')) : ?>
    <div class="row">
        <div mg="6" class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach (session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-3" id="userId">
        <div class="mb-3">
            <label for="userId">Employee <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="userId" name="userId" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->userId) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Employee</div>
        </div>
    </div>
    <div class="col-md-3" id="leaveCategoryId">
        <div class="mb-3">
            <label for="leaveCategoryId">Leave Category <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="leaveCategoryId" name="leaveCategoryId" required>
                <option value="">Please Select</option>
                <?php
                    foreach($leaveCategories as $leaveCategory)
                    {
                        $selected = null;
    
                        (old('leaveCategoryId', $data->leaveCategoryId) == $leaveCategory->leaveCategoryId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$leaveCategory->leaveCategoryId.'" '.$selected.'>'.$leaveCategory->leaveCategory.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Leave Category</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="fromDate">Leave From Date <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="fromDate" name="fromDate" required value="<?= old('fromDate', $data->fromDate); ?>">
        <div class="invalid-feedback">Please choose the Leave From Date</div>
    </div>
    <div class="col-md-3 mb-3">
        <label for="toDate">Leave To Date <span style="color:#ff0000;"><sup>*</sup></span></label>
        <input type="date" class="form-control" id="toDate" name="toDate" required value="<?= old('toDate', $data->toDate); ?>">
        <div class="invalid-feedback">Please choose the Leave To Date</div>
    </div>
    <div class="col-md-3" id="nextApprover">
        <div class="mb-3">
            <label for="nextApprover">Next Approver <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="nextApprover" name="nextApprover" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->nextApprover) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the Next Approver</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="mb-3">
        <label for="status">Status <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="status" name="status" required>
                <option value="">Please Select</option>
                <option value="PENDING" <?php if(old('status', $data->status) == "PENDING") { echo "selected"; } ?>>PENDING</option>
                <option value="APPROVED" <?php if(old('status', $data->status) == "APPROVED") { echo "selected"; } ?>>APPROVED</option>
            </select>
            <div class="invalid-feedback">Please choose the Status</div>
        </div>
    </div>
    <div class="col-md-3" id="approvedBy">
        <div class="mb-3">
            <label for="approvedBy">Approved By <span style="color:#ff0000;"><sup>*</sup></span></label>
            <select class="form-control" id="approvedBy" name="approvedBy" required>
                <option value="">Please Select</option>
                <?php
                    foreach($users as $user)
                    {
                        $selected = null;
    
                        (old('userId', $data->approvedBy) == $user->userId) ? $selected = "selected" : $selected == "";
    
                        echo '<option value="'.$user->userId.'" '.$selected.'>'.$user->employeeName.'</option>';
                    }
                ?>
            </select>
            <div class="invalid-feedback">Please choose the User</div>
        </div>
    </div>
    <div class="col-md-12 mb-3">
        <label for="approverRemarks">Approver Remarks <small>(If Any)</small></label>
        <textarea id="approverRemarks" name="approverRemarks" class="form-control" placeholder="Approver Remarks (Optional)"><?= old('approverRemarks', $data->approverRemarks); ?></textarea>
    </div>
    <div class="col-md-12 mb-3">
        <label for="remarks">Remarks <small>(If Any)</small></label>
        <textarea id="remarks" name="remarks" class="form-control" placeholder="Remarks (Optional)"><?= old('remarks', $data->remarks); ?></textarea>
    </div>
</div>
<div class="row">
   <div class="col-md-12" id="document_form">
      <div class="row">
         <div class="col-md-9 mb-3">
            <label>Attachments  (<small>Only PDF documents / Image Files. Max size : 8MB</small>)</label>
            <input class="form-control" type="file" name="document[]" accept="application/pdf, image/png, image/gif, image/jpeg">
         </div>
         <div class="col-md-3 mb-3" style="margin-top:40px; text-align:right; padding-right:30px;">
            <a href="javascript:void(0);" onclick="add_document();"><i class="bx bx-plus" style="font-size:20px;"></i></a>
         </div>
      </div>
   </div>
</div>

 