<?php
namespace App\Libraries;

class Authentication
{
    private $user;
    public function login($mobileNumber, $userPassword)
    {
        $model = new \App\Models\Users();
        $user = $model->where('mobileNumber', $mobileNumber)->first();

        if($user === null)
        {
            return false;
        }
        else
        {
            if(md5($userPassword) != $user->userPassword)
            {
               return false;
            } 
        }

        $session = session();
        $session->regenerate();
        $session->set('userId', $user->userId);
        $session->set('employeeId', $user->employeeId);
        $session->set('employeeName', $user->employeeName);
        $session->set('mobileNumber', $user->mobileNumber);
        $session->set('userRole', $user->userRole);
        return true;
    }

    public function logout()
    {
        session()->destroy();
        return true;
    }

    public function getCurrentUser()
    {
        if(! $this->isLoggedIn())
        {
            return null;
        }

        if($this->user === null)
        {
            $model = new \App\Models\Users();
            $this->user = $model->where('userId', session()->get('userId'));
        }

        return $this->user;
    }

    public function isLoggedIn()
    {
        return session()->has('userId');
    }
}