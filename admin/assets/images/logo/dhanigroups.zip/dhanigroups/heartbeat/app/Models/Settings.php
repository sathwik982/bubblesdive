<?php

namespace App\Models;
class Settings extends \CodeIgniter\Model
{
    
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['morningAttendanceStart', 'morningAttendanceEnd', 'eveningAttendanceStart', 'eveningAttendanceEnd'];
    protected $useTimestams = false;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'morningAttendanceStart' => 'required',
        'morningAttendanceEnd' => 'required',
        'eveningAttendanceStart' => 'required',
        'eveningAttendanceEnd' => 'required'
    ];

    public function findById($id)
    {
        return $this->where('id', $id)->first();
    }
}
?>