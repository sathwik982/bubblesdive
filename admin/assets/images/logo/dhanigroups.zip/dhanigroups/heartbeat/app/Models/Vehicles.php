<?php

namespace App\Models;
class Vehicles extends \CodeIgniter\Model
{
    
    protected $table = 'vehicles';
    protected $primaryKey = 'vehicleId';
    protected $allowedFields = ['vehicleType', 'vehicleRegNumber', 'vehiclePucNumber', 'vehiclePucValidity', 'vehicleInsuranceNumber', 'vehicleInsuranceValidity', 'vehicleLastServiceDate', 'picture', 'ownership', 'createdDate', 'lastModifiedDate'];
    protected $useTimestams = true;
    protected $createdField = 'createdDate';
	protected $updatedField = 'lastModifiedDate';
    protected $returnType = 'App\Entities\Entity';

    protected $validationRules    = [
        'vehicleType' => 'required',
        'vehicleRegNumber' => 'required|is_unique[vehicles.vehicleRegNumber]',
        'vehiclePucNumber' => 'required|is_unique[vehicles.vehiclePucNumber]',
        'vehicleInsuranceNumber' => 'required|is_unique[vehicles.vehicleInsuranceNumber]',
        'vehicleInsuranceValidity' => 'required',
        'vehicleLastServiceDate' => 'required',
        'picture' => 'required',
        'ownership' => 'required',

    ];

    protected $validationMessages = [
        'vehicleType' => [
            'required' => 'Vehicle Type is required'
        ],
        'vehicleRegNumber' => [
            'required' => 'Vehicle Registration Number is required',
            'is_unique' => 'Vehicle Registration Number you entered is already used'
        ],
        'vehiclePucNumber' => [
            'required' => 'Vehicle PUC Number is required',
            'is_unique' => 'Vehicle PUC Number you entered is already used'
        ],
        'vehicleInsuranceNumber' => [
            'required' => 'Vehicle Insurance Number is required',
            'is_unique' => 'Vehicle Insurance Number you entered is already used',
        ],
        'vehicleInsuranceValidity' => [
            'required' => 'Vehicle Insurance validity is required',
        ],
        'vehicleLastServiceDate' => [
            'required' => 'Vehicle Last Service Date is required',
        ],
        'picture' => [
            'required' => 'Vehicle Picture is required',
        ],
        'ownership' => [
            'required' => 'Vehicle Ownership is required',
        ],


    ];

    public function findById($vehicleId)
    {
        return $this->where('vehicleId', $vehicleId)->first();
    }
}
?>