<?php

namespace App\Controllers\Admin;
use App\Entities\Entity;
use \Hermawan\DataTables\DataTable;

class Qualifications extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->model = new \App\Models\Qualifications();
        include_once "heartbeat/app/Controllers/models.php";
        
        define('VIEWFOLDER','Admin/Qualifications/');
        define('ITEM','Qualification');
        define('ITEMS','Qualifications');
        define('DBTABLE','qualifications');
        define('VARIABLE','data');
        define('ROUTE','admin/qualifications');

        session()->set('activate', "admin");

    }

    public function index()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

        return view(VIEWFOLDER.'index', ['const' => $const]);
    }

    public function load()
    {
        $db = db_connect();
        $builder = $db->table(DBTABLE)->select('qualificationId, qualificationName, createdDate, lastModifiedDate');
        
        return DataTable::of($builder)
        //->addNumbering()
        ->add('action', function($row)
        {
            return '
                    <a href="'.site_url(ROUTE."/edit/".$row->qualificationId).'" class="text-primary"><i class="bx bx bxs-pencil" style="font-size:20px;"></i></a>
                    <a style="padding-left:10px;" href="'.site_url(ROUTE."/delete/".$row->qualificationId).'" class="text-danger"><i class="bx bx-trash" style="font-size:20px;"></i></a>
                   ';
        })
        //->hide('qualificationId')
        ->toJson();
    }

    public function new()
    {
        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
        );

       
        $data = new Entity();
        return view(VIEWFOLDER."new", [VARIABLE => $data, 'const' => $const]);
    }

    public function create()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}
        
        $post = $this->request->getPost();
        $data = new Entity($this->request->getPost());
        //$data->createdBy = session()->get('userId');

        if($this->model->insert($data))
        {
            return redirect()->to(ROUTE)->with('success', ITEM.' created successfully');
        }
        else
        {
            return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
        }

    }

    public function edit($qualificationId)
    {
        $data = $this->check($qualificationId);

        $const = array(
            'route' => ROUTE,
            'variable'=> VARIABLE,
            'item'=> ITEM,
            'items'=> ITEMS,
            'viewfolder'=> VIEWFOLDER,
            'identifier'=> $data->qualificationName,
            'id'=> $data->qualificationId
        );
        
        return view(VIEWFOLDER."edit", [VARIABLE => $data, 'const' => $const]);
    }

    public function update($qualificationId)
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
			$response = service("response");
			$response->setStatusCode(403);
			$response->setBody("You do not have permission to access this page directly");
			return $response;
		}

		$post = $this->request->getPost();
		$data = $this->check($qualificationId);
		$data->fill($post);

		if (!$data->hasChanged())
		{
			return redirect()->back()->with('warning', 'No changes were made to save')->withInput();
		}
		else if ($this->model->save($data))
		{
			return redirect()->to(ROUTE)->with('success', ITEM.' updated successfully')->withInput();
		}
		else
		{
			return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong.')->withInput();
		}
    }

    public function delete($qualificationId)
    {
        $data = $this->check($qualificationId);
        if($_SERVER['REQUEST_METHOD'] != 'POST')
		{
            $const = array(
                'route' => ROUTE,
                'variable'=> VARIABLE,
                'item'=> ITEM,
                'items'=> ITEMS,
                'viewfolder'=> VIEWFOLDER,
                'identifier'=> $data->qualificationName,
                'id'=> $data->qualificationId
            );
			return view(VIEWFOLDER."delete", [VARIABLE => $data, 'const' => $const]);
		}
		else
		{
			$data = $this->check($qualificationId);
			if ($this->model->delete($qualificationId))
			{
				return redirect()->to(ROUTE)->with('success', ITEM.' deleted successfully');
			}
			else
			{
				return redirect()->back()->with('error', $this->model->errors())->with('warning', 'Something went wrong. Please check the form fields.')->withInput();
			}
		}
    }

    public function check($qualificationId)
	{
		$data = $this->model->findById($qualificationId);
		if($data===null)
		{
			throw new \CodeIgniter\Exceptions\PageNotFoundException(ITEM." with the ID : $qualificationId not found");
		}
		return $data;
	}
}
