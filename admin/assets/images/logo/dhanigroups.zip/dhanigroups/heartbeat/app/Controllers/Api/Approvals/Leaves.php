<?php

namespace App\Controllers\Api\Approvals;

use CodeIgniter\RESTful\ResourceController;
use Exception;
use App\Entities\Entity;
use Firebase\JWT\JWT;
use App\Models\Users;
use PDO;
use Location\Coordinate;
use Location\Distance\Vincenty;

class Leaves extends ResourceController
{
	public function __construct()
    {
        $this->attendance = new \App\Models\Attendance;
		$this->designations = new \App\Models\Designations;
		$this->expense = new \App\Models\Expenses;
		$this->expenseCategories = new \App\Models\ExpenseCategories;
		$this->headquarters = new \App\Models\Headquarters;
		$this->laborAttendance = new \App\Models\LabourAttendance;
		$this->leaves = new \App\Models\Leaves;
		$this->leaveDocuments = new \App\Models\LeaveDocuments;
		$this->leaveCategories = new \App\Models\LeaveCategories;
		$this->leaveDeposits = new \App\Models\LeaveDeposits;
		$this->logs = new \App\Models\Logs;
		$this->profile = new \App\Models\Profile;
		$this->projects = new \App\Models\Projects;
		$this->qualifications = new \App\Models\Qualifications;
		$this->settings = new \App\Models\Settings;
		$this->users = new \App\Models\Users;
		$this->vehicles = new \App\Models\Vehicles;
    }

	public function getKey()
	{
		return "3170d4b2-d84d-7845-96ee-fa3efe5068ca";
	}

	private function checkUser($userId)
	{
		$user = $this->users->where('userId', $userId)->where('userStatus', 'ACTIVE')->first();
		if($user)
		{
			return $user;
		}
		else
		{
			false;
		}
	}

    public function index()
    {
        $response = [
            "status" => 500,
            "message" => "Please choose the right route inside leaves/",
            "error" => true,
            "data" => []
        ];

        return $this->respondCreated($response);
    }

	public function list($limit = null, $offset = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
                    //Content Goes Here
                    $total = $this->leaves->select('COUNT(leaveId) as total')->where('status', 'PENDING')->where('nextApprover', $userId)->first()->total;

                    if(!$limit || $limit <= 0) {  $limit = 20; }
                    if(!$offset ) {  $offset = 0; }

                    $data = $this->leaves->where('status', 'PENDING')->where('nextApprover', $userId)->orderBy('leaveId', 'DESC')->limit($limit, $offset)->find();

                    if($data)
                    {

                        foreach($data as $leaves)
                        {
                            $nextApproverName = $this->users->findById($leaves->nextApprover) ? $this->users->findById($leaves->nextApprover)->employeeName: "-";
                            $leaves->nextApproverName = $nextApproverName;

                            $leaveCategoryName = $this->leaveCategories->findById($leaves->leaveCategoryId) ? $this->leaveCategories->findById($leaves->leaveCategoryId)->leaveCategory: "-";
                            $leaves->leaveCategoryName = $leaveCategoryName;

                            $leaveId = $leaves->leaveId;
                            $documents = $this->leaveDocuments->where('leaveId', $leaveId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->leaveDocumentId);
                                unset($document->leaveId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }

                            $leaves->documents = $documents;

                        }
                        
                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function filter()
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{

                    $startDate = $this->request->getVar("startDate");
                    $endDate = $this->request->getVar("endDate");

                    //Content Goes Here
                    $query = $this->leaves->where('status', 'PENDING')->where('nextApprover', $userId);

                    if($startDate && $endDate)
                    {
                        $query = $query->where("fromDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE)->orWhere("toDate BETWEEN '" . $startDate . "' AND '" . $endDate . "'", NULL, FALSE);
                    }

                    $data = $query = $query->orderBy('leaveId', 'DESC')->find();

                    if($data)
                    {
                        foreach($data as $leaves)
                        {
                            $nextApproverName = $this->users->findById($leaves->nextApprover) ? $this->users->findById($leaves->nextApprover)->employeeName: "-";
                            $leaves->nextApproverName = $nextApproverName;

                            $leaveCategoryName = $this->leaveCategories->findById($leaves->leaveCategoryId) ? $this->leaveCategories->findById($leaves->leaveCategoryId)->leaveCategory: "-";
                            $leaves->leaveCategoryName = $leaveCategoryName;

                            $leaveId = $leaves->leaveId;
                            $documents = $this->leaveDocuments->where('leaveId', $leaveId)->findAll();

                            foreach($documents as $document)
                            {
                                unset($document->leaveDocumentId);
                                unset($document->leaveId);
                                unset($document->createdDate);
                                unset($document->lastModifiedDate);

                                if($document->document)
                                {
                                    $document->document = site_url($document->document);
                                }
                            }

                            $leaves->documents = $documents;
                        }

                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "data" => $data
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function view($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);
				$leaveId = $this->request->getVar("leaveId");

				if($user)
				{
                    //Content Goes Here
                    $total = $this->leaves->select('COUNT(leaveId) as total')->where('leaveId', $leaveId)->first()->total;
                    $data = $this->leaves->where('leaveId', $leaveId)->orderBy('leaveId', 'DESC')->first();

					$leaves = $data;

                    if($leaves)
                    {
                        $nextApproverName = $this->users->findById($leaves->nextApprover) ? $this->users->findById($leaves->nextApprover)->employeeName: "-";
						$leaves->nextApproverName = $nextApproverName;

						$leaveCategoryName = $this->leaveCategories->findById($leaves->leaveCategoryId) ? $this->leaveCategories->findById($leaves->leaveCategoryId)->leaveCategory: "-";
						$leaves->leaveCategoryName = $leaveCategoryName;

						$leaveId = $leaves->leaveId;
						$documents = $this->leaveDocuments->where('leaveId', $leaveId)->findAll();

						foreach($documents as $document)
						{
							unset($document->leaveDocumentId);
							unset($document->leaveId);
							unset($document->createdDate);
							unset($document->lastModifiedDate);

							if($document->document)
							{
								$document->document = site_url($document->document);
							}
						}

						$leaves->documents = $documents;
                        
                        $response = [
                            "status" => 200,
                            "message" => "Data Fetched successfully",
                            "error" => false,
                            "totalRecords" => $total,
                            "data" => $leaves
                        ];
                    }
                    else
                    {
                        $response = [
                            "status" => 500,
                            "message" => "No Data found",
                            "error" => false,
                            "data" => []
                        ];
                    }
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function approve($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$leaveId = $this->request->getVar("leaveId");
					$currentApprover = $userId;
					$profile = $this->profile->where('userId', $userId)->first();
					$nextApprover = ($profile->reportTo && $profile->reportTo >= 1) ? $profile->reportTo : null;

					if($this->request->getVar("leaveId") && $this->request->getVar("leaveId") >= 1)
					{
					//Content Goes Here
						if($nextApprover)
						{
							$updateArray = array(
								'nextApprover' => $nextApprover,
								'status' => 'APPROVED'
							);

							if($this->leaves->set($updateArray)->where('leaveId', $leaveId)->update())
							{
								$log = array(
									'userId' => $userId,
									'leaveId' => $leaveId,
									'log' => "Leave approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Leave approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->leaves->errors()
								];
							}
						}
						else
						{
							$updateArray = array(
								'nextApprover' => null,
								'status' => 'APPROVED',
								'approvedBy' => $userId
							);

							if($this->leaves->set($updateArray)->where('leaveId', $leaveId)->update())
							{
								$log = array(
									'userId' => $userId,
									'leaveId' => $leaveId,
									'log' => "Leave approved"
								);

								$this->logs->insert($log);

								$response = [
									"status" => 200,
									"message" => "Leave approved successfully",
									"error" => false,
									"data" => []
								];
							}
							else
							{
								$response = [
									"status" => 500,
									"message" => "Sorry, unable to approve attendance",
									"error" => true,
									"data" => $this->leaves->errors()
								];
							}
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Leave ID is required",
							"error" => true,
							"data" => []
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

	public function reject($id = null)
    {
        $auth = $this->request->getServer('HTTP_AUTHORIZATION');
		try
		{
			if (isset($auth))
			{
                $token = explode(' ', $auth)[0];
				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));
				$userId = $decoded_data->userinfo->userId;
				$user = $this->checkUser($userId);

				if($user)
				{
					$leaveId = $this->request->getVar("leaveId");
					$approverRemarks = $this->request->getVar("approverRemarks");

					if($this->request->getVar("leaveId") && $this->request->getVar("leaveId") >= 1 && $approverRemarks)
					{
					//Content Goes Here
						$updateArray = array(
							'status' => 'REJECTED',
							'approverRemarks' => $approverRemarks
						);

						if($this->leaves->set($updateArray)->where('leaveId', $leaveId)->update())
						{
							$log = array(
								'userId' => $userId,
								'leaveId' => $leaveId,
								'log' => $approverRemarks
							);

							$this->logs->insert($log);

							$response = [
								"status" => 200,
								"message" => "Leave rejected successfully",
								"error" => false,
								"data" => []
							];
						}
						else
						{
							$response = [
								"status" => 500,
								"message" => "Sorry, unable to approve attendance",
								"error" => true,
								"data" => $this->leaves->errors()
							];
						}
					}
					else
					{
						$response = [
							"status" => 500,
							"message" => "Leave ID & Remarks are required",
							"error" => true,
							"data" => []
						];
					}
                    //Content Goes Here
                }
                else
                {
                    $response = [
                        "status" => 500,
                        "message" => "Session Expired. Please login & try again.",
                        "error" => true,
                        "data" => []
                    ];
                }
			}
		}
		catch (Exception $ex)
		{
			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}
		return $this->respondCreated($response);
    }

}