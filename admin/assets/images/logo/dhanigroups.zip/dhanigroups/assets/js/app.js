! function() {
    "use strict";
    var t, e, a, n = localStorage.getItem("language"),
        s = "en";

    function o(e) {
        document.getElementsByClassName("header-lang-img").forEach(function(t) {
            if (t) {
                switch (e) {
                    case "en":
                        t.src = "assets/images/flags/us.jpg";
                        break;
                    case "sp":
                        t.src = "assets/images/flags/spain.jpg";
                        break;
                    case "gr":
                        t.src = "assets/images/flags/germany.jpg";
                        break;
                    case "it":
                        t.src = "assets/images/flags/italy.jpg";
                        break;
                    case "ru":
                        t.src = "assets/images/flags/russia.jpg";
                        break;
                    default:
                        t.src = "assets/images/flags/us.jpg"
                }
                localStorage.setItem("language", e), n = localStorage.getItem("language"),
                    function() {
                        null == n && o(s);
                        var t = new XMLHttpRequest;
                        t.open("GET", "/assets/lang/" + n + ".json"), t.onreadystatechange = function() {
                            var a;
                            4 === this.readyState && 200 === this.status && (a = JSON.parse(this.responseText), Object.keys(a).forEach(function(e) {
                                document.querySelectorAll("[data-key='" + e + "']").forEach(function(t) {
                                    t.textContent = a[e]
                                })
                            }))
                        }, t.send()
                    }()
            }
        })
    }

    function l() {
        var t = document.querySelectorAll(".counter-value");
        t && t.forEach(function(s) {
            ! function t() {
                var e = +s.getAttribute("data-target"),
                    a = +s.innerText,
                    n = e / 250;
                n < 1 && (n = 1), a < e ? (s.innerText = (a + n).toFixed(0), setTimeout(t, 1)) : s.innerText = e
            }()
        })
    }

    function d() {
        setTimeout(function() {
            var t, e, a, n = document.getElementById("side-menu");
            n && (t = n.querySelector(".mm-active .active"), 300 < (e = t ? t.offsetTop : 0) && (e -= 100, (a = document.getElementsByClassName("vertical-menu") ? document.getElementsByClassName("vertical-menu")[0] : "") && a.querySelector(".simplebar-content-wrapper") && setTimeout(function() {
                a.querySelector(".simplebar-content-wrapper").scrollTop = e
            }, 0)))
        }, 0)
    }

    function i() {
        for (var t = document.getElementById("topnav-menu-content").getElementsByTagName("a"), e = 0, a = t.length; e < a; e++) "nav-item dropdown active" === t[e].parentElement.getAttribute("class") && (t[e].parentElement.classList.remove("active"), t[e].nextElementSibling.classList.remove("show"));
        window.innerWidth <= 992 ? (document.getElementsByClassName("vertical-menu")[0].removeAttribute("style"), "horizontal" == document.body.getAttribute("data-layout") && (document.getElementsByClassName("vertical-menu")[0].style.display = "none")) : "vertical" == document.body.getAttribute("data-layout") && (document.getElementsByClassName("vertical-menu")[0].style.display = "block")
    }

    function r(t) {
        var e = document.getElementById(t);
        e.style.display = "block";
        var a = setInterval(function() {
            e.style.opacity || (e.style.opacity = 1), 0 < e.style.opacity ? e.style.opacity -= .2 : (clearInterval(a), e.style.display = "none")
        }, 200)
    }

    function c() {
        var t, e, a;
        feather.replace(), window.sessionStorage && ((t = sessionStorage.getItem("is_visited")) ? "rtl" == document.getElementsByTagName("html")[0].style.direction ? sessionStorage.setItem("is_visited", "layout-direction-rtl") : null !== (e = document.querySelector("#" + t)) && (e.checked = !0, a = t, 1 == document.getElementById("layout-direction-ltr").checked && "layout-direction-ltr" === a ? (document.getElementsByTagName("html")[0].removeAttribute("dir"), document.getElementById("layout-direction-rtl").checked = !1, document.getElementById("bootstrap-style").setAttribute("href", "assets/css/bootstrap.min.css"), document.getElementById("app-style").setAttribute("href", "assets/css/app.min.css"), sessionStorage.setItem("is_visited", "layout-direction-ltr")) : 1 == document.getElementById("layout-direction-rtl").checked && "layout-direction-rtl" === a && (document.getElementById("layout-direction-ltr").checked = !1, document.getElementById("bootstrap-style").setAttribute("href", "assets/css/bootstrap-rtl.min.css"), document.getElementById("app-style").setAttribute("href", "assets/css/app-rtl.min.css"), document.getElementsByTagName("html")[0].setAttribute("dir", "rtl"), sessionStorage.setItem("is_visited", "layout-direction-rtl"))) : sessionStorage.setItem("is_visited", "layout-direction-ltr"))
    }

    function u(t) {
        document.getElementById(t) && (document.getElementById(t).checked = !0)
    }

    function m() {
        document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.body.classList.remove("fullscreen-enable")
    }
    window.onload = function() {
            document.getElementById("preloader") && (r("pre-status"), r("preloader"))
        }, c(), document.addEventListener("DOMContentLoaded", function(t) {
            document.getElementById("side-menu") && new MetisMenu("#side-menu")
        }), l(),
        function() {
            var e = document.body.getAttribute("data-sidebar-size");
            window.onload = function() {
                1024 <= window.innerWidth && window.innerWidth <= 1366 && (document.body.setAttribute("data-sidebar-size", "sm"), u("sidebar-size-small"))
            };
            for (var t = document.getElementsByClassName("vertical-menu-btn"), a = 0; a < t.length; a++) t[a] && t[a].addEventListener("click", function(t) {
                t.preventDefault(), document.body.classList.toggle("sidebar-enable"), 992 <= window.innerWidth ? null == e ? null == document.body.getAttribute("data-sidebar-size") || "lg" == document.body.getAttribute("data-sidebar-size") ? document.body.setAttribute("data-sidebar-size", "sm") : document.body.setAttribute("data-sidebar-size", "lg") : "md" == e ? "md" == document.body.getAttribute("data-sidebar-size") ? document.body.setAttribute("data-sidebar-size", "sm") : document.body.setAttribute("data-sidebar-size", "md") : "sm" == document.body.getAttribute("data-sidebar-size") ? document.body.setAttribute("data-sidebar-size", "lg") : document.body.setAttribute("data-sidebar-size", "sm") : d()
            })
        }(), setTimeout(function() {
            var t = document.querySelectorAll("#sidebar-menu a");
            t && t.forEach(function(t) {
                var e, a, n, s, o, l = window.location.href.split(/[?#]/)[0];
                t.href == l && (t.classList.add("active"), (e = t.parentElement) && "side-menu" !== e.id && (e.classList.add("mm-active"), (a = e.parentElement) && "side-menu" !== a.id && (a.classList.add("mm-show"), (n = a.parentElement) && "side-menu" !== n.id && (n.classList.add("mm-active"), (s = n.parentElement) && "side-menu" !== s.id && (s.classList.add("mm-show"), (o = s.parentElement) && "side-menu" !== o.id && o.classList.add("mm-active"))))))
            })
        }, 0), (t = document.querySelectorAll(".navbar-nav a")) && t.forEach(function(t) {
            var e, a, n, s, o, l, d = window.location.href.split(/[?#]/)[0];
            t.href == d && (t.classList.add("active"), (e = t.parentElement) && (e.classList.add("active"), (a = e.parentElement).classList.add("active"), (n = a.parentElement) && (n.classList.add("active"), (s = n.parentElement).closest("li") && s.closest("li").classList.add("active"), s && (s.classList.add("active"), (o = s.parentElement) && (o.classList.add("active"), (l = o.parentElement) && l.classList.add("active"))))))
        }), (e = document.querySelector('[data-toggle="fullscreen"]')) && e.addEventListener("click", function(t) {
            t.preventDefault(), document.body.classList.toggle("fullscreen-enable"), document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement ? document.cancelFullScreen ? document.cancelFullScreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen && document.webkitCancelFullScreen() : document.documentElement.requestFullscreen ? document.documentElement.requestFullscreen() : document.documentElement.mozRequestFullScreen ? document.documentElement.mozRequestFullScreen() : document.documentElement.webkitRequestFullscreen && document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT)
        }), document.addEventListener("fullscreenchange", m), document.addEventListener("webkitfullscreenchange", m), document.addEventListener("mozfullscreenchange", m),
        function() {
            if (document.getElementById("topnav-menu-content")) {
                for (var t = document.getElementById("topnav-menu-content").getElementsByTagName("a"), e = 0, a = t.length; e < a; e++) t[e].onclick = function(t) {
                    "#" === t.target.getAttribute("href") && (t.target.parentElement.classList.toggle("active"), t.target.nextElementSibling.classList.toggle("show"))
                };
                window.addEventListener("resize", i)
            }
        }(), [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]')).map(function(t) {
            return new bootstrap.Tooltip(t)
        }), [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]')).map(function(t) {
            return new bootstrap.Popover(t)
        }), [].slice.call(document.querySelectorAll(".toast")).map(function(t) {
            return new bootstrap.Toast(t)
        }),
        function() {
            "null" != n && n !== s && o(n);
            var t = document.getElementsByClassName("language");
            t && t.forEach(function(e) {
                e.addEventListener("click", function(t) {
                    o(e.getAttribute("data-lang"))
                })
            })
        }(),
        function() {
            var e = document.getElementsByTagName("body")[0],
                t = document.querySelectorAll(".light-dark");
            t && t.forEach(function(t) {
                t.addEventListener("click", function(t) {
                    e.hasAttribute("data-layout-mode") && "dark" == e.getAttribute("data-layout-mode") ? (u("layout-mode-light"), document.body.setAttribute("data-layout-mode", "light"), "vertical" == document.body.getAttribute("data-layout") && document.body.setAttribute("data-topbar", "light")) : (u("layout-mode-dark"), document.body.setAttribute("data-layout-mode", "dark"), "vertical" == document.body.getAttribute("data-layout") && document.body.setAttribute("data-topbar", "dark"))
                })
            }), e.hasAttribute("data-layout-mode") && "dark" == e.getAttribute("data-layout-mode") ? u("layout-mode-dark") : u("layout-mode-light"), e.hasAttribute("data-layout-size") && "boxed" == e.getAttribute("data-layout-size") ? u("layout-width-boxed") : u("layout-width-fluid"), e.hasAttribute("data-layout-scrollable") && "true" == e.getAttribute("data-layout-scrollable") ? u("layout-position-scrollable") : u("layout-position-fixed"), e.hasAttribute("data-topbar") && "dark" == e.getAttribute("data-topbar") ? u("topbar-color-dark") : u("topbar-color-light"), e.hasAttribute("data-sidebar-size") && "sm" == e.getAttribute("data-sidebar-size") ? u("sidebar-size-small") : e.hasAttribute("data-sidebar-size") && "md" == e.getAttribute("data-sidebar-size") ? u("sidebar-size-compact") : u("sidebar-size-default"), e.hasAttribute("data-sidebar") && "brand" == e.getAttribute("data-sidebar") ? u("sidebar-color-brand") : e.hasAttribute("data-sidebar") && "dark" == e.getAttribute("data-sidebar") ? u("sidebar-color-dark") : u("sidebar-color-light"), document.getElementsByTagName("html")[0].hasAttribute("dir") && "rtl" == document.getElementsByTagName("html")[0].getAttribute("dir") ? u("layout-direction-rtl") : u("layout-direction-ltr"), document.querySelectorAll("input[name='layout'").forEach(function(t) {
                t.addEventListener("change", function(t) {
                    t && t.target && "vertical" == t.target.value ? (u("layout-vertical"), document.body.setAttribute("data-layout", "vertical"), document.body.setAttribute("data-sidebar", "dark"), document.body.setAttribute("data-topbar", "light"), document.getElementById("sidebar-setting").style.display = "block", document.getElementsByClassName("isvertical-topbar")[0].style.display = "block", document.getElementsByClassName("ishorizontal-topbar")[0].style.display = "none", document.getElementsByClassName("vertical-menu")[0].style.display = "block", window.innerWidth <= 992 && document.getElementsByClassName("vertical-menu")[0].removeAttribute("style"), u("sidebar-color-dark"), u("topbar-color-light")) : (u("layout-horizontal"), document.body.setAttribute("data-layout", "horizontal"), document.body.removeAttribute("data-sidebar"), document.body.setAttribute("data-topbar", "dark"), document.getElementById("sidebar-setting").style.display = "none", document.getElementsByClassName("vertical-menu")[0].style.display = "none", document.getElementsByClassName("ishorizontal-topbar")[0].style.display = "block")
                })
            }), document.querySelectorAll("input[name='layout-mode']").forEach(function(t) {
                t.addEventListener("change", function(t) {
                    t && t.target && t.target.value && ("light" == t.target.value ? (document.body.setAttribute("data-layout-mode", "light"), document.body.setAttribute("data-topbar", "light"), document.body.setAttribute("data-sidebar", "dark"), e.hasAttribute("data-layout") && "horizontal" == e.getAttribute("data-layout") && document.body.removeAttribute("data-sidebar"), u("topbar-color-light")) : (document.body.setAttribute("data-layout-mode", "dark"), document.body.setAttribute("data-topbar", "dark"), document.body.setAttribute("data-sidebar", "dark"), e.hasAttribute("data-layout") && "horizontal" == e.getAttribute("data-layout") || u("topbar-color-dark")), u("sidebar-color-dark"))
                })
            }), document.querySelectorAll("input[name='layout-direction']").forEach(function(t) {
                t.addEventListener("change", function(t) {
                    t && t.target && t.target.value && ("ltr" == t.target.value ? (document.getElementsByTagName("html")[0].removeAttribute("dir"), document.getElementById("bootstrap-style").setAttribute("href", "assets/css/bootstrap.min.css"), document.getElementById("app-style").setAttribute("href", "assets/css/app.min.css"), sessionStorage.setItem("is_visited", "layout-direction-ltr")) : (document.getElementById("bootstrap-style").setAttribute("href", "assets/css/bootstrap-rtl.min.css"), document.getElementById("app-style").setAttribute("href", "assets/css/app-rtl.min.css"), document.getElementsByTagName("html")[0].setAttribute("dir", "rtl"), sessionStorage.setItem("is_visited", "layout-direction-rtl")))
                })
            })
        }(), d(), (a = document.getElementById("checkAll")) && (a.onclick = function() {
            for (var t = document.querySelectorAll('.table-check input[type="checkbox"]'), e = 0; e < t.length; e++) t[e].checked = this.checked
        })
}();